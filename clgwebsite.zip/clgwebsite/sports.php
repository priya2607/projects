<!DOCTYPE html>
<html lang="en">
  <head>
  <?php include 'php/head.php';?>
</head>
  <body>
     <!-- SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#"></a>
    <!-- END SCROLL TOP BUTTON -->

    <!--=========== BEGIN HEADER SECTION ================-->
    <?php include 'php/header.php';?>
    <!--=========== END HEADER SECTION ================--> 
    <section id="imgBanner">
      <h2>sports</h2>
    </section>
    <!--=========== END COURSE BANNER SECTION ================-->

    
    <!--=========== BEGIN COURSE BANNER SECTION ================-->
    <section id="courseArchive">
      <div class="container">
        <div class="row">
          <!-- start course content -->
          <div class="col-lg-8 col-md-8 col-sm-8">
            <div class="courseArchive_content">              
             <div class="singlecourse_ferimg_area">
              <div class="slideshow-container">

<div class="">
  <div class="numbertext"></div>
  <img src="img/extra/1 (1).jpg" style="width:100%">
  <div class="text">THE CHANAKYAS OF BUSINESS</div>
</div>

               <!--div class="singlecourse_ferimg">
                 <img src="img/course-single.jpg" alt="img">
               </div>  
                <div class="singlecourse_bottom">
                  <h2>Introduction To Matrix</h2>
                  <span class="singlecourse_author">
                    <img alt="img" src="img/author.jpg">
                    Richard Remus, Teacher
                  </span>
                  <span class="singlecourse_price">$20</span>
                </div-->
             </div>
              <h1>About Sports</h1><p>The college  provides varied extra-curricular activities in Sports for training the students  in Physical Education &amp; Gymnasium for both hostlers and day-scholars. </p><p>The  college offers free admission for the students to practice sports and athletics  in the non-working days.</p><p>We  offer regular and standard coaching for the students through qualified Physical  Director &amp; qualified Physical Trainee team of faculties.</p>
      
      <p><strong>List of games available</strong></p>
    <table class="table table-bordered table-responsive">
  <tr>
    <td width="162" valign="top"><p><strong>INDOOR GAMES</strong></p></td>
    <td width="213" valign="top"><p><strong>OUTDOOR GAMES</strong></p></td>
  </tr>
  <tr>
    <td width="162" valign="top"><p>1.Chess<br />
      2.Carom<br />
      3.Table Tennis<br />
      4.Badminton</p></td>
    <td width="213" valign="top"><p>1.Volleyball<br />
      2.Basketball<br />
      3.Kabaadi<br />
      4.Ball Badminton<br />
      5.Football<br />
      6. Hockey<br />
      7.Handball<br />
      8.Throw ball<br />
      9. Athletics(200m    track)<br />
      10.Cricket.</p></td>
  </tr>
</table>
<h1>Faculty Details</h1>  
<table class="table table-bordered table-responsive">
        <tr>
          <td width="104"><p align="center"><strong>S.No</strong></p></td>
          <td width="177"><p align="center"><strong>Name</strong></p></td>
          <td width="125"><p align="center"><strong>Qualification</strong></p></td>
          <td width="121"><p align="center"><strong>Designation</strong></p></td>
          <td width="120"><p align="center"><strong>Years Of    Experience</strong></p></td>
          <td width="113" valign="top"><p align="center"><strong>Area of    Interest</strong></p></td>
        </tr>
        <tr>
          <td width="104"><p align="center">1.</p></td>
          <td width="177"><p align="center">Dr.P.Murugan</p></td>
          <td width="125"><p align="center">M.Phil.,Ph.D.,</p></td>
          <td width="121"><p align="center">Director of Physical Education</p></td>
          <td width="120"><p align="center">12</p></td>
          <td width="113" valign="top"><p>Athletics</p></td>
        </tr>
        <tr>
          <td width="104"><p align="center">2.</p></td>
          <td width="177"><p align="center">Mr.P. Rajesh Giridhavan</p></td>
          <td width="125"><p align="center">B.P.Ed, M.P.Ed</p></td>
          <td width="121"><p align="center">Asst. Physical Director</p></td>
          <td width="120"><p align="center">01</p></td>
          <td width="113" valign="top"><p>Kabaadi</p></td>
        </tr>
        <tr>
          <td width="104"><p align="center">3.</p></td>
          <td width="177"><p align="center">Mr.C.MuthuKrishnan</p></td>
          <td width="125"><p align="center">B.A.,B.P.Ed</p></td>
          <td width="121"><p align="center">Asst. Physical Director</p></td>
          <td width="120"><p align="center">01</p></td>
          <td width="113" valign="top"><p>Athletics </p></td>
        </tr>
      </table>
       <h1>Achievements 2014-2015</h1>  
<table class="table table-bordered table-responsive">
  <tr>
    <td width="49" valign="top"><p align="center"><strong>Sno.</strong></p></td>
    <td width="126" valign="top"><p align="center"><strong>Event</strong></p></td>
    <td width="88" valign="top"><p align="center"><strong>Date</strong></p></td>
    <td width="143" valign="top"><p align="center"><strong>Participants</strong></p></td>
    <td width="134" valign="top"><p align="center"><strong>Location</strong></p></td>
    <td width="93" valign="top"><p align="center"><strong>Place Won</strong></p></td>
  </tr>
  <tr>
    <td width="49" valign="top"><p align="center">1</p></td>
    <td width="126" valign="top"><p align="center">Erode    District level Body Building Competition</p></td>
    <td width="88" valign="top"><p align="center">15.08.2014</p></td>
    <td width="143" valign="top"><p>M.Suthan,IV Mech</p></td>
    <td width="134" valign="top"><p align="center">Anthiyur  </p></td>
    <td width="93" valign="top"><p align="center">Third    Place</p></td>
  </tr>
  <tr>
    <td width="49" valign="top"><p align="center">2</p></td>
    <td width="126" valign="top"><p align="center">Zone-12 <br />
      Inter    collegiate Badminton  tournament for    Women</p></td>
    <td width="88" valign="top"><p align="center">From    05.09.14 to 06.09.14</p></td>
    <td width="143" valign="top"><p>1.Ms.E.Ramya-IV CIVIL<br />
      2.Ms.K.Immaculate<br />
      Kavipriya-IV    ECE<br />
      S.Vaishnavi-III    ECE</p></td>
    <td width="134" valign="top"><p align="center">&ldquo;KS    RANGASAMY College of Technology&rdquo;, Thiruchengode </p></td>
    <td width="93" valign="top"><p align="center">Third    Place</p></td>
  </tr>
  <tr>
    <td width="49" valign="top"><p align="center">3</p></td>
    <td width="126" valign="top"><p align="center">State    level JKK NATARAJA Trophy KABADDI Tournament for Men</p></td>
    <td width="88" valign="top"><p align="center">From    25.09.14 to 26.09.14</p></td>
    <td width="143" valign="top"><p>1.Mr. V.Muthu Pandi- IV CIVIL</p></td>
    <td width="134" valign="top"><p align="center">&ldquo;JKK    NATARAJA College of Engineering&rdquo;,<br />
      Komarapalayam</p></td>
    <td width="93" valign="top"><p align="center">Best    APPANCE Player Award</p></td>
  </tr>
</table>
      <h3>A selected team meets and wins trophies in  the Anna University Inter Zone Competition every year</h3>

<div class="row">
        <div class="col-sm-6 col-md-4">
        <a><img src="img/extra/1.jpg" class="img-thumbnail"></a>
        </div> 
        
        <div class="col-sm-6 col-md-4">
        <a><img src="img/extra/2.jpg" class="img-thumbnail"></a>
        </div> 
        
        <div class="col-sm-6 col-md-4">
        <a><img src="img/extra/3.jpg" class="img-thumbnail"></a>
        </div> 
        
        <div class="col-sm-6 col-md-4">
        <a><img src="img/extra/4.jpg" class="img-thumbnail"></a>
        </div> 
        
        <div class="col-sm-6 col-md-4">
        <a><img src="img/extra/5.JPG" class="img-thumbnail"></a>
        </div> 
        
        <div class="col-sm-6 col-md-4">
        <a><img src="img/extra/6.JPG" class="img-thumbnail"></a>
        </div> 
         
        
      </div>
</div>
  </div>
               <!--table class="table table-striped course_table">
                <thead>
                  <tr>          
                    <th>Course Title</th>
                    <th>Instructor</th>
                    <th>Timing</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>          
                    <td><a href="#">Computer Science &amp; Engineering</a></td>
                    <td>Dr. Steve Palmer</td>
                    <td>08:00 to 13:00</td>
                  </tr>
                  <tr>
                    <td><a href="#">Electronics &amp; Communications Engineering</a></td>          
                    <td>Jacob</td>                    
                    <td>08:00 to 13:00</td>
                  </tr>
                  <tr>
                    <td><a href="#">Civil Engineering</a></td>          
                    <td>Kimberly Jones</td>                    
                    <td>08:00 to 13:00</td>
                  </tr>
                  <tr>
                    <td><a href="#">Electrical &amp; Electronics Engineering</a></td>   

                    <td>Dr. Klee</td>                    
                    <td>08:00 to 13:00</td>
                  </tr>
                  <tr><td><a href="#">Mechanical Engineering</a></td> </tr>
                </tbody>
              </table-->
             </div>
             <script>
var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 1000); // Change image every 2 seconds
}
</script>

             <!-- start related course -->
             <!--div class="related_course">
                <h2>More Courses</h2>
                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="single_course wow fadeInUp" >
                      <div class="singCourse_imgarea">
                        <img src="img/course-1.jpg">
                        <div class="mask">                         
                          <a class="course_more" href="#">View Course</a>
                        </div>
                      </div>
                      <div class="singCourse_content">
                        <h3 class="singCourse_title"><a href="#">Introduction To Matrix</a></h3>
                        <p class="singCourse_price"><span>$20</span> Per One Month</p>
                        <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
                      </div>
                      <div class="singCourse_author">
                        <img alt="img" src="img/author.jpg">
                        <p>Richard Remus, Teacher</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="single_course wow fadeInUp" >
                      <div class="singCourse_imgarea">
                        <img src="img/course-1.jpg">
                        <div class="mask">                         
                          <a class="course_more" href="#">View Course</a>
                        </div>
                      </div>
                      <div class="singCourse_content">
                        <h3 class="singCourse_title"><a href="#">Introduction To Matrix</a></h3>
                        <p class="singCourse_price"><span>$20</span> Per One Month</p>
                        <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
                      </div>
                      <div class="singCourse_author">
                        <img alt="img" src="img/author.jpg">
                        <p>Richard Remus, Teacher</p>
                      </div>
                    </div>
                  </div>                                    
                </div>
              </div-->
              <!-- End related course -->
            </div>
          </div>
          <!-- End course content -->

          <!-- start course archive sidebar -->
          
          <!-- start course archive sidebar -->
        </div>
      </div>
    </section>

     <!--=========== BEGIN FOOTER SECTION ================-->
  <?php include 'php/footer.php';?>
    <!--=========== END FOOTER SECTION ================--> 

  

    <!-- Javascript Files
    ================================================== -->

    <!-- initialize jQuery Library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <!-- Preloader js file -->
    <script src="js/queryloader2.min.js" type="text/javascript"></script>
    <!-- For smooth animatin  -->
    <script src="js/wow.min.js"></script>  
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- slick slider -->
    <script src="js/slick.min.js"></script>
    <!-- superslides slider -->
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.animate-enhanced.min.js"></script>
    <script src="js/jquery.superslides.min.js" type="text/javascript" charset="utf-8"></script>   
    <!-- for circle counter -->
    <script src='https://cdn.rawgit.com/pguso/jquery-plugin-circliful/master/js/jquery.circliful.min.js'></script>
    <!-- Gallery slider -->
    <script type="text/javascript" language="javascript" src="js/jquery.tosrus.min.all.js"></script>   
   
    <!-- Custom js-->
    <script src="js/custom.js"></script>
  <!--=============================================== 
    Template Design By WpFreeware Team.
    Author URI : http://www.wpfreeware.com/
  ====================================================-->
  </body>
  </html>
<!DOCTYPE html>
<html lang="en">
 <head>
  <?php include 'php/head.php';?>
</head>
  <body>
     <!-- SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#"></a>
    <!-- END SCROLL TOP BUTTON -->

    <!--=========== BEGIN HEADER SECTION ================-->
       <?php include 'php/header.php';?>
    <!--=========== END HEADER SECTION ================--> 
    <section id="imgBanner">
      <h2>Alumni</h2>
    </section>
    <!--=========== END COURSE BANNER SECTION ================-->

    
    <!--=========== BEGIN COURSE BANNER SECTION ================-->
    <section id="courseArchive">
      <div class="container">
        <div class="row">
          <!-- start course content -->
          <div class="col-lg-8 col-md-8 col-sm-8">
            <div class="courseArchive_content">              
             <div class="singlecourse_ferimg_area">
              <div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/index/1.jpg" style="width:100%">
  <div class="text"></div>
</div>

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/index/2.jpg" style="width:100%">
  <div class="text"></div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/index/3.jpg" style="width:100%">
  <div class="text"></div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/index/4.jpg" style="width:100%">
  <div class="text"></div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/index/5.jpg" style="width:100%">
  <div class="text"></div>
</div>
</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
   <span class="dot"></span> 
  <span class="dot"></span>
</div>
               <!--div class="singlecourse_ferimg">
                 <img src="img/course-single.jpg" alt="img">
               </div>  
                <div class="singlecourse_bottom">
                  <h2>Introduction To Matrix</h2>
                  <span class="singlecourse_author">
                    <img alt="img" src="img/author.jpg">
                    Richard Remus, Teacher
                  </span>
                  <span class="singlecourse_price">$20</span>
                </div-->
             </div>
            <div class="row">
<div class="col-xs-12 col-sm-9">
  <div class=" inner"> 
    <div class="">
      <h1>Alumni Day Registration Form</h1>  
                <form role="form" class="form-horizontal" method="post">
    <strong>Alumni Sasurians keep in touch by enrolling yourself .</strong><br>
<br>

<div class="form-group">
  <label class="col-sm-4 control-label" for="inputEmail3">Name</label>
        <div class="col-sm-8">
          <input type="text"  id="inputEmail3" class="form-control" Placeholder="Name" name="name">
        </div>
    </div>
      
      <div class="form-group">
        <label class="col-sm-4 control-label" for="inputEmail3">Anna University Register No</label>
        <div class="col-sm-8">
          <input type="text"  id="inputEmail3" class="form-control" Placeholder="Register No" name="register_no">
        </div>
      </div>
      <div class="form-group">
        <label class="col-sm-4 control-label" for="inputEmail3">Branch </label>
        <div class="col-sm-8">
        <select  class="form-control" name="department" required  data-placeholder="Select Branch" style="width:400px;" >
                      <option value="">Select Department</option>
                                            <optgroup label="UG Courses"> 
                                            <option value="Computer Science and Engineering">Computer Science and Engineering</option>
                                             <option value="Electronics and Communication Engineering">Electronics and Communication Engineering</option>
                                              <option value="Electrical and Electronics Engineering">Electrical and Electronics Engineering</option>
                                               <option value="Mechanical Engineering">Mechanical Engineering</option>
                                               <option value="Civil Engineering">Civil Engineering</option>
                                               <option value="Information Technology">Information Technology</option>
</optgroup>
<optgroup label="PG Courses">
<option value="MCA">MCA</option>
<option value="MBA">MBA</option>
<option value="M.E Computer Science">M.E Computer Science</option>
<option value="M.E VLSI">M.E VLSI</option>
<option value="M.E PED">M.E PED</option>
<option value="M.E Applied Electronics">M.E Applied Electronics</option>
<option value="M.Tech Information Technology">M.Tech Information Technology</option>
</optgroup>
                    </select>
        </div>
      </div>
      <div class="form-group">
        <label class="col-sm-4 control-label" for="inputEmail3">Batch</label>
        <div class="col-sm-8">
            <input type="text"  id="inputEmail3" class="form-control" placeholder="E.g (2010-2014)" name="batch">
        </div>
      </div>
      <div class="form-group">
        <label class="col-sm-4 control-label" for="inputEmail3">Year of Passout</label>
        <div class="col-sm-8">
            <select  data-placeholder="Select Batch" class="form-control" name="passout" style="width:200px;" ><option value="">Select Year</option>      <option value="2018">2018</option>
            <option value="2017">2017</option>
            <option value="2016">2016</option>
            <option value="2015">2015</option>
            <option value="2014">2014</option>
            <option value="2013">2013</option>
            <option value="2012">2012</option>
            <option value="2011">2011</option>
            <option value="2010">2010</option>
            <option value="2009">2009</option>
            <option value="2008">2008</option>
            <option value="2007">2007</option>
            <option value="2006">2006</option>
            <option value="2005">2005</option>
            <option value="2004">2004</option>
            <option value="2003">2003</option>
            <option value="2002">2002</option>
            <option value="2001">2001</option>
      </select>
        </div>
      </div>
      <div class="page-header">What is your current occupation? </div>
<div class="form-group">
  <label class="col-sm-4 control-label" for="inputEmail3">If Employed, Name of the organization</label>
        <div class="col-sm-8">
          <input type="text" placeholder="Designation" id="inputEmail3" class="form-control" name="designation"><br>
<br>
<input type="text" placeholder="Place" id="inputEmail3" class="form-control" name="place">
        </div>
    </div>
    
    <div class="form-group">
  <label class="col-sm-4 control-label" for="inputEmail3">If Doing Business, Type of Business</label>
        <div class="col-sm-8">
          <input type="text" placeholder="Type of Business" id="inputEmail3" class="form-control" name="business"><br>
<br>
<input type="text" placeholder="Place" id="inputEmail3" class="form-control" name="bus_palce">
        </div>
    </div>
    
    <div class="form-group">
  <label class="col-sm-4 control-label" for="inputEmail3">If Pursuing Higher studies</label>
        <div class="col-sm-8">
          <input type="text" placeholder="Course" id="inputEmail3" class="form-control" name="study"><br>
<br>
<input type="text" placeholder="College" id="inputEmail3" class="form-control" name="college">
        </div>
    </div>
      <div class="form-group">
        <label class="col-sm-4 control-label" for="inputEmail3">Marital Status </label>
        <div class="col-sm-8">
          <label class="checkbox-inline">
  <input type="radio" id="inlineCheckbox1" name="marital" value="1"> Single
</label>
<label class="checkbox-inline">
  <input type="radio" id="inlineCheckbox2" name="marital" value="2"> Married
</label> 
        </div>
      </div>
      <div class="form-group">
        <label class="col-sm-4 control-label" for="inputEmail3">Address for communication</label>
        <div class="col-sm-8">
        <div class="row">
  <div class="col-xs-6">
          <textarea class="form-control" id="inputEmail3" placeholder="Residential Address" name="res_address"></textarea>
          </div>
          <div class="col-xs-6">
          <textarea class="form-control" id="inputEmail3" placeholder="Official Address" name="off_address"></textarea>
          </div>
          
          </div>
        </div>
      </div>
      
      
      <div class="form-group">
        <label class="col-sm-4 control-label" for="inputEmail3">Email ID (Username)</label>
        <div class="col-sm-8">
          <input type="email" placeholder="Email" id="inputEmail3" class="form-control" name="email">
        </div>
      </div>
      
      
      <div class="form-group">
        <label class="col-sm-4 control-label" for="inputPassword3">Password</label>
        <div class="col-sm-8">
          <input type="password" placeholder="Password" id="inputPassword3" class="form-control" name="password">
        </div>
      </div>
      <div class="form-group">
        <label class="col-sm-4 control-label" for="inputEmail3">Phone No.</label>
        <div class="col-sm-8">
          <input type="text"  id="inputEmail3" class="form-control" placeholder="Phone Number" name="phone" >
        </div>
      </div>
      <div class="form-group">
        <label class="col-sm-4 control-label" for="inputEmail3">Mobile</label>
        <div class="col-sm-8">
          <input type="text"  id="inputEmail3" class="form-control" name="mobile" placeholder="Mobile Number">
        </div>
      </div>
      <div class="form-group">
        <label class="col-sm-4 control-label" for="inputEmail3">Feedback</label>
        <div class="col-sm-8">
          <input type="text"  id="inputEmail3" class="form-control" placeholder="Feedback" name="feedback">
        </div>
      </div> 
      <div class="form-group">
        <div class="col-sm-offset-4 col-sm-8">
          <div class="checkbox">
            <label>
              <input type="checkbox" required> I Agree to the Terms and Conditions.
            </label>
          </div>
        </div>
      </div>
      <div class="form-group">
    <label for="inputPassword3" class="col-sm-4 control-label">Captcha</label>
    <div class="col-sm-8">
          <img src="http://www.sasurieengg.com/CaptchaSecurityImages.php" class="pull-left"/><input type="text" maxlength="10"   id="mob" placeholder="Captcha" class="form-control pull-left"  style="width:90px;"  required name="security_code"/>
    </div>
  </div>
      <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
          <button class="btn btn-primary" type="submit" name="add">Register</button>
        </div>
      </div>
    </form>
</div>
  </div>
  
</div>
 
 
    </div>
  </div>
  
</div>
             <script>
var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 1000); // Change image every 2 seconds
}
</script>

             <!-- start related course -->
             <!--div class="related_course">
                <h2>More Courses</h2>
                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="single_course wow fadeInUp" >
                      <div class="singCourse_imgarea">
                        <img src="img/course-1.jpg">
                        <div class="mask">                         
                          <a class="course_more" href="#">View Course</a>
                        </div>
                      </div>
                      <div class="singCourse_content">
                        <h3 class="singCourse_title"><a href="#">Introduction To Matrix</a></h3>
                        <p class="singCourse_price"><span>$20</span> Per One Month</p>
                        <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
                      </div>
                      <div class="singCourse_author">
                        <img alt="img" src="img/author.jpg">
                        <p>Richard Remus, Teacher</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="single_course wow fadeInUp" >
                      <div class="singCourse_imgarea">
                        <img src="img/course-1.jpg">
                        <div class="mask">                         
                          <a class="course_more" href="#">View Course</a>
                        </div>
                      </div>
                      <div class="singCourse_content">
                        <h3 class="singCourse_title"><a href="#">Introduction To Matrix</a></h3>
                        <p class="singCourse_price"><span>$20</span> Per One Month</p>
                        <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
                      </div>
                      <div class="singCourse_author">
                        <img alt="img" src="img/author.jpg">
                        <p>Richard Remus, Teacher</p>
                      </div>
                    </div>
                  </div>                                    
                </div>
              </div-->
              <!-- End related course -->
            </div>
          </div>
          <!-- End course content -->

          <!-- start course archive sidebar -->
         
              <!-- start single sidebar -->
              <!--div class="single_sidebar">
                <h2>Sponsor Add <span class="fa fa-angle-double-right"></span></h2>
                <a class="side_add" href="#"><img src="img/side-add.jpg" alt="img"></a>
              </div-->
              <!-- End single sidebar -->
            </div>
          </div>
          <!-- start course archive sidebar -->
        </div>
      </div>
    </section>

     <!--=========== BEGIN FOOTER SECTION ================-->
  <?php include 'php/footer.php';?>
    <!--=========== END FOOTER SECTION ================--> 

  

    <!-- Javascript Files
    ================================================== -->

    <!-- initialize jQuery Library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <!-- Preloader js file -->
    <script src="js/queryloader2.min.js" type="text/javascript"></script>
    <!-- For smooth animatin  -->
    <script src="js/wow.min.js"></script>  
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- slick slider -->
    <script src="js/slick.min.js"></script>
    <!-- superslides slider -->
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.animate-enhanced.min.js"></script>
    <script src="js/jquery.superslides.min.js" type="text/javascript" charset="utf-8"></script>   
    <!-- for circle counter -->
    <script src='https://cdn.rawgit.com/pguso/jquery-plugin-circliful/master/js/jquery.circliful.min.js'></script>
    <!-- Gallery slider -->
    <script type="text/javascript" language="javascript" src="js/jquery.tosrus.min.all.js"></script>   
   
    <!-- Custom js-->
    <script src="js/custom.js"></script>
  <!--=============================================== 
    Template Design By WpFreeware Team.
    Author URI : http://www.wpfreeware.com/
  ====================================================-->
  </body>
  </html>
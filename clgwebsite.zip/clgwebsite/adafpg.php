<!DOCTYPE html>
<html lang="en">
 <head>
  <?php include 'php/head.php';?>
</head>
  <body>
     <!-- SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#"></a>
    <!-- END SCROLL TOP BUTTON -->

    <?php include 'php/header.php';?>
    <!--=========== END HEADER SECTION ================--> 
    <section id="imgBanner">
      <h2>Alumni</h2>
    </section>
    <!--=========== END COURSE BANNER SECTION ================-->

    
    <!--=========== BEGIN COURSE BANNER SECTION ================-->
    <section id="courseArchive">
      <div class="container">
        <div class="row">
          <!-- start course content -->
          <div class="col-lg-8 col-md-8 col-sm-8">
            <div class="courseArchive_content">              
             <div class="singlecourse_ferimg_area">
              <div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/index/1.jpg" style="width:100%">
  <div class="text"></div>
</div>

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/index/2.jpg" style="width:100%">
  <div class="text"></div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/index/3.jpg" style="width:100%">
  <div class="text"></div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/index/4.jpg" style="width:100%">
  <div class="text"></div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/index/5.jpg" style="width:100%">
  <div class="text"></div>
</div>
</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
   <span class="dot"></span> 
  <span class="dot"></span>
</div></div><br>
               <!--div class="singlecourse_ferimg">
                 <img src="img/course-single.jpg" alt="img">
               </div>  
                <div class="singlecourse_bottom">
                  <h2>Introduction To Matrix</h2>
                  <span class="singlecourse_author">
                    <img alt="img" src="img/author.jpg">
                    Richard Remus, Teacher
                  </span>
                  <span class="singlecourse_price">$20</span>
                </div-->
 <div class="row">
<div class="col-xs-12 col-sm-12">
<div class=" inner"> 
<form class="form-horizontal spce" role="form" method="post">
<div class="form-group">
<label for="inputEmail3" class="col-sm-2 control-label">Name of the Student</label>
<div class="col-sm-10">
<input type="text" class="form-control" id="inputEmail3" name="name" required placeholder="Name of the Student" value="">
</div>
</div>
<div class="form-group">
<label for="inputPassword3" class="col-sm-2 control-label">Email ID</label>
<div class="col-sm-10">
<input type="email" class="form-control" id="inputPassword3" name="email" required placeholder="Email ID" value="">
</div>
</div>
<div class="form-group">
<label for="inputPassword3" class="col-sm-2 control-label">Mobile No</label>
<div class="col-sm-10">
<input type="text" class="form-control" id="inputPassword3" name="mobile" required placeholder="Mobile Number" value="">
<input type="hidden" name="xx" value="1">
</div>
</div>
<div class="form-group">
<label for="inputPassword3" class="col-sm-2 control-label">Course Preferred</label>
<div class="col-sm-10">
<select  class="form-control" name="department" required  data-placeholder="Select Department" style="width:400px;" >
<option value="">Select Department</option>
<optgroup label="PG Courses"> 
<option value="MBA">MBA</option>
<option value="M.E Computer Science">M.E Computer Science</option>
<option value="M.E VLSI">M.E VLSI</option>
<option value="M.E PED">M.E PED</option>
<option value="M.E Applied Electronics">M.E Applied Electronics</option> 
</optgroup>
</select>
</div>
</div>
<div class="form-group">
<label for="inputPassword3" class="col-sm-2 control-label">Captcha</label>
<div class="col-sm-10">
<img src="http://www.sasurieengg.com/CaptchaSecurityImages.php?width=60&height=20&characters=5" class="pull-left"/><input type="text" maxlength="10"   id="mob" placeholder="Captcha" class="form-control pull-left"  style="width:90px;"  required name="security_code"/>
</div>
</div>
<div class="form-group">
<div class="col-sm-offset-2 col-sm-10">
<button type="submit" name="apply" class="btn btn-danger">Apply</button>
</div>
</div>
</form>
<p>&nbsp; </p>
<h6 style="font-size:14px;"><strong>Admission Contact</strong> - 94425 93809 , 94425 93824 , 94425 93828</h6>
</div>
             <script>
var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 1000); // Change image every 2 seconds
}
</script>

             <!-- start related course -->
             <!--div class="related_course">
                <h2>More Courses</h2>
                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="single_course wow fadeInUp" >
                      <div class="singCourse_imgarea">
                        <img src="img/course-1.jpg">
                        <div class="mask">                         
                          <a class="course_more" href="#">View Course</a>
                        </div>
                      </div>
                      <div class="singCourse_content">
                        <h3 class="singCourse_title"><a href="#">Introduction To Matrix</a></h3>
                        <p class="singCourse_price"><span>$20</span> Per One Month</p>
                        <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
                      </div>
                      <div class="singCourse_author">
                        <img alt="img" src="img/author.jpg">
                        <p>Richard Remus, Teacher</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="single_course wow fadeInUp" >
                      <div class="singCourse_imgarea">
                        <img src="img/course-1.jpg">
                        <div class="mask">                         
                          <a class="course_more" href="#">View Course</a>
                        </div>
                      </div>
                      <div class="singCourse_content">
                        <h3 class="singCourse_title"><a href="#">Introduction To Matrix</a></h3>
                        <p class="singCourse_price"><span>$20</span> Per One Month</p>
                        <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
                      </div>
                      <div class="singCourse_author">
                        <img alt="img" src="img/author.jpg">
                        <p>Richard Remus, Teacher</p>
                      </div>
                    </div>
                  </div>                                    
                </div>
              </div-->
              <!-- End related course -->
            </div>
          </div>
          <!-- End course content -->

          <!-- start course archive sidebar -->
         
              <!-- start single sidebar -->
              <!--div class="single_sidebar">
                <h2>Sponsor Add <span class="fa fa-angle-double-right"></span></h2>
                <a class="side_add" href="#"><img src="img/side-add.jpg" alt="img"></a>
              </div-->
              <!-- End single sidebar -->
            </div>
          </div>
          <!-- start course archive sidebar -->
        </div>
      </div>
    </section>

     <!--=========== BEGIN FOOTER SECTION ================-->
    <?php include 'php/footer.php';?>
    <!--=========== END FOOTER SECTION ================--> 

  

    <!-- Javascript Files
    ================================================== -->

    <!-- initialize jQuery Library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <!-- Preloader js file -->
    <script src="js/queryloader2.min.js" type="text/javascript"></script>
    <!-- For smooth animatin  -->
    <script src="js/wow.min.js"></script>  
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- slick slider -->
    <script src="js/slick.min.js"></script>
    <!-- superslides slider -->
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.animate-enhanced.min.js"></script>
    <script src="js/jquery.superslides.min.js" type="text/javascript" charset="utf-8"></script>   
    <!-- for circle counter -->
    <script src='https://cdn.rawgit.com/pguso/jquery-plugin-circliful/master/js/jquery.circliful.min.js'></script>
    <!-- Gallery slider -->
    <script type="text/javascript" language="javascript" src="js/jquery.tosrus.min.all.js"></script>   
   
    <!-- Custom js-->
    <script src="js/custom.js"></script>
  <!--=============================================== 
    Template Design By WpFreeware Team.
    Author URI : http://www.wpfreeware.com/
  ====================================================-->
  </body>
  </html>
<!DOCTYPE html>
<html lang="en">
 <head>
  <?php include 'php/head.php';?>
</head>
  <body> 

    <!-- SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#"></a>
    <!-- END SCROLL TOP BUTTON -->

    <!--=========== BEGIN HEADER SECTION ================-->
        <?php include 'php/header.php';?>
    <!--=========== END HEADER SECTION ================--> 

    <!--=========== BEGIN COURSE BANNER SECTION ================-->
    <section id="imgBanner">
      <h2>Computer Science</h2>
    </section>
    <!--=========== END COURSE BANNER SECTION ================-->

    
    <!--=========== BEGIN COURSE BANNER SECTION ================-->
    <section id="courseArchive">
      <div class="container">
        <div class="row">
          <!-- start course content -->
          <div class="col-lg-8 col-md-8 col-sm-8">
            <div class="courseArchive_content">              
             <div class="singlecourse_ferimg_area">
              <div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/place/1.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/place/2.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/place/3.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/place/4.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/place/5.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>
</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span>
  <span class="dot"></span>
</div>
               <!--div class="singlecourse_ferimg">
                 <img src="img/course-single.jpg" alt="img">
               </div>  
                <div class="singlecourse_bottom">
                  <h2>Introduction To Matrix</h2>
                  <span class="singlecourse_author">
                    <img alt="img" src="img/author.jpg">
                    Richard Remus, Teacher
                  </span>
                  <span class="singlecourse_price">$20</span>
                </div-->
             </div></div></div>

              <div class="row">
<div class=" col-sm-8">
       <h1>Placements Till Now</h1>
      <table class="table table-bordered table-responsive">
  <tr>
    <td><strong>YEAR</strong></td>
    <td><strong>NAME OF THE    COMPANY</strong></td>
    <td><strong>Total No of    Students Placed </strong></td>
  </tr>
  <tr>
    <td width="101" rowspan="16" valign="top"><p>2016</p></td>
    <td width="197" nowrap="nowrap"><p>TECH    MAHINDRA</p></td>
    <td width="181" rowspan="16" valign="top"><p>165</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>AGNITIO    SYSTEMS</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>IVTL    INFOVIEW</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>VINAYAK    INFOTECH</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>VURAM    TECHNOLOGY</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>L&amp;T    INFOTECH</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>NEW AGE    SYS SOLUTIONS </p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>HP</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>V DART</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>VIVID    INFOTECH</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>CTS</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>VEE    TECHNOLOGIES</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>HEXAWARE</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>SRIRAM    TRANSPORT</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>ILM</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>FLEXTRONICS</p></td>
  </tr>  
  <tr>
    <td width="101" rowspan="24" valign="top"><p>2015</p></td>
    <td width="197" nowrap="nowrap"><p>HP </p></td>
    <td width="181" rowspan="24" valign="top"><p>289</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>L &amp;    T INFOTECH</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>VERNALIS</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>VIVID</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>ILM</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>TECH    MAHINDRA</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>IVTL</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>CSS    CORP</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>URC    CONSTRUCTION</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>SILICON    PARTNER</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>LGB</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>INFOSYS</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>PLATO    TECHNOLOGIES </p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>INDIA    HEALTH CARE SOLUTIONS </p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>PRIYA    FIRE SAFETY</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>SUN    SOLAIRES</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>WIPRO</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>THYROCARE</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>CEASE    FIRE</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>RAASI </p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>MINDNOTIX</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>NY    SYSTEMS</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>MPHASIS</p></td>
  </tr>
  <tr>
    <td width="197" nowrap="nowrap"><p>Vee    Technologies</p></td>
  </tr>
   <tr>
    <td rowspan="17" width="64">2014</td>
    <td width="275">TECH MAHINDRA</td>
    <td rowspan="17" width="184">234</td>
  </tr>
  <tr>
    <td width="275">CTS</td>
  </tr>
  <tr>
    <td width="275">HP</td>
  </tr>
  <tr>
    <td width="275">L&amp;T Infotech</td>
  </tr>
  <tr>
    <td>DHYAN INFOTECH</td>
  </tr>
  <tr>
    <td>Vernalis System</td>
  </tr>
  <tr>
    <td>Vinayak Info system</td>
  </tr>
  <tr>
    <td>Acheron</td>
  </tr>
  <tr>
    <td>Sanspareil</td>
  </tr>
  <tr>
    <td>Aspire System</td>
  </tr>
  <tr>
    <td>HCL STATE STREET</td>
  </tr>
  <tr>
    <td>KGISL</td>
  </tr>
  <tr>
    <td>Forte Solutions</td>
  </tr>
  <tr>
    <td>CSS Corp</td>
  </tr>
  <tr>
    <td>C Cubed Solutions</td>
  </tr>
  <tr>
    <td>Xerago</td>
  </tr>
  <tr>
    <td>Aee Bee Solutions</td>
  </tr>
<tr>
    <td rowspan="20" width="64">2013</td>
    <td width="275">Inautix</td>
    <td rowspan="20" width="184">230</td>
  </tr>
  <tr>
    <td>Tech Mahindra </td>
  </tr>
  <tr>
    <td>Hexaware</td>
  </tr>
  <tr>
    <td>Dhyan Infotech</td>
  </tr>
  <tr>
    <td>DELL Software</td>
  </tr>
  <tr>
    <td>Global Edge</td>
  </tr>
  <tr>
    <td>Mbit Wireless</td>
  </tr>
  <tr>
    <td>CTS</td>
  </tr>
  <tr>
    <td>American Megatrends</td>
  </tr>
  <tr>
    <td>HCL B Serv</td>
  </tr>
  <tr>
    <td>IBM </td>
  </tr>
  <tr>
    <td>BNP Paribas</td>
  </tr>
  <tr>
    <td>HCL B Serv</td>
  </tr>
  <tr>
    <td>LGB</td>
  </tr>
  <tr>
    <td>C Cubed Solutions</td>
  </tr>
  <tr>
    <td>C Bazzar</td>
  </tr>
  <tr>
    <td>Digital Nirvana</td>
  </tr>
  <tr>
    <td>Fun Dreamz</td>
  </tr>
  <tr>
    <td>FreshDesk</td>
  </tr>
  <tr>
    <td>CSS Corp</td>
  </tr>
 <tr>
    <td rowspan="24" width="64">2012</td>
    <td width="275">HCL  Technologies</td>
    <td rowspan="24" width="184">185</td>
  </tr>
  <tr>
    <td width="275">Hexaware</td>
  </tr>
  <tr>
    <td width="275">Aon hewitt</td>
  </tr>
  <tr>
    <td width="275">Syntel</td>
  </tr>
  <tr>
    <td width="275">Bahwan cybertek</td>
  </tr>
  <tr>
    <td width="275">Indus teqsite pvt ltd, chennai</td>
  </tr>
  <tr>
    <td width="275">American Megatrends</td>
  </tr>
  <tr>
    <td width="275">Financial Software Solutions</td>
  </tr>
  <tr>
    <td width="275">Power Process Engineering</td>
  </tr>
  <tr>
    <td width="275">Aquasub engineering</td>
  </tr>
  <tr>
    <td width="275">L - cube</td>
  </tr>
  <tr>
    <td width="275">NIIT tech ltd</td>
  </tr>
  <tr>
    <td width="275">Suresoft</td>
  </tr>
  <tr>
    <td width="275">C cube</td>
  </tr>
  <tr>
    <td width="275">Bajaj capital</td>
  </tr>
  <tr>
    <td width="275">CSS</td>
  </tr>
  <tr>
    <td width="275">Jaro education</td>
  </tr>
  <tr>
    <td width="275">Steroid soft</td>
  </tr>
  <tr>
    <td width="275">Oxfarm</td>
  </tr>
  <tr>
    <td width="275">Cross fields</td>
  </tr>
  <tr>
    <td width="275">Jaro education(mba)</td>
  </tr>
  <tr>
    <td width="275">India infoline(mba)</td>
  </tr>
  <tr>
    <td width="275">Carolina Technologies</td>
  </tr>
  <tr>
    <td width="275">Microtek pvt ltd</td>
  </tr>
  <tr>
    <td rowspan="23">2011</td>
    <td width="275">L&amp;T    Infotech</td>
    <td rowspan="23">211</td>
  </tr>
  <tr>
    <td width="275">HCL Technologies Ltd.</td>
  </tr>
  <tr>
    <td width="275">Inautix</td>
  </tr>
  <tr>
    <td width="275">Hewlett Packard</td>
  </tr>
  <tr>
    <td width="275">Accenture</td>
  </tr>
  <tr>
    <td width="275">Mahindra Satyam</td>
  </tr>
  <tr>
    <td width="275">Hexaware Technologies Ltd.</td>
  </tr>
  <tr>
    <td width="275">Lucid Imaging</td>
  </tr>
  <tr>
    <td width="275">Syntel</td>
  </tr>
  <tr>
    <td width="275">Temenos</td>
  </tr>
  <tr>
    <td width="275">Cognizant Technology Solutions</td>
  </tr>
  <tr>
    <td width="275">Syntel</td>
  </tr>
  <tr>
    <td width="275">Indus Teqsite Pvt. Ltd. Chennai</td>
  </tr>
  <tr>
    <td width="275">L-Cube Innovative Solutions Ltd.</td>
  </tr>
  <tr>
    <td width="275">Dynpro India Pvt. Ltd. Bangalore</td>
  </tr>
  <tr>
    <td width="275">IFCI Financial Services Pvt. Ltd.</td>
  </tr>
  <tr>
    <td width="275">Sutherland Global Services</td>
  </tr>
  <tr>
    <td width="275">Procon Advisory Services India Pvt. Ltd.</td>
  </tr>
  <tr>
    <td width="275">ICICI Prudential Life Insurance </td>
  </tr>
  <tr>
    <td width="275">Cybernet Slash Support </td>
  </tr>
  <tr>
    <td width="275">HCL B-Serv</td>
  </tr>
  <tr>
    <td width="275">Allsec Technologies</td>
  </tr>
  <tr>
    <td width="275">Spinach</td>
  </tr>
</table></div>
             <script>
var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 1000); // Change image every 2 seconds
}
</script>

             <!-- start related course -->
             <!--div class="related_course">
                <h2>More Courses</h2>
                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="single_course wow fadeInUp" >
                      <div class="singCourse_imgarea">
                        <img src="img/course-1.jpg">
                        <div class="mask">                         
                          <a class="course_more" href="#">View Course</a>
                        </div>
                      </div>
                      <div class="singCourse_content">
                        <h3 class="singCourse_title"><a href="#">Introduction To Matrix</a></h3>
                        <p class="singCourse_price"><span>$20</span> Per One Month</p>
                        <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
                      </div>
                      <div class="singCourse_author">
                        <img alt="img" src="img/author.jpg">
                        <p>Richard Remus, Teacher</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="single_course wow fadeInUp" >
                      <div class="singCourse_imgarea">
                        <img src="img/course-1.jpg">
                        <div class="mask">                         
                          <a class="course_more" href="#">View Course</a>
                        </div>
                      </div>
                      <div class="singCourse_content">
                        <h3 class="singCourse_title"><a href="#">Introduction To Matrix</a></h3>
                        <p class="singCourse_price"><span>$20</span> Per One Month</p>
                        <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
                      </div>
                      <div class="singCourse_author">
                        <img alt="img" src="img/author.jpg">
                        <p>Richard Remus, Teacher</p>
                      </div>
                    </div>
                  </div>                                    
                </div>
              </div-->
              <!-- End related course -->
          <!-- End course content -->

          <!-- start course archive sidebar -->
          <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="courseArchive_sidebar">
              <!-- start single sidebar -->
              <!--div class="single_sidebar">
                <h2>Events <span class="fa fa-angle-double-right"></span></h2>
                <ul class="news_tab">
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a href="#" class="news_img">
                          <img alt="img" src="img/news.jpg" class="media-object">
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Dummy text of the printing and typesetting industry</a>
                       <span class="feed_date">27.02.15</span>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a href="#" class="news_img">
                          <img alt="img" src="img/news.jpg" class="media-object">
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Dummy text of the printing and typesetting industry</a>
                       <span class="feed_date">28.02.15</span>                
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a href="#" class="news_img">
                          <img alt="img" src="img/news.jpg" class="media-object">
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Dummy text of the printing and typesetting industry</a>
                       <span class="feed_date">28.02.15</span>                
                      </div>
                    </div>
                  </li>                  
                </ul>
              </div-->
              <!-- End single sidebar -->
              <!-- start single sidebar -->
              <div class="single_sidebar" >
                <h2>Placements <span class="fa fa-angle-double-right"></span></h2>
                <ul>
                  <li><a href="our.php">Our Recruiters</a></li>
                  <li><a href="ptn.php">Placements Till Now</a></li>
                   <li><a href="trainning.php">Training</a></li>
                  <li><a href="contact.php">Contact PCDC</a></li>
                </ul>
              </div>
              <!-- End single sidebar -->
              <!-- start single sidebar -->
              <!--div class="single_sidebar">
                <h2>Sponsor Add <span class="fa fa-angle-double-right"></span></h2>
                <a class="side_add" href="#"><img src="img/side-add.jpg" alt="img"></a>
              </div-->
              <!-- End single sidebar -->
            </div>
          </div>
          <!-- start course archive sidebar -->
        </div>
      </div>
    </section>
    <!--=========== END COURSE BANNER SECTION ================-->
    
    <!--=========== BEGIN FOOTER SECTION ================-->
   <?php include 'php/footer.php';?>
    <!--=========== END FOOTER SECTION ================--> 

  

    <!-- Javascript Files
    ================================================== -->

    <!-- initialize jQuery Library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <!-- Preloader js file -->
    <script src="js/queryloader2.min.js" type="text/javascript"></script>
    <!-- For smooth animatin  -->
    <script src="js/wow.min.js"></script>  
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- slick slider -->
    <script src="js/slick.min.js"></script>
    <!-- superslides slider -->
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.animate-enhanced.min.js"></script>
    <script src="js/jquery.superslides.min.js" type="text/javascript" charset="utf-8"></script>   
    <!-- for circle counter -->
    <script src='https://cdn.rawgit.com/pguso/jquery-plugin-circliful/master/js/jquery.circliful.min.js'></script>
    <!-- Gallery slider -->
    <script type="text/javascript" language="javascript" src="js/jquery.tosrus.min.all.js"></script>   
   
    <!-- Custom js-->
    <script src="js/custom.js"></script>
  <!--=============================================== 
    Template Design By WpFreeware Team.
    Author URI : http://www.wpfreeware.com/
  ====================================================-->

  </body>
</html>
<!DOCTYPE html>
<html lang="en">
 <head>
  <?php include 'php/head.php';?>
</head>
  <body>
     <!-- SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#"></a>
    <!-- END SCROLL TOP BUTTON -->

    <!--=========== BEGIN HEADER SECTION ================-->
    <?php include 'php/header.php';?>
    <!--=========== END HEADER SECTION ================--> 
    <section id="imgBanner">
      <h2>Master of Business Administration</h2>
    </section>
    <!--=========== END COURSE BANNER SECTION ================-->

    
    <!--=========== BEGIN COURSE BANNER SECTION ================-->
    <section id="courseArchive">
      <div class="container">
        <div class="row">
          <!-- start course content -->
          <div class="col-lg-8 col-md-8 col-sm-8">
            <div class="courseArchive_content">              
             <div class="singlecourse_ferimg_area">
              <div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/pg/1.jpg" style="width:100%">
  <div class="text">THE CHANAKYAS OF BUSINESS</div>
</div>

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/pg/2.jpg" style="width:100%">
  <div class="text">THE CHANAKYAS OF BUSINESS</div>
</div>
</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 

</div>
               <!--div class="singlecourse_ferimg">
                 <img src="img/course-single.jpg" alt="img">
               </div>  
                <div class="singlecourse_bottom">
                  <h2>Introduction To Matrix</h2>
                  <span class="singlecourse_author">
                    <img alt="img" src="img/author.jpg">
                    Richard Remus, Teacher
                  </span>
                  <span class="singlecourse_price">$20</span>
                </div-->
             </div>
             <div class="single_course_content">
                <div class="inner department">
<div class="btn-group btn-group-sm" style="padding-bottom:20px;">
        <a class="btn  btn-primary " href="#">2011 - 2013 </a>
        <a class="btn  btn-primary btn-warning" href="mba3(1).php">2010 - 2012 </a>
        <a class="btn  btn-primary " href="mba3(2).php">2009 - 2011  </a>
        <a class="btn  btn-primary " href="mba3(3).php">2008 - 2010   </a>
        <a class="btn  btn-primary " href="mba3(4).php">2007 - 2009  </a>
      </div>      <h1>2010 - 2012 Batch</h1>
      <table class="table table-bordered table-responsive">
<thead>
 <tr>
    <td>S.No.</td>
    <td>Register No./Roll No.</td>
    <td>Name</td>
    <td>E-mail id</td>
  </tr></thead>
  <tr>
    <td>1</td>
    <td>10MB01</td>
    <td>AKHIL .T</td>
    <td>akhilthilakan@yahoo.com</td>
  </tr>
  <tr>
    <td>2</td>
    <td>10MB02</td>
    <td>AMBIKA .K</td>
    <td>ambika143@ymail.com</td>
  </tr>
  <tr>
    <td>3</td>
    <td>10MB03</td>
    <td>AMSADEVI .R</td>
    <td></td>
  </tr>
  <tr>
    <td>4</td>
    <td>10MB04</td>
    <td>APARNA. A</td>
    <td>aparnasudha136@gmail.com</td>
  </tr>
  <tr>
    <td>5</td>
    <td>10MB05</td>
    <td>ARIVALAGAN .M</td>
    <td>arivu0002@yahoo.co.in</td>
  </tr>
  <tr>
    <td>6</td>
    <td>10MB06</td>
    <td>ARPUTHA RAJAN JACOB</td>
    <td>ajacup@gmail.com</td>
  </tr>
  <tr>
    <td>7</td>
    <td>10MB07</td>
    <td>ARUN .P</td>
    <td>p_arun_90@yahoo.co.in</td>
  </tr>
  <tr>
    <td>8</td>
    <td>10MB08</td>
    <td>BHUVANESHWARI .S</td>
    <td>sinha.868@gmail.com</td>
  </tr>
  <tr>
    <td>9</td>
    <td>10MB09</td>
    <td>BIBIN JAMES</td>
    <td>johnyjameskallar@gmail.com</td>
  </tr>
  <tr>
    <td>10</td>
    <td>10MB10</td>
    <td>DINESH KUMAR .V</td>
    <td>bcadinesh@gamil.com</td>
  </tr>
  <tr>
    <td>11</td>
    <td>10MB11</td>
    <td>ELAMPARITHY .T</td>
    <td>parithy9942@gmail.com</td>
  </tr>
  <tr>
    <td>12</td>
    <td>10MB12</td>
    <td>GOKULPRASAD .R</td>
    <td>gokulprasad27@gmail.com</td>
  </tr>
  <tr>
    <td>13</td>
    <td>10MB13</td>
    <td>GOPI .R</td>
    <td></td>
  </tr>
  <tr>
    <td>14</td>
    <td>10MB14</td>
    <td>GOWTHAMI .R</td>
    <td>gowthami@gmail.com</td>
  </tr>
  <tr>
    <td>15</td>
    <td>10MB15</td>
    <td>HEMALATHA .D</td>
    <td>chittu.ammu@gmail.com</td>
  </tr>
  <tr>
    <td>16</td>
    <td>10MB16</td>
    <td>JAYAPRAKASH.M</td>
    <td>jpmkps@yahoo.com</td>
  </tr>
  <tr>
    <td>17</td>
    <td>10MB17</td>
    <td>JEEVANANDHAM .S</td>
    <td>jeevasoundhar90@gamil.com</td>
  </tr>
  <tr>
    <td>18</td>
    <td>10MB18</td>
    <td>JESTIN JOSEPH</td>
    <td>jestinjoseph100@gmail.com</td>
  </tr>
  <tr>
    <td>19</td>
    <td>10MB19</td>
    <td>JILNESH .C</td>
    <td>jilnesh@gmail.com</td>
  </tr>
  <tr>
    <td>20</td>
    <td>10MB20</td>
    <td>KARTHICK .M</td>
    <td>MKARTHICK271@GMAIL.COM</td>
  </tr>
  <tr>
    <td>21</td>
    <td>10MB21</td>
    <td>KARTHIKEYAN .B</td>
    <td>kasugan@gmail.com</td>
  </tr>
  <tr>
    <td>22</td>
    <td>10MB22</td>
    <td>KARTHIKEYAN. D</td>
    <td>tamil_dk@yahoo.co.in</td>
  </tr>
  <tr>
    <td>23</td>
    <td>10MB23</td>
    <td>KARTHIKEYAN .M</td>
    <td>mailingtokarthik@yahoo.com</td>
  </tr>
  <tr>
    <td>24</td>
    <td>10MB24</td>
    <td>KASTHURI .C</td>
    <td>kasthurisekkar@gmail.com</td>
  </tr>
  <tr>
    <td>25</td>
    <td>10MB25</td>
    <td>KISHORE .S</td>
    <td>KISHOREBLOSSOMS@GMAIL.COM</td>
  </tr>
  <tr>
    <td>26</td>
    <td>10MB26</td>
    <td>MAHENDRAN .A</td>
    <td>SMILEFACE015@GMAIL.COM</td>
  </tr>
  <tr>
    <td>27</td>
    <td>10MB27</td>
    <td>MANOJ.J</td>
    <td>MANOBIYU@YAHOO.COM</td>
  </tr>
  <tr>
    <td>28</td>
    <td>10MB28</td>
    <td>MATHIYALAGAN .V</td>
    <td>mathi@yahoo.com</td>
  </tr>
  <tr>
    <td>29</td>
    <td>10MB29</td>
    <td>MEHALA</td>
    <td>jo.mehala@gmail.com</td>
  </tr>
  <tr>
    <td>30</td>
    <td>10MB30</td>
    <td>MENAGA. A</td>
    <td>sugamena@yahoo.co.in</td>
  </tr>
  <tr>
    <td>31</td>
    <td>10MB31</td>
    <td>MUTHUKUMAR. B</td>
    <td>kuttykumar.93@gmail.com</td>
  </tr>
  <tr>
    <td>32</td>
    <td>10MB32</td>
    <td>MUTHU KUMAR .V</td>
    <td></td>
  </tr>
  <tr>
    <td>33</td>
    <td>10MB33</td>
    <td>NAVEEN KUMAR .B</td>
    <td>naveensb19@gmail.com</td>
  </tr>
  <tr>
    <td>34</td>
    <td>10MB34</td>
    <td>NIRMALA .K</td>
    <td>nirmalakvk@yahoo.co.in</td>
  </tr>
  <tr>
    <td>35</td>
    <td>10MB35</td>
    <td>NITHYA. D</td>
    <td>nithyathayalan@yahoo.com</td>
  </tr>
  <tr>
    <td>36</td>
    <td>10MB36</td>
    <td>NITHYA. P</td>
    <td>1.nithiii@gmail.com</td>
  </tr>
  <tr>
    <td>37</td>
    <td>10MB37</td>
    <td>PALANI .M</td>
    <td>shinepalani037@gmail.com</td>
  </tr>
  <tr>
    <td>38</td>
    <td>10MB38</td>
    <td>PRAKASH .A</td>
    <td>prakeshpyaar@gmail.com</td>
  </tr>
  <tr>
    <td>39</td>
    <td>10MB39</td>
    <td>PRATHEEP .S</td>
    <td>PRATHEEP_SRP@YAHOO.COM</td>
  </tr>
  <tr>
    <td>40</td>
    <td>10MB40</td>
    <td>RAJESH. B </td>
    <td>BRAJESH.2248@GMAIL.COM</td>
  </tr>
  <tr>
    <td>41</td>
    <td>10MB41</td>
    <td>RAJ KUMAR. K </td>
    <td>rajuroobi@gmail.com</td>
  </tr>
  <tr>
    <td>42</td>
    <td>10MB42</td>
    <td>RAMESH .V.S</td>
    <td>rameshcbi@rocketmail.com</td>
  </tr>
  <tr>
    <td>43</td>
    <td>10MB43</td>
    <td>SADEESH KUMAR .U</td>
    <td></td>
  </tr>
  <tr>
    <td>44</td>
    <td>10MB44</td>
    <td>SARAVANAN .R</td>
    <td>sarvaans@gmail.com</td>
  </tr>
  <tr>
    <td>45</td>
    <td>10MB45</td>
    <td>SARGUNAM .S</td>
    <td>sargi.rocks@gmail.com</td>
  </tr>
  <tr>
    <td>46</td>
    <td>10MB46</td>
    <td>SATHISH KUMAR .C.P</td>
    <td>savee1810@gmail.com</td>
  </tr>
  <tr>
    <td>47</td>
    <td>10MB47</td>
    <td>SELVACHITHAMBARAM .B</td>
    <td>bselvac@gmail.com</td>
  </tr>
  <tr>
    <td>48</td>
    <td>10MB48</td>
    <td>SHARAVANAN .P</td>
    <td>getsaro@gmail.com</td>
  </tr>
  <tr>
    <td>49</td>
    <td>10MB49</td>
    <td>SHARMILA .K</td>
    <td>ksharmila.kaa@gmail.com</td>
  </tr>
  <tr>
    <td>50</td>
    <td>10MB50</td>
    <td>SINDHU .C</td>
    <td>sindhu.hariss@yahoo.com</td>
  </tr>
  <tr>
    <td>51</td>
    <td>10MB51</td>
    <td>SOMASUNDARAM .S</td>
    <td>SOMU31@YAHOO.COM</td>
  </tr>
  <tr>
    <td>52</td>
    <td>10MB52</td>
    <td>SRIDHAR .G</td>
    <td>skpgsri@gmail.com</td>
  </tr>
  <tr>
    <td>53</td>
    <td>10MB53</td>
    <td>SRINIVASAN .K.G</td>
    <td>sriniganeshkg@gmail.com</td>
  </tr>
  <tr>
    <td>54</td>
    <td>10MB54</td>
    <td>THIRUKUMARAN.N</td>
    <td>vthiruilee@yahoo.com</td>
  </tr>
  <tr>
    <td>55</td>
    <td>10MB55</td>
    <td>TIBIN JOSEPH</td>
    <td>tibin4you@gmail.com</td>
  </tr>
  <tr>
    <td>56</td>
    <td>10MB56</td>
    <td>VADIVEL .K</td>
    <td>vimalvelbca@yahoo.com</td>
  </tr>
  <tr>
    <td>57</td>
    <td>10MB57</td>
    <td>YASOTHA .N</td>
    <td></td>
  </tr>
  <tr>
    <td>58</td>
    <td>10MB58</td>
    <td>YOGESHWARI .S</td>
    <td>venn.yoyo@gmail.com</td>
  </tr>
  <tr>
    <td>59</td>
    <td>10MB59</td>
    <td>YUVARAJ .M</td>
    <td>yuva.raj20@yahoo.com</td>
  </tr>
  <tr>
    <td>60</td>
    <td>10MB60</td>
    <td>YUVARAJ .M</td>
    <td>yuvarajmani89@gmail.com</td>
  </tr>
</table>
  </div>

             
               <!--table class="table table-striped course_table">
                <thead>
                  <tr>          
                    <th>Course Title</th>
                    <th>Instructor</th>
                    <th>Timing</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>          
                    <td><a href="#">Computer Science &amp; Engineering</a></td>
                    <td>Dr. Steve Palmer</td>
                    <td>08:00 to 13:00</td>
                  </tr>
                  <tr>
                    <td><a href="#">Electronics &amp; Communications Engineering</a></td>          
                    <td>Jacob</td>                    
                    <td>08:00 to 13:00</td>
                  </tr>
                  <tr>
                    <td><a href="#">Civil Engineering</a></td>          
                    <td>Kimberly Jones</td>                    
                    <td>08:00 to 13:00</td>
                  </tr>
                  <tr>
                    <td><a href="#">Electrical &amp; Electronics Engineering</a></td>   

                    <td>Dr. Klee</td>                    
                    <td>08:00 to 13:00</td>
                  </tr>
                  <tr><td><a href="#">Mechanical Engineering</a></td> </tr>
                </tbody>
              </table-->
             </div>
             <script>
var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 1000); // Change image every 2 seconds
}
</script>

             <!-- start related course -->
             <!--div class="related_course">
                <h2>More Courses</h2>
                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="single_course wow fadeInUp" >
                      <div class="singCourse_imgarea">
                        <img src="img/course-1.jpg">
                        <div class="mask">                         
                          <a class="course_more" href="#">View Course</a>
                        </div>
                      </div>
                      <div class="singCourse_content">
                        <h3 class="singCourse_title"><a href="#">Introduction To Matrix</a></h3>
                        <p class="singCourse_price"><span>$20</span> Per One Month</p>
                        <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
                      </div>
                      <div class="singCourse_author">
                        <img alt="img" src="img/author.jpg">
                        <p>Richard Remus, Teacher</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="single_course wow fadeInUp" >
                      <div class="singCourse_imgarea">
                        <img src="img/course-1.jpg">
                        <div class="mask">                         
                          <a class="course_more" href="#">View Course</a>
                        </div>
                      </div>
                      <div class="singCourse_content">
                        <h3 class="singCourse_title"><a href="#">Introduction To Matrix</a></h3>
                        <p class="singCourse_price"><span>$20</span> Per One Month</p>
                        <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
                      </div>
                      <div class="singCourse_author">
                        <img alt="img" src="img/author.jpg">
                        <p>Richard Remus, Teacher</p>
                      </div>
                    </div>
                  </div>                                    
                </div>
              </div-->
              <!-- End related course -->
            </div>
          </div>
          <!-- End course content -->

          <!-- start course archive sidebar -->
          <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="courseArchive_sidebar">
              <!-- start single sidebar -->
              <!--div class="single_sidebar">
                <h2>Events <span class="fa fa-angle-double-right"></span></h2>
                <ul class="news_tab">
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a href="#" class="news_img">
                          <img alt="img" src="img/news.jpg" class="media-object">
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Dummy text of the printing and typesetting industry</a>
                       <span class="feed_date">27.02.15</span>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a href="#" class="news_img">
                          <img alt="img" src="img/news.jpg" class="media-object">
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Dummy text of the printing and typesetting industry</a>
                       <span class="feed_date">28.02.15</span>                
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a href="#" class="news_img">
                          <img alt="img" src="img/news.jpg" class="media-object">
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Dummy text of the printing and typesetting industry</a>
                       <span class="feed_date">28.02.15</span>                
                      </div>
                    </div>
                  </li>                  
                </ul>
              </div-->
              <!-- End single sidebar -->
              <!-- start single sidebar -->
              <div class="single_sidebar">
                <a href="#" class="list-group-item" style="background:#dcb305; color:#000; font-size:15px;">Master of Business Administration</a>
                 <a href="mba.php" class="list-group-item ">About the Department</a>
                 <a href="mba1.php" class="list-group-item ">Association Activities</a>
                 <a href="mba2.php" class="list-group-item ">Laurels Won by Students</a>
                 <a href="mba3.php" class="list-group-item active">Alumni Students</a>
                 <a href="mba4.php" class="list-group-item ">E-Course Material</a>  
                 <a href="http://nptel.ac.in/course.php?disciplineId=110" class="list-group-item" target="_blank">NPTEL VIDEO</a> 
              </div>
              <!-- End single sidebar -->
              <!-- start single sidebar -->
              <!--div class="single_sidebar">
                <h2>Sponsor Add <span class="fa fa-angle-double-right"></span></h2>
                <a class="side_add" href="#"><img src="img/side-add.jpg" alt="img"></a>
              </div-->
              <!-- End single sidebar -->
            </div>
          </div>
          <!-- start course archive sidebar -->
        </div>
      </div>
    </section>

     <!--=========== BEGIN FOOTER SECTION ================-->
  <?php include 'php/footer.php';?>
    <!--=========== END FOOTER SECTION ================--> 

  

    <!-- Javascript Files
    ================================================== -->

    <!-- initialize jQuery Library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <!-- Preloader js file -->
    <script src="js/queryloader2.min.js" type="text/javascript"></script>
    <!-- For smooth animatin  -->
    <script src="js/wow.min.js"></script>  
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- slick slider -->
    <script src="js/slick.min.js"></script>
    <!-- superslides slider -->
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.animate-enhanced.min.js"></script>
    <script src="js/jquery.superslides.min.js" type="text/javascript" charset="utf-8"></script>   
    <!-- for circle counter -->
    <script src='https://cdn.rawgit.com/pguso/jquery-plugin-circliful/master/js/jquery.circliful.min.js'></script>
    <!-- Gallery slider -->
    <script type="text/javascript" language="javascript" src="js/jquery.tosrus.min.all.js"></script>   
   
    <!-- Custom js-->
    <script src="js/custom.js"></script>
  <!--=============================================== 
    Template Design By WpFreeware Team.
    Author URI : http://www.wpfreeware.com/
  ====================================================-->
  </body>
  </html>
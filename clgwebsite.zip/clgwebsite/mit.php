<!DOCTYPE html>
<html lang="en">
  <head>
  <?php include 'php/head.php';?>
</head>
  <body>
     <!-- SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#"></a>
    <!-- END SCROLL TOP BUTTON -->

    <!--=========== BEGIN HEADER SECTION ================-->
    <?php include 'php/header.php';?>
    <!--=========== END HEADER SECTION ================--> 
    <section id="imgBanner">
      <h2>Master of Business Administration</h2>
    </section>
    <!--=========== END COURSE BANNER SECTION ================-->

    
    <!--=========== BEGIN COURSE BANNER SECTION ================-->
    <section id="courseArchive">
      <div class="container">
        <div class="row">
          <!-- start course content -->
          <div class="col-xs-12 col-lg-9">
            <div class="courseArchive_content">              
             <div class="singlecourse_ferimg_area">
              <div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/s/1.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/s/2.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/s/3.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/s/4.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/s/5.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>
</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 

</div></div></div></div>

               <!--div class="singlecourse_ferimg">
                 <img src="img/course-single.jpg" alt="img">
               </div>  
                <div class="singlecourse_bottom">
                  <h2>Introduction To Matrix</h2>
                  <span class="singlecourse_author">
                    <img alt="img" src="img/author.jpg">
                    Richard Remus, Teacher
                  </span>
                  <span class="singlecourse_price">$20</span>
                </div-->
             </div>
             <div class="row">
<div class="col-xs-12 col-sm-9">
  
       <h1>M.Tech. Information Technology</h1>
<h3 class="page-header">Thoery and Practicals</h3> 
<ul class="list">
  <li>Applied Probability and Statistics</li>
  <li>Advanced Data Structures and Algorithms</li>
  <li>Multicore Architectures</li>
  <li>Internetworking Technologies</li>
  <li>Object Oriented Software Engineering</li>
  <li>Advanced Databases</li>
  <li>Advanced Data Structures Laboratory</li>
  <li>Internetworking Laboratory</li>
  <li>Mini Project</li>
  <li>Web Technologies</li>
  <li>Cloud Computing</li>
  <li>Network and Information Security</li>
  <li>Data Warehousing and Data Mining</li>
  <li>Elective I</li>
  <li>Elective II</li>
  <li>Web Technology Laboratory</li>
  <li>Cloud Computing Laboratory</li>
  <li>Technical Seminar</li>
  <li>Soft Computing</li>
  <li>Elective III</li>
  <li>Elective IV</li>
  <li>Project Work (Phase I)</li>
  <li>Project Work (Phase II)</li>
</ul>    
<h3 class="page-header">Electives</h3>
<ul class="list">
  <li>Software Metrics and Reliability</li>
  <li>Network Management</li>
  <li>Bio Informatics</li>
  <li>XML and Web Services</li>
  <li>Enterprise Application Integration</li>
  <li>Video Analytics</li>
  <li>Software Project Management</li>
  <li>Mobile and Pervasive Computing</li>
  <li>Principles of Programming Languages</li>
  <li>Multimedia Technologies</li>
  <li>Automata Theory and Compiler Design</li>
  <li>Big Data Analytics</li>
  <li>Software Quality and Testing</li>
  <li>Wireless Adhoc and Sensor Networks</li>
  <li>Web Mining</li>
  <li>Image Processing and Pattern Analysis</li>
  <li>Intelligent Agents</li>
  <li>Internet of Things</li>
  <li>Web Engineering</li>
  <li>Parallel Programming Paradigms</li>
  <li>Social Network Analysis</li>
  <li>Knowledge Engineering</li>
  <li>Energy Aware Computing</li>
  <li>4G Technologies</li>
  <li>Performance Evaluation of Computer Systems</li>
</ul>
<h3 class="page-header">Programme Educational Objectives (PEOs)</h3>
<ol>
<li><strong>Core competency</strong></li>
<p>To apply their basic knowledge in Mathematics, Science and
Engineering and to expose to the recent Information Technologies to
analyze and solve real world problems.
</p>
<li><strong>Innovation</strong></li>
<p>To  be competent in the IT segments and to bring out novel ideas by
exploring  the multiple solutions for the given problem.
<p>
<li><strong>AdaptiveLearning</strong></li>
<p>To engage in sustained learning for the career opportunities in
industries, research divisions, and academics so that they can adapt
to ever-changing technological and societal requirements.

<p>
<li><strong>Team spirit </strong></li>
<p>To mould the students to be ethically committed towards team work
for producing quality output with the aim of developing our nation.

<p>
</ol>
<h3 class="page-header">
Programme Outcomes (POS)
</h3>
<p>1. An ability to apply knowledge of mathematics, science and information science
in advance level</p>
<p>2.
An ability to design a Information system with components and processes to
meet desired needs within realistic constraints such as economic,
environmental, social, political, ethical, health and safety, manufacturability,
and sustainability</p>
<p>3. An ability to identify and modify the functions of the internals of information
processing system
<p>4. An ability to apply Software Engineering principles, techniques and tools in
software development</p>
<p>5. An ability to create, collect, process, view, organize, store, mine and retrieve
information both in local and remote locations in a secure and effective manner</p>
<p>6. An ability to design and conduct experiments, as well as to analyze and
interpret information to lay a foundation for solving complex problems</p>
<p>7. An ability to engage in life-long learning to acquire knowledge of contemporary
issues in IT domain to meet the challenges in the career</p>
<p>8.
An ability to apply the skills and techniques in information technology and interdisciplinary
domains for providing solutions in a global, economic, environmental,
and societal context</p>
<p>9. An ability to develop IT research skills and innovative ideas</p>
<p>10. An ability to model the IT real world problems and to address and share the
research issues</p>
<p>11. An ability to share their IT knowledge and express their ideas in any technical
forum</p>
<p>12. An ability to present their ideas to prepare for a position to educate and guide others.</p>

    </div>
               <!--table class="table table-striped course_table">
                <thead>
                  <tr>          
                    <th>Course Title</th>
                    <th>Instructor</th>
                    <th>Timing</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>          
                    <td><a href="#">Computer Science &amp; Engineering</a></td>
                    <td>Dr. Steve Palmer</td>
                    <td>08:00 to 13:00</td>
                  </tr>
                  <tr>
                    <td><a href="#">Electronics &amp; Communications Engineering</a></td>          
                    <td>Jacob</td>                    
                    <td>08:00 to 13:00</td>
                  </tr>
                  <tr>
                    <td><a href="#">Civil Engineering</a></td>          
                    <td>Kimberly Jones</td>                    
                    <td>08:00 to 13:00</td>
                  </tr>
                  <tr>
                    <td><a href="#">Electrical &amp; Electronics Engineering</a></td>   

                    <td>Dr. Klee</td>                    
                    <td>08:00 to 13:00</td>
                  </tr>
                  <tr><td><a href="#">Mechanical Engineering</a></td> </tr>
                </tbody>
              </table-->
             </div>
             <script>
var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 1000); // Change image every 2 seconds
}
</script>

             <!-- start related course -->
             <!--div class="related_course">
                <h2>More Courses</h2>
                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="single_course wow fadeInUp" >
                      <div class="singCourse_imgarea">
                        <img src="img/course-1.jpg">
                        <div class="mask">                         
                          <a class="course_more" href="#">View Course</a>
                        </div>
                      </div>
                      <div class="singCourse_content">
                        <h3 class="singCourse_title"><a href="#">Introduction To Matrix</a></h3>
                        <p class="singCourse_price"><span>$20</span> Per One Month</p>
                        <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
                      </div>
                      <div class="singCourse_author">
                        <img alt="img" src="img/author.jpg">
                        <p>Richard Remus, Teacher</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="single_course wow fadeInUp" >
                      <div class="singCourse_imgarea">
                        <img src="img/course-1.jpg">
                        <div class="mask">                         
                          <a class="course_more" href="#">View Course</a>
                        </div>
                      </div>
                      <div class="singCourse_content">
                        <h3 class="singCourse_title"><a href="#">Introduction To Matrix</a></h3>
                        <p class="singCourse_price"><span>$20</span> Per One Month</p>
                        <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
                      </div>
                      <div class="singCourse_author">
                        <img alt="img" src="img/author.jpg">
                        <p>Richard Remus, Teacher</p>
                      </div>
                    </div>
                  </div>                                    
                </div>
              </div-->
              <!-- End related course -->
            </div>
          
          <!-- End course content -->

          <!-- start course archive sidebar -->
          
              <!-- start single sidebar -->
              <!--div class="single_sidebar">
                <h2>Events <span class="fa fa-angle-double-right"></span></h2>
                <ul class="news_tab">
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a href="#" class="news_img">
                          <img alt="img" src="img/news.jpg" class="media-object">
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Dummy text of the printing and typesetting industry</a>
                       <span class="feed_date">27.02.15</span>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a href="#" class="news_img">
                          <img alt="img" src="img/news.jpg" class="media-object">
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Dummy text of the printing and typesetting industry</a>
                       <span class="feed_date">28.02.15</span>                
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a href="#" class="news_img">
                          <img alt="img" src="img/news.jpg" class="media-object">
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Dummy text of the printing and typesetting industry</a>
                       <span class="feed_date">28.02.15</span>                
                      </div>
                    </div>
                  </li>                  
                </ul>
              </div-->
              <!-- End single sidebar -->
              <!-- start single sidebar -->
            
              <!-- End single sidebar -->
              <!-- start single sidebar -->
              <!--div class="single_sidebar">
                <h2>Sponsor Add <span class="fa fa-angle-double-right"></span></h2>
                <a class="side_add" href="#"><img src="img/side-add.jpg" alt="img"></a>
              </div-->
              <!-- End single sidebar -->
            </div>
          </div>
          <!-- start course archive sidebar -->
        </div>
      </div>
    </section>

     <!--=========== BEGIN FOOTER SECTION ================-->
    <?php include 'php/footer.php';?>
    <!--=========== END FOOTER SECTION ================--> 

  

    <!-- Javascript Files
    ================================================== -->

    <!-- initialize jQuery Library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <!-- Preloader js file -->
    <script src="js/queryloader2.min.js" type="text/javascript"></script>
    <!-- For smooth animatin  -->
    <script src="js/wow.min.js"></script>  
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- slick slider -->
    <script src="js/slick.min.js"></script>
    <!-- superslides slider -->
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.animate-enhanced.min.js"></script>
    <script src="js/jquery.superslides.min.js" type="text/javascript" charset="utf-8"></script>   
    <!-- for circle counter -->
    <script src='https://cdn.rawgit.com/pguso/jquery-plugin-circliful/master/js/jquery.circliful.min.js'></script>
    <!-- Gallery slider -->
    <script type="text/javascript" language="javascript" src="js/jquery.tosrus.min.all.js"></script>   
   
    <!-- Custom js-->
    <script src="js/custom.js"></script>
  <!--=============================================== 
    Template Design By WpFreeware Team.
    Author URI : http://www.wpfreeware.com/
  ====================================================-->
  </body>
  </html>
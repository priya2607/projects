<!DOCTYPE html>
<html lang="en">
  <head>
  <?php include 'php/head.php';?>
</head>
  <body>
     <!-- SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#"></a>
    <!-- END SCROLL TOP BUTTON -->

    <!--=========== BEGIN HEADER SECTION ================-->
         <?php include 'php/header.php';?>
    <!--=========== END HEADER SECTION ================--> 
    <section id="imgBanner">
      <h2>Admission</h2>
    </section>
    <!--=========== END COURSE BANNER SECTION ================-->

    
    <!--=========== BEGIN COURSE BANNER SECTION ================-->
    <section id="courseArchive">
      <div class="container">
        <div class="row">
          <!-- start course content -->
          <div class="col-lg-8 col-md-8 col-sm-8">
            <div class="courseArchive_content">              
             <div class="singlecourse_ferimg_area">
              <div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/index/1.jpg" style="width:100%">
  <div class="text"></div>
</div>

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/index/2.jpg" style="width:100%">
  <div class="text"></div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/index/3.jpg" style="width:100%">
  <div class="text"></div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/index/4.jpg" style="width:100%">
  <div class="text"></div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/index/5.jpg" style="width:100%">
  <div class="text"></div>
</div>
</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
   <span class="dot"></span> 
  <span class="dot"></span>
</div></div>
               <!--div class="singlecourse_ferimg">
                 <img src="img/course-single.jpg" alt="img">
               </div>  
                <div class="singlecourse_bottom">
                  <h2>Introduction To Matrix</h2>
                  <span class="singlecourse_author">
                    <img alt="img" src="img/author.jpg">
                    Richard Remus, Teacher
                  </span>
                  <span class="singlecourse_price">$20</span>
                </div-->
            <div class="row">
<div class="col-xs-12 col-sm-12">
  <div class=" inner"> 
    <div class=""> 
      <h1>Scholarships</h1>
      <h3 class="page-header">Scholarships under  Government Schemes</h3>
<table class="table table-bordered table-responsive">
  <tr>
    <td width="194"><strong>Scholarships    Scheme</strong></strong></td>
    <td width="172"><strong>Address</strong></strong></td>
    <td width="118"><strong>Eligibility</strong></strong></td>
    <td width="185"><strong>Contact    Details/Website/Email address</strong></strong></td>
  </tr>
  <tr>
    <td width="194">Government Scholarship</td>
    <td width="172">The District Welfare Officer,<br />
      BC/MBC Welfare Department, Tiruppur.</td>
    <td width="118">BC / MBC – SWS only<br />
      Parent Annual Income <br />
      should be less than 2,00,000/-</td>
    <td width="185" valign="top"><a href="http://www.edistrict.tn.gov.in" target="_blank">www.edistrict.tn.gov.in </a>Apply through college</td>
  </tr>
  <tr>
    <td width="194">Government Scholarship</td>
    <td width="172">The District Welfare Officer,<br />
      Adi Dravidar Welfare Department, Tiruppur.</td>
    <td width="118">SC / ST – SWS only<br />
      Parent Annual Income <br />
      should be less than 3,00,000/-</td>
    <td width="185" valign="top"><a href="http://www.edistrict.tn.gov.in" target="_blank">www.edistrict.tn.gov.in</a> Apply through college</td>
  </tr>
  <tr>
    <td width="194">Government Scholarship (SC/ST Fee    waiver scheme) 100% free</td>
    <td width="172">The District Welfare Officer,<br />
      Adi Dravidar Welfare Department, Tiruppur.</td>
    <td width="118">SC / ST – SWS only<br />
      Parent Annual Income <br />
      should be less than 3,00,000/-</td>
    <td width="185" valign="top"><a href="http://www.edistrict.tn.gov.in" target="_blank">www.edistrict.tn.gov.in</a> Apply through college</td>
  </tr>
  <tr>
    <td width="194">Govt. Special Scholarship</td>
    <td width="172">The&nbsp; District&nbsp; Welfare    Officer,<br />
      Adi Dravidar Welfare Dept. Tiruppur.</td>
    <td width="118">SC/ST Students only<br />
      Stay in Sasurie College Hostel<br />
      Parent Income <br />
      should be less than 1,00,000/-</td>
    <td width="185" valign="top">&nbsp; Apply through college</td>
  </tr>
  <tr>
    <td width="194">Central Sector Scheme of    Scholarship for College &amp; University Students</td>
    <td width="172">The Joint Director (Hr. Sec.),<br />
      Directorate of Government Examinations, D.P.I. Campus,<br />
      College Road, Chennai – 600 006.</td>
    <td width="118">80% and above Marks in HSC</td>
    <td width="185"><a href="http://www.tn.gov.in.dge/" target="_blank">www.tn.gov.in.dge/ </a>Apply through college</td>
  </tr>
  <tr>
    <td width="194">Merit Scholarship</td>
    <td width="172">Municipal Administrative    Commissioner,<br />
      Ezhilagam Building (Annexure) , <br />
      6th Floor, Chepauk, Chennai-5.</td>
    <td width="118">Highest marks in HSC &amp; studied    in Municipal/ Corporation School</td>
    <td width="185">Apply through college</td>
  </tr>
  <tr>
    <td width="194">Chief Minister Farmers Security    Scheme</td>
    <td width="172">The Commissioner of Technical    Education, Guindy, Chennai-25.</td>
    <td width="118">Wards of Farmers</td>
    <td width="185">Apply through college</td>
  </tr>
  <tr>
    <td width="194">Tamilnadu National Teacher Welfare    Fund</td>
    <td width="172">The Secretary-Treasurer,<br />
      National Foundation for Teachers' Welfare, Chennai –600 006.</td>
    <td width="118">Wards of Teachers</td>
    <td width="185">044 – 28267186</td>
  </tr>
  <tr>
    <td width="194">Tamilnadu Educational Trust,    Chennai</td>
    <td width="172">The Manager,<br />
      Tamilnadu Educational Trust,<br />
      Rajah Annamalai Building Annexe, IInd Floor,<br />
      18/3 Rukmini Lakshmipathi Road,<br />
      Chennai – 600 008.</td>
    <td width="118">60% and above Marks in HSC<br />
      Parent annual Income <br />
      should be less than 50,000/-</td>
    <td width="185">Apply through college</td>
  </tr>
  <tr>
    <td width="194">Minority Scholarship</td>
    <td width="172">The Commissioner of Minorities    Welfare,<br />
      807 (5th Floor)<br />
      Anna Salai, Chennai – 600 002.</td>
    <td width="118">Christians, Muslims, Sikhs &amp;    Buddhist<br />
      50% marks in previous exams</td>
    <td width="185"><a href="http://www.minorityaffairs,gov.in" target="_blank">www.minorityaffairs,gov.in</a><br />
      Apply through college</td>
  </tr>
  <tr>
    <td width="194">Physically Challenged Scholarship</td>
    <td width="172">National Handicapped Finance and    Development Corp. (NHFDC)</td>
    <td width="118">Students with disability </td>
    <td width="185"><a href="http://www.nhfdc.nic.in" target="_blank">www.nhfdc.nic.in</a><br />
      Apply through college</td>
  </tr>
</table>
<h3 class="page-header">Scholarship Schemes  from Private Sector</h3>
<table class="table table-bordered table-responsive">
  <tr>
    <td width="144"><strong>Scholarships</strong></strong></td>
    <td width="203"><strong>Address</strong></strong></td>
    <td width="122"><strong>Eligibility</strong></strong></td>
    <td width="229"><strong>Contact    Details/Website/Email address</strong></strong></td>
  </tr>
  <tr>
    <td width="144">Sri Vijayalakshmi Trust</td>
    <td width="203">Sri Vijayalakshmi Trust,<br />
      107 A Sengupta Street,<br />
      Ramnagar, Coimbatore – 641 009.</td>
    <td width="122">Coimbatore, Erode, Tiruppur &amp;    Nilgiri District students with 80% above only apply</td>
    <td width="229">Tel: 0422-2233798</td>
  </tr>
  <tr>
    <td width="144">Oil &amp; Natural Gas Corporation    Ltd.,</td>
    <td width="203">The Manager (HR)-I/C<br />
      SC/ST cell, Room No.3<br />
      Old Secretariat Building, ONGC,<br />
      Tel Bhavan Dehradun – 248003<br />
      (Uttrakhand)</td>
    <td width="122">SC/ST Meritorious students Engg.,    Geo Sciences &amp; MBA<br />
      Parent Annual Income<br />
      should be less than should be less than 1.5 lakh</td>
    <td width="229">www.ongcindia.com</td>
  </tr>
  <tr>
    <td width="144">The Hindu – Hitachi Scholarship</td>
    <td width="203">The Hindu,<br />
      859 &amp; 860 Anna Salai,<br />
      Chennai – 600 002.</td>
    <td width="122">B.E., (Engg.) or its equivalent    from any recognized university. One year professional experience need apply</td>
    <td width="229">&nbsp;</td>
  </tr>
  <tr>
    <td width="144">NTPC Scholarship</td>
    <td width="203">Dy. General Manager (HR-Welfare),<br />
      NTPC Ltd.,<br />
      NTPC Bhawan, Scope Complex,<br />
      Core-7, Lodi Road,<br />
      New Delhi – 110 003.</td>
    <td width="122">SC/ST/Physically challenged    persons</td>
    <td width="229">www.ntpc.co.in</td>
  </tr>
  <tr>
    <td width="144">Titan Scholarship</td>
    <td width="203">Titan Industries Ltd.,<br />
      3 Sipcot industrial Complex,<br />
      Hosur – 635 126.&nbsp;&nbsp; Krishnagiri Dt.</td>
    <td width="122">Dharmapuri &amp; Krishnagiri    District students only apply</td>
    <td width="229">www.titanindustries.in</td>
  </tr>
  <tr>
    <td width="144">Rotary Scholarship</td>
    <td width="203">Rotary Service Center<br />
      Juhu Tara Road<br />
      Mumbai 400 049</td>
    <td width="122">&nbsp;</td>
    <td width="229">022-26609847, 26607217<br />
      (Praful M. Bhatt)<br />
      http://www.rotary.org/<br />
      foundation/educational/amb_scho/<br />
      Also see:<br />
      http://www.umich.edu/~icenter/<br />
      overseas/study/rotary.html </td>
  </tr>
</table>
    </div>
  </div>
  
</div>
<div class="row">
<div class="col-xs-12 col-sm-12">
  <div class=" inner"> 
    <div class="">
      <h1>SASURIE Scholarships </h1>
      <h3 class="page-header">Sasurie scholarships is provided for both Regular B.E and Lateral</h3>
      <h3>Entry students on the basis of :</h3>
     <p>1.Merit  </p>
     <p>2.Sports Quota (State and National level performance )</p>
     <h6><strong>For more details contact :Mobile No.9488892222</strong></h6>
  </div>
  
</div>
</div>
             <script>
var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 1000); // Change image every 2 seconds
}
</script>

             <!-- start related course -->
             <!--div class="related_course">
                <h2>More Courses</h2>
                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="single_course wow fadeInUp" >
                      <div class="singCourse_imgarea">
                        <img src="img/course-1.jpg">
                        <div class="mask">                         
                          <a class="course_more" href="#">View Course</a>
                        </div>
                      </div>
                      <div class="singCourse_content">
                        <h3 class="singCourse_title"><a href="#">Introduction To Matrix</a></h3>
                        <p class="singCourse_price"><span>$20</span> Per One Month</p>
                        <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
                      </div>
                      <div class="singCourse_author">
                        <img alt="img" src="img/author.jpg">
                        <p>Richard Remus, Teacher</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="single_course wow fadeInUp" >
                      <div class="singCourse_imgarea">
                        <img src="img/course-1.jpg">
                        <div class="mask">                         
                          <a class="course_more" href="#">View Course</a>
                        </div>
                      </div>
                      <div class="singCourse_content">
                        <h3 class="singCourse_title"><a href="#">Introduction To Matrix</a></h3>
                        <p class="singCourse_price"><span>$20</span> Per One Month</p>
                        <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
                      </div>
                      <div class="singCourse_author">
                        <img alt="img" src="img/author.jpg">
                        <p>Richard Remus, Teacher</p>
                      </div>
                    </div>
                  </div>                                    
                </div>
              </div-->
              <!-- End related course -->
            </div>
          </div>
          <!-- End course content -->

          <!-- start course archive sidebar -->
         
              <!-- start single sidebar -->
              <!--div class="single_sidebar">
                <h2>Sponsor Add <span class="fa fa-angle-double-right"></span></h2>
                <a class="side_add" href="#"><img src="img/side-add.jpg" alt="img"></a>
              </div-->
              <!-- End single sidebar -->
            </div>
          </div>
          <!-- start course archive sidebar -->
        </div>
      </div>
    </section>

     <!--=========== BEGIN FOOTER SECTION ================-->
   <?php include 'php/footer.php';?>
    <!--=========== END FOOTER SECTION ================--> 

  

    <!-- Javascript Files
    ================================================== -->

    <!-- initialize jQuery Library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <!-- Preloader js file -->
    <script src="js/queryloader2.min.js" type="text/javascript"></script>
    <!-- For smooth animatin  -->
    <script src="js/wow.min.js"></script>  
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- slick slider -->
    <script src="js/slick.min.js"></script>
    <!-- superslides slider -->
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.animate-enhanced.min.js"></script>
    <script src="js/jquery.superslides.min.js" type="text/javascript" charset="utf-8"></script>   
    <!-- for circle counter -->
    <script src='https://cdn.rawgit.com/pguso/jquery-plugin-circliful/master/js/jquery.circliful.min.js'></script>
    <!-- Gallery slider -->
    <script type="text/javascript" language="javascript" src="js/jquery.tosrus.min.all.js"></script>   
   
    <!-- Custom js-->
    <script src="js/custom.js"></script>
  <!--=============================================== 
    Template Design By WpFreeware Team.
    Author URI : http://www.wpfreeware.com/
  ====================================================-->
  </body>
  </html>
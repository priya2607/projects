<!DOCTYPE html>
<html lang="en">
  <head>
  <?php include 'php/head.php';?>
</head>
  <body> 

    <!-- SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#"></a>
    <!-- END SCROLL TOP BUTTON -->

    <!--=========== BEGIN HEADER SECTION ================-->
      <?php include 'php/header.php';?>
    <!--=========== END HEADER SECTION ================--> 

    <!--=========== BEGIN COURSE BANNER SECTION ================-->
    <section id="imgBanner">
      <h2>Extra Curricular</h2>
    </section>
    <!--=========== END COURSE BANNER SECTION ================-->

    
    <!--=========== BEGIN COURSE BANNER SECTION ================-->
    <section id="courseArchive">
      <div class="container">
        <div class="row">
          <!-- start course content -->
          <div class="col-lg-8 col-md-8 col-sm-8">
            <div class="courseArchive_content">              
             <div class="singlecourse_ferimg_area">
              <div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/place/1.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/place/2.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/place/3.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/place/4.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/place/5.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>
</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span>
  <span class="dot"></span>
</div>
               <!--div class="singlecourse_ferimg">
                 <img src="img/course-single.jpg" alt="img">
               </div>  
                <div class="singlecourse_bottom">
                  <h2>Introduction To Matrix</h2>
                  <span class="singlecourse_author">
                    <img alt="img" src="img/author.jpg">
                    Richard Remus, Teacher
                  </span>
                  <span class="singlecourse_price">$20</span>
                </div-->
             </div></div></div>
<div class="col-sm-4">
            <div class="courseArchive_sidebar">
              <div class="single_sidebar" >
                <h2>Placements <span class="fa fa-angle-double-right"></span></h2>
                <ul>
                  <li><a href="our.php">Our Recruiters</a></li>
                  <li><a href="ptn.php">Placements Till Now</a></li>
                   <li><a href="trainning.php">Training</a></li>
                  <li><a href="contactplace.php">Contact PCDC</a></li>
                </ul>
              </div></div></div>
              <div class="row">
<div class="col-xs-12 col-sm-9">
  
      <h1 class="page-header">Clubs</h1>
      
     <!-- <p>The various clubs functioning to develop the students knowledge, Extra Curricular ,Career are :      </p>
      <ul class="list">
        <li><a href="javascript:void(0)">Arena Club</a>
        <ul class="list"  style="margin-left:15px; padding-top:10px;">
        <li><a href="javascript:void(0)">2014</a></li>
        <li><a href="arena-club.php">2013</a></li>
        </ul>
        </li>
        <li><a href="ruthram-club.php">Ruthram Club</a></li>
        <li><a href="hr-club.php">HR&nbsp;Club</a></li>
        <li><a href="corporate-connect.php">Corporate Connect</a></li>
        <li><a href="finance-club.php">Finance Club</a></li>
        <li><a href="marketing-club.php">Marketing Cub</a></li>
        <li><a href="edc-cell.php">EDC CELL</a> </li> 
 </ul>     -->
 
 <p>The following clubs are functioning to develop the students leadership  skill, knowledge and their Extra Curricular activities :</p>
<ul class="list">
  <li>Arena Club</li>
  <li>Picasso Club</li>
  <li>Bernard Shaw Club</li>
  <li>Sachin Club</li>
  <li>Einstein Club</li>
  <li>Nature CLub</li>
</ul>
<h3><strong>SLF</strong></h3>

  Sasurie leadership forum is to promote the volunteer ship  and leadership skill among students. The Objective of SLF is to project the  talents of our students in different fields<p></p>
<ul class="list">
  <li>BRAND AMBASSADOR</li>
  <li>RANKERS LEAGUE</li>
  <li>SKILL MASTER</li>
  <li>PROJECT EXPOSITION</li>
  <li>SPECTATOR SPORT</li>
</ul>
<h3><strong>MENTORSHIP  FORUM</strong></h3>
<ul class="list">
  <li>Mentorship forum in the institution is to  establish mentoring relationship between professionals and Industry experts  with the students.</li>
  <li>This programme offers assistance to make right  career decisions, based on the experience of the mentor and identifying various  research and higher studies opportunities.</li>
  <li>Mentorship program for the third year students is  started during the academic year 2014-15</li>
  <li>During the academic year 2015-16 , mentorship  program is organized for the second and third year students</li>
</ul>

    </div>
    </div>
 
</div>

</div></div>

</div>
             <script>
var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 1000); // Change image every 2 seconds
}
</script>

             <!-- start related course -->
             <!--div class="related_course">
                <h2>More Courses</h2>
                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="single_course wow fadeInUp" >
                      <div class="singCourse_imgarea">
                        <img src="img/course-1.jpg">
                        <div class="mask">                         
                          <a class="course_more" href="#">View Course</a>
                        </div>
                      </div>
                      <div class="singCourse_content">
                        <h3 class="singCourse_title"><a href="#">Introduction To Matrix</a></h3>
                        <p class="singCourse_price"><span>$20</span> Per One Month</p>
                        <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
                      </div>
                      <div class="singCourse_author">
                        <img alt="img" src="img/author.jpg">
                        <p>Richard Remus, Teacher</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="single_course wow fadeInUp" >
                      <div class="singCourse_imgarea">
                        <img src="img/course-1.jpg">
                        <div class="mask">                         
                          <a class="course_more" href="#">View Course</a>
                        </div>
                      </div>
                      <div class="singCourse_content">
                        <h3 class="singCourse_title"><a href="#">Introduction To Matrix</a></h3>
                        <p class="singCourse_price"><span>$20</span> Per One Month</p>
                        <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
                      </div>
                      <div class="singCourse_author">
                        <img alt="img" src="img/author.jpg">
                        <p>Richard Remus, Teacher</p>
                      </div>
                    </div>
                  </div>                                    
                </div>
              </div-->
              <!-- End related course -->
          <!-- End course content -->

          <!-- start course archive sidebar -->
          
              <!-- start single sidebar -->
              <!--div class="single_sidebar">
                <h2>Events <span class="fa fa-angle-double-right"></span></h2>
                <ul class="news_tab">
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a href="#" class="news_img">
                          <img alt="img" src="img/news.jpg" class="media-object">
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Dummy text of the printing and typesetting industry</a>
                       <span class="feed_date">27.02.15</span>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a href="#" class="news_img">
                          <img alt="img" src="img/news.jpg" class="media-object">
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Dummy text of the printing and typesetting industry</a>
                       <span class="feed_date">28.02.15</span>                
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a href="#" class="news_img">
                          <img alt="img" src="img/news.jpg" class="media-object">
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Dummy text of the printing and typesetting industry</a>
                       <span class="feed_date">28.02.15</span>                
                      </div>
                    </div>
                  </li>                  
                </ul>
              </div-->
              <!-- End single sidebar -->
              <!-- start single sidebar -->
              
              <!-- End single sidebar -->
              <!-- start single sidebar -->
              <!--div class="single_sidebar">
                <h2>Sponsor Add <span class="fa fa-angle-double-right"></span></h2>
                <a class="side_add" href="#"><img src="img/side-add.jpg" alt="img"></a>
              </div-->
              <!-- End single sidebar -->
          <!-- start course archive sidebar -->
        </div>
      </div>
    </section>
    <!--=========== END COURSE BANNER SECTION ================-->
    
    <!--=========== BEGIN FOOTER SECTION ================-->
  <?php include 'php/footer.php';?>
    <!--=========== END FOOTER SECTION ================--> 

  

    <!-- Javascript Files
    ================================================== -->

    <!-- initialize jQuery Library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <!-- Preloader js file -->
    <script src="js/queryloader2.min.js" type="text/javascript"></script>
    <!-- For smooth animatin  -->
    <script src="js/wow.min.js"></script>  
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- slick slider -->
    <script src="js/slick.min.js"></script>
    <!-- superslides slider -->
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.animate-enhanced.min.js"></script>
    <script src="js/jquery.superslides.min.js" type="text/javascript" charset="utf-8"></script>   
    <!-- for circle counter -->
    <script src='https://cdn.rawgit.com/pguso/jquery-plugin-circliful/master/js/jquery.circliful.min.js'></script>
    <!-- Gallery slider -->
    <script type="text/javascript" language="javascript" src="js/jquery.tosrus.min.all.js"></script>   
   
    <!-- Custom js-->
    <script src="js/custom.js"></script>
  <!--=============================================== 
    Template Design By WpFreeware Team.
    Author URI : http://www.wpfreeware.com/
  ====================================================-->

  </body>
</html>
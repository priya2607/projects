<!DOCTYPE html>
<html lang="en">
 <head>
  <?php include 'php/head.php';?>
</head>
  <body>
     <!-- SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#"></a>
    <!-- END SCROLL TOP BUTTON -->

    <!--=========== BEGIN HEADER SECTION ================-->
     <?php include 'php/header.php';?>
    <!--=========== END HEADER SECTION ================--> 
    <section id="imgBanner">
      <h2>Master of Business Administration</h2>
    </section>
    <!--=========== END COURSE BANNER SECTION ================-->

    
    <!--=========== BEGIN COURSE BANNER SECTION ================-->
    <section id="courseArchive">
      <div class="container">
        <div class="row">
          <!-- start course content -->
          <div class="col-lg-8 col-md-8 col-sm-8">
            <div class="courseArchive_content">              
             <div class="singlecourse_ferimg_area">
              <div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/pg/1.jpg" style="width:100%">
  <div class="text">THE CHANAKYAS OF BUSINESS</div>
</div>

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/pg/2.jpg" style="width:100%">
  <div class="text">THE CHANAKYAS OF BUSINESS</div>
</div>
</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
</div>   </div>
             <div class="single_course_content">
                <h3>Association Activities</h3>
<table class="table table-bordered table-responsive">
<thead>
  <tr>
    <td width="51"><p align="center"><strong>S.NO</strong></p></td>
    <td width="94"><p align="center"><strong>DATE</strong></p></td>
    <td width="186"><p align="center"><strong>TITLE OF THE PROGRAMME</strong></p></td>
    <td width="204"><p align="center"><strong>CHIEF GUEST</strong></p></td>
    </tr></thead>
  <tbody><tr>
    <td width="51"><p align="center">1</p></td>
    <td width="94"><p align="center">30.08.12</p></td>
    <td width="186"><p align="center">Importance of Insurance</p></td>
    <td width="204"><p align="center">Mr. JC. Senthilraja<br>
      Sales Manager<br>
      Erode</p></td>
    </tr>
  <tr>
    <td width="51"><p align="center">2</p></td>
    <td width="94"><p align="center">31.08.12</p></td>
    <td width="186"><p align="center">Don't give up</p></td>
    <td width="204"><p align="center">Dr. S. Krishna<br>
      Coimbatore</p></td>
    </tr>
  <tr>
    <td width="51"><p align="center">3</p></td>
    <td width="94"><p align="center">06.10.12</p></td>
    <td width="186"><p align="center">Management challenges and Excitement</p></td>
    <td width="204"><p align="center">Dr.Nithyanadhan Devaraj<br>
      L &amp; T, SBU Head.Cbe</p></td>
    </tr>
  <tr>
    <td width="51"><p align="center">4</p></td>
    <td width="94"><p align="center">19.1012</p></td>
    <td width="186"><p align="center">Financial planning for young Investors</p></td>
    <td width="204"><p align="center">Asst.Prof.Prabakar<br>
      RVS College, Cbe.</p></td>
    </tr>
  <tr>
    <td width="51"><p align="center">5</p></td>
    <td width="94"><p align="center">28.11.12</p></td>
    <td width="186"><p align="center">Inauguration of Readers Forum</p></td>
    <td width="204"><p align="center">Prof.N.Mani<br>
      Erode Arts and Science College.</p></td>
    </tr>
  <tr>
    <td width="51"><p align="center">6</p></td>
    <td width="94"><p align="center">30.11.12</p></td>
    <td width="186"><p align="center">Be a Executive</p></td>
    <td width="204"><p align="center">Mr.Balamurugan Chenniappan</p></td>
    </tr>
  <tr>
    <td width="51"><p align="center">7</p></td>
    <td width="94"><p align="center">28.02.13</p></td>
    <td width="186"><p align="center">Union Budget Live Cast</p></td>
    <td width="204"><p align="center">-</p></td>
    </tr>
  <tr>
    <td width="51"><p align="center">8</p></td>
    <td width="94"><p align="center">06.03.13</p></td>
    <td width="186"><p align="center">Empowering the rural Youth</p></td>
    <td width="204"><p align="center">Mr.Viswanathan<br>
      Sigaram Foundation</p></td>
    </tr>
  <tr>
    <td width="51"><p align="center">9</p></td>
    <td width="94"><p align="center">26.08.13</p></td>
    <td width="186"><p align="center">Rudhtam Club Inagauration</p></td>
    <td width="204"><p align="center">Mrs.R.Sasiprabha<br>
      JCI Trainer</p></td>
    </tr>
  <tr>
    <td width="51"><p align="center">10</p></td>
    <td width="94"><p align="center">10.1013</p></td>
    <td width="186"><p align="center">Finanace Club Inaguration</p></td>
    <td width="204"><p align="center">Dr.P.Karthikeyan<br>
      SEBI co-ordinator</p></td>
    </tr>
  <tr>
    <td width="51"><p align="center">11</p></td>
    <td width="94"><p align="center">09.10.13</p></td>
    <td width="186"><p align="center">Corpoarate Connect</p></td>
    <td width="204"><p align="center">Mr.M.Sathis kumar<br>
      Manager HR&amp; Administration<br>
      VEE J PEE Aluminium Foundry<br>
      Coimbatore</p></td>
    </tr>
  <tr>
    <td width="51"><p align="center">12</p></td>
    <td width="94"><p align="center">27.02.14</p></td>
    <td width="186"><p align="center">Tutelafest-2014-National Level Intercollegiate Meet</p></td>
    <td width="204"><p align="center">Mr.M.K.Podaran<br>
      Chairman Podaran Soft Drinks</p></td>
    </tr>
</tbody></table>
             </div>
             <script>
var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 1000); // Change image every 2 seconds
}
</script>

                         </div>
          </div>
          <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="courseArchive_sidebar">
                           <div class="single_sidebar">
                <a href="#" class="list-group-item" style="background:#dcb305; color:#000; font-size:15px;">Master of Business Administration</a>
                 <a href="mba.php" class="list-group-item ">About the Department</a>
                 <a href="mba1.php" class="list-group-item active ">Association Activities</a>
                 <a href="mba2.php"class="list-group-item ">Laurels Won by Students</a>
                 <a href="mba3.php" class="list-group-item ">Alumni Students</a>
                 <a href="mba4.php" class="list-group-item ">E-Course Material</a>  
                 <a href="http://nptel.ac.in/course.php?disciplineId=110" class="list-group-item" target="_blank">NPTEL VIDEO</a> 
              </div>
            </div>
          </div>
          <!-- start course archive sidebar -->
        </div>
      </div>
    </section>

     <!--=========== BEGIN FOOTER SECTION ================-->
   <?php include 'php/footer.php';?>
    <!--=========== END FOOTER SECTION ================--> 

  

    <!-- Javascript Files
    ================================================== -->

    <!-- initialize jQuery Library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <!-- Preloader js file -->
    <script src="js/queryloader2.min.js" type="text/javascript"></script>
    <!-- For smooth animatin  -->
    <script src="js/wow.min.js"></script>  
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- slick slider -->
    <script src="js/slick.min.js"></script>
    <!-- superslides slider -->
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.animate-enhanced.min.js"></script>
    <script src="js/jquery.superslides.min.js" type="text/javascript" charset="utf-8"></script>   
    <!-- for circle counter -->
    <script src='https://cdn.rawgit.com/pguso/jquery-plugin-circliful/master/js/jquery.circliful.min.js'></script>
    <!-- Gallery slider -->
    <script type="text/javascript" language="javascript" src="js/jquery.tosrus.min.all.js"></script>   
   
    <!-- Custom js-->
    <script src="js/custom.js"></script>
  <!--=============================================== 
    Template Design By WpFreeware Team.
    Author URI : http://www.wpfreeware.com/
  ====================================================-->
  </body>
  </html>
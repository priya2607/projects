<!DOCTYPE html>
<head>
    <style type="text/css">
        img {
    max-width: 100%;
    height: auto;
    width: auto\9;
    /* ie8 */
}
div {
    display: inline-flex;
}
    </style>
</head>
<body>
    <div style="max-width: 800px; border:2px black solid">
        <div style="height: auto; border:1px green solid">
            <img src=http://i.imgur.com/Xt6vUQD.jpg />
        </div>
        <div style="height: auto; border:1px blue solid">
            <img src=http://i.imgur.com/BqFMNlq.jpg />
        </div>
    </div>
</body>

<!DOCTYPE html>
<html lang="en">
  <head>
  <?php include 'php/head.php';?>
</head>
  <body> 

    <!-- SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#"></a>
    <!-- END SCROLL TOP BUTTON -->

    <?php include 'php/header.php';?>
    <!--=========== END HEADER SECTION ================--> 

    <!--=========== BEGIN COURSE BANNER SECTION ================-->
    <section id="imgBanner">
      <h2>Facilities</h2>
    </section>
    <!--=========== END COURSE BANNER SECTION ================-->

    
    <!--=========== BEGIN COURSE BANNER SECTION ================-->
    <section id="courseArchive">
      <div class="container">
        <div class="row">
          <!-- start course content -->
          <div class="col-lg-8 col-md-8 col-sm-8">
            <div class="courseArchive_content">              
             <div class="singlecourse_ferimg_area">
                           <div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/index/i1.jpg" style="width:100%">
  <div class="text">THE GEARS OF PROGRESS</div>
</div>

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/index/i2.jpg" style="width:100%">
  <div class="text">THE GEARS OF PROGRESS</div>
</div>

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/index/i3.jpg" style="width:100%">
  <div class="text">THE GEARS OF PROGRESS</div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/index/i4.jpg" style="width:100%">
  <div class="text">THE GEARS OF PROGRESS</div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/index/i5.jpg" style="width:100%">
  <div class="text">THE GEARS OF PROGRESS</div>
</div>
</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span>
   <span class="dot"></span>
</div>
             </div>
             <div class="single_course_content">
               <h2>Facilities</h2>
              <h2>Seminar Halls</h2>
               <p>Sasurie College of Engineering provides well equipped spacious  Seminar Halls with air conditioning facilities and built-in LCD monitor for various technical Expo,Symposium and  Conference events for better quality education for the students.</p>
             <img src="img/seminar/s1.jpg">
             <img src="img/seminar/s2.jpg">
             <img src="img/seminar/s3.jpg">
              <h2>Hostel</h2>
               <p>Hostel carter to the needs of individual students with comfortable stay and nutritious food; vegetarian and non-vegetarian, prepared in hygienic condition and RO water is served and students participate in deciding the menu. Hostels for boys and girls with spacious rooms, television, newspaper and regular medical check-up, yoga class are provided by the hostel.</p>
             <img src="img/seminar/h1.jpg">
             <img src="img/seminar/h2.jpg">
             <h2>ATM</h2>
               <p>Sasurie college of Engineering provides 24 hour ATM facility (in accordance with Karur Vysya Bank) to both the hostlers and day scholars within the campus; and to the trespassers for free. ATM facility reduces the risk of students to carry the fee amount by cash in hand.</p>
             <img src="img/seminar/a.jpg">
            
            <h2>Canteen</h2>
               <p>Our campus  functions with a canteen  that serve the students and staff members.

The Canteen  built-up area  is  900 Sq.mt, has a seating capacity of 600. The administration of this canteen  is given to an experienced, proficient and committed contractor. It is open on all working days and provides foods at a very reasonable price.</p><h3>Special Features</h3>
<p>A hygienic catering</p>
<p>Purified Drinking water</p>
<p>Well equipped with modernized cooking appliances</p>
<h2>Power Supply</h2>
<p>The campus is well equipped with the power supply for 24 hrs to carry out day- to-day process in a full fledged manner.</p>
             <img src="img/seminar/p.jpg">
             <h2>RO System</h2><p>Reverse Osmosis drinking water system is  the purified drinking water  provided in the campus and in the hostels to maintain a good hygiene.</p>
             <img src="img/seminar/r.jpg">
              
            </div>
               <script>
var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 1000); // Change image every 2 seconds
}
</script>
          </div>
          <!-- End course content -->

          <!-- start course archive sidebar -->
          <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="courseArchive_sidebar">
              <!-- start single sidebar -->
              <div class="single_sidebar">
                <h2>Events <span class="fa fa-angle-double-right"></span></h2>
                <ul class="news_tab">
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a href="#" class="news_img">
                          <img alt="img" src="img/news.jpg" class="media-object">
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Dummy text of the printing and typesetting industry</a>
                       <span class="feed_date">27.02.15</span>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a href="#" class="news_img">
                          <img alt="img" src="img/news.jpg" class="media-object">
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Dummy text of the printing and typesetting industry</a>
                       <span class="feed_date">28.02.15</span>                
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a href="#" class="news_img">
                          <img alt="img" src="img/news.jpg" class="media-object">
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Dummy text of the printing and typesetting industry</a>
                       <span class="feed_date">28.02.15</span>                
                      </div>
                    </div>
                  </li>                  
                </ul>
              </div>
              <!-- End single sidebar -->
              <!-- start single sidebar -->
              <div class="single_sidebar">
                <h2>Quick Links <span class="fa fa-angle-double-right"></span></h2>
                <ul>
                  <li><a href="#">Link 1</a></li>
                  <li><a href="#">Link 2</a></li>
                  <li><a href="#">Link 3</a></li>
                  <li><a href="#">Link 4</a></li>
                  <li><a href="#">Link 5</a></li>
                </ul>
              </div>
              <!-- End single sidebar -->
              <!-- start single sidebar -->
              <div class="single_sidebar">
                <h2>Sponsor Add <span class="fa fa-angle-double-right"></span></h2>
                <a class="side_add" href="#"><img src="img/side-add.jpg" alt="img"></a>
              </div>
              <!-- End single sidebar -->
            </div>
          </div>
          <!-- start course archive sidebar -->
        </div>
      </div>
    </section>
    <!--=========== END COURSE BANNER SECTION ================-->
    
    <!--=========== BEGIN FOOTER SECTION ================-->
  <?php include 'php/footer.php';?>
    <!--=========== END FOOTER SECTION ================--> 

  

    <!-- Javascript Files
    ================================================== -->

    <!-- initialize jQuery Library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <!-- Preloader js file -->
    <script src="js/queryloader2.min.js" type="text/javascript"></script>
    <!-- For smooth animatin  -->
    <script src="js/wow.min.js"></script>  
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- slick slider -->
    <script src="js/slick.min.js"></script>
    <!-- superslides slider -->
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.animate-enhanced.min.js"></script>
    <script src="js/jquery.superslides.min.js" type="text/javascript" charset="utf-8"></script>   
    <!-- for circle counter -->
    <script src='https://cdn.rawgit.com/pguso/jquery-plugin-circliful/master/js/jquery.circliful.min.js'></script>
    <!-- Gallery slider -->
    <script type="text/javascript" language="javascript" src="js/jquery.tosrus.min.all.js"></script>   
   
    <!-- Custom js-->
    <script src="js/custom.js"></script>
  <!--=============================================== 
    Template Design By WpFreeware Team.
    Author URI : http://www.wpfreeware.com/
  ====================================================-->

  </body>
</html>
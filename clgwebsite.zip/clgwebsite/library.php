<!DOCTYPE html>
<html lang="en">
<head>
  <?php include 'php/head.php';?>
</head>
  <body> 

    <!-- SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#"></a>
    <!-- END SCROLL TOP BUTTON -->

    <!--=========== BEGIN HEADER SECTION ================-->
      <!-- END SCROLL TOP BUTTON -->

     <?php include 'php/header.php';?>
    <!--=========== END HEADER SECTION ================--> 

    <!--=========== BEGIN COURSE BANNER SECTION ================-->
    <section id="imgBanner"><div id="ug" style= text-align: "left">
      <h2>Sce Central Library </h2></div>
    </section>
    <!--=========== END COURSE BANNER SECTION ================-->

    
    <!--=========== BEGIN COURSE BANNER SECTION ================-->
    <section id="courseArchive">
      <div class="container">
        <div class="row">
          <!-- start course content -->
          <div class="col-lg-8 col-md-8 col-sm-8">
            <div class="courseArchive_content">              
             <div class="singlecourse_ferimg_area">
               
             </div>
             <div class="single_course_content">
               <h2 >Library & Information Center</h2>

               <div class="courseArchive_content">              
             <div class="singlecourse_ferimg_area">
                           <div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="http://www.sasurieengg.com/images/banner/library/1.jpg" style="width:100%">
  <div class="text">SASURIE CENTRAL LIBRARY</div>
</div>

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="http://www.sasurieengg.com/images/banner/library/1.jpg" style="width:100%">
  <div class="text">SASURIE CENTRAL LIBRARY</div>
</div>

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="http://www.sasurieengg.com/images/banner/library/1.jpg" style="width:100%">
  <div class="text">SASURIE CENTRAL LIBRARY</div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="http://www.sasurieengg.com/images/banner/library/1.jpg" style="width:100%">
  <div class="text">SASURIE CENTRAL LIBRARY</div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="http://www.sasurieengg.com/images/banner/library/1.jpg" style="width:100%">
  <div class="text">SASURIE CENTRAL LIBRARY</div>
</div>
</div></div></div>
<br>
<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span>
   <span class="dot"></span>
</div>

<script>
var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 1000); // Change image every 2 seconds
}
</script>
              
                  <ul class="nav nav-tabs feed_tabs1" id="mytab2" >
              <li><a href="#home" data-toggle="tab">Home</a></li>
              <li><a href="#book" data-toggle="tab">books</a></li>
              <li><a href="#journals" data-toggle="tab">Journals</a></li>
              <li><a href="#dl" data-toggle="tab">Digital Library</a></li>
              <li><a href="#nptel" data-toggle="tab">Nptel Online Source</a></li>       
              <li><a href="#service" data-toggle="tab">Service</a></li>
              <li><a href="#qbs" data-toggle="tab">Question bank & Syllabus</a></li> 
              <li><a href="#web" data-toggle="tab">Web opac</a></li>
              <li><a href="#ill" data-toggle="tab">International Librarys Links</a></li>
              <li><a href="#link" data-toggle="tab">Use Full Links</a></li>
              <li><a href="#profile" data-toggle="tab">Profile</a></li>
            </ul>
            <div class="tab-content" >

              <div class="tab-pane fade in active" id="home">
                <div class="single_notice_pane">
                <h1>SASURIE Central Library</h1>
                <h3>About US</h3>
                <p>The Library transactions are carried out by Intergrate Software Technology. It has the facility of Web OPAC-online search. So the library catalogue can be accessed through intranet, in future through internet. And the library is being subscribed to the E-resources.</p>
              <h3>Library Working Hours :</h3>
              <p>The Library functions from 8.00 A.M. To 7.00 P.M. on all working days.</p>
              <p>The Library functions from 9.00 A.M. To 1.00 P.M. on Holidays.</p>
              <h3>Statistics :</h3>
              <p>There are one Photocopier machines ie. One  Digital Copier RICOH Aficio 2020D are available in the Library. Library provides reprographic service to the users at a nominal cost. This service is helpful to the students for preparing their paper presentations, projects etc.</p>
             <br><table class="table table-bordered">
                      <tbody> <tr>
          <td><p><strong>Total No Of Volumes :</strong></p></td><td>44299</td></tr><tr>
          <td><p><strong>Total No Of Titles :</strong></p></td><td>18799</td></tr><tr>
          <td><p><strong>Library Area :</strong></p></td><td>815SQMTS</td></tr><tr>
          <td><p><strong>News Paper :</strong></p></td><td>9</td></tr><tr>
          <td><p><strong>CDS :</strong></p></td><td>3570</td></tr><tr>
          <td><p><strong>Project :</strong></p></td><td>14074</td></tr><tr>
          <td><p><strong>Magazine :</strong></p></td><td>947</td></tr><tr>
          <td><p><strong>Back Volume :</strong></p></td><td>35</td></tr>
           </tbody></table>
              </div>
            </div>

               <div class="tab-pane fade" id="profile">                
                <div class="single_notice_pane">
                     <table>
                      <tbody>
                  <tr>
                    
                    <td width="75%" height="150px"><table width="90%" border="0"><tbody><tr><td><span class="Desgn_stat_txt">Name:</span>
                    <span class="Desgn_dspl_txt">P.KUMAR.,MCOM(CA),MLISC,MPHIL.,</span></td></tr>
                    <tr><td><span class="Desgn_stat_txt">Designation:</span> <span class="Desgn_dspl_txt">HOD</span><br>Department Library & Information Science</td></tr>
                    <tr><td><span class="Desgn_stat_txt">Phone:</span> <span class="Desgn_nrml_txt">0429-4243675,243717</span></td></tr>
                    
                    <tr>
                    <td><span class="Desgn_stat_txt">E-Mail:</span> <span class="Desgn_nrml_txt">sasurielibrary2020@gmail.com</span></td>
                    </tr>
                        </tbody></table>
                      </td>
                  </tr>
                  </tbody>
                </table>
                  <h3>Seminor & Confreence : </h3><br>
                  <h4>SRI KRISHNA COLLEGE OF TECHNOLOGY.COIMBATORE</h4>
                  <p>Two Days National Workshop on Koha and DSpace OSS:A comparehensive hands on learning</p>
                  <h4>SRI KRISHNA COLLEGE OF TECHNOLOGY.COIMBATORE</h4>
                  <p>One Day Workshop on 'DELNET' Resources Service of Facilities</p>
                  <h4>NATIONAL INSTITUTE OF TECHNOLOGY.TIRUCHIRAPPALI</h4>
                  <p>One Day Workshop on 'DELNET' Resources Service of Facilities</p>
                  <h4>K.L.N.COLLEGE OF INFORMATION TECHNOLOGY</h4>
                  <p>One Day National Seminor on "Implementation of Future Technology In ACADEMIC LIBRARIES</p>
                  <h4>DR MAHALINGAM COLLEGE OF ENGINEERING AND TECHNOLOGY.POLLACHI</h4>
                  <p>Socientyfer The Advancement of Library and Informartion Science(SACIS)</p>
                  <h4>ALAGAPPA UNIVERSIT.KARAIKUDI</h4>
                  <p>ICSSRSponsored National Seminor on Application and Relevance of E-Resourcein Academic Library</p>
                  <h4>GOBI ARTS & SCIENCE COLLEGE.GOBI</h4>
                  <p>VGC Sponsored Tow Days National Conference on "Acadamic Library Planning In Higher Education and Resurgence:Role of E-Resources</p>
                  <h4>SASURIE COLLEGE OF ENGNEERING.VIJAYAMANGALAM</h4>
                  <p>International Conference on Innovation in Communication,Information and Computing ICICIC13</p>
                  <h4>NATIONAL PROGRAMME ON TECHNOLOGY ENHANCEDCERNING</h4>
                  <p>IIT Madras NPTEL Workshop</p>
                  </div>
              </div>  


              <div class="tab-pane fade " id="link">
                <div class="single_notice_pane"><br>
                    <p>Links</p>
                    <table align="center"><tbody><tr><td> 
             <li><a href="../download/freeebookssites.pdf" target="_blank">Free Engineering ebooks</a></li>
             <li><a href="http://www.e-booksdirectory.com/engineering.php" target="_blank">Engineering ebooks</a></li>
            <li><a href="http://dli.iiit.ac.in/" target="_blank">Digital Library of India</a></li>
            <li><a href="http://www.nationallibrary.gov.in/" target="_blank">National Library</a></li>
            <li><a href="http://www.library.iisc.ernet.in" target="_blank">JRD Tata Memorial Library</a></li>
            
            <li><a href="http://www.cenlib.iitm.ac.in/docs/library/" target="_blank">Central Library - Chennai</a></li>
            <li><a href="http://www.ieee.org/portal/innovate/products/research/ieee_iel.html" target="_blank">IEEE/IET Electronic Library</a></li>
            <li><a href="http://www.doaj.org/" target="_blank">Directory of Open Access Journals</a></li>
            <li><a href="http://www.onlinecomputerbooks.com/" target="_blank">Computer eBooks</a></li>
            <li><a href="http://www.doaj.org/" target="_blank">DOAJ - Directory of Open Access Journals</a></li>
            </td></tr>
            </tbody></table>
                </div> 
              </div> 


              <div class="tab-pane fade " id="book">
                <div class="single_notice_pane">
                  <table class="table table-bordered">
        <tbody><tr>
          <td colspan="6"><p align="center"><strong>Books</strong></p></td>
          </tr>
        <tr align="center">
          <td><p><strong>Department</strong></p></td>
          <td><p><strong>Title</strong></p></td>
          <td><p><strong>Vol</strong></p></td>
          <td><p><strong>N.Journal</strong></p></td>
          <td><p><strong>I.Journal</strong></p></td>
          <td><p><strong>E.Journal</strong></p></td>
        </tr>
        <tr align="center">
          <td>CIVIL</td>
          <td>771</td>
          <td>2220</td>
          <td>6</td>
          <td>6</td>
          <td>147</td>
        </tr>
        <tr align="center">
          <td>MECH</td>
          <td>2103</td>
          <td>5063</td>
          <td>18</td>
          <td>17</td>
          <td>39</td>
        </tr>
        <tr align="center">
          <td>ECE</td>
          <td>3284</td>
          <td>8333</td>
          <td>18</td>
          <td>18</td>
          <td>11</td>
        </tr>
        <tr align="center">
          <td>EEE</td>
          <td>1956</td>
          <td>4456</td>
          <td>6</td>
          <td>6</td>
          <td>15</td>
        </tr>
        <tr align="center">
          <td>CSE</td>
          <td>3695</td>
          <td>8203</td>
          <td>12</td>
          <td>12</td>
          <td>188</td>
        </tr>
        <tr align="center">
          <td>IT</td>
          <td>494</td>
          <td>1073</td>
          <td>-</td>
          <td>-</td>
          <td>38</td>
        </tr>
        <tr align="center">
          <td>S&H</td>
          <td>2678</td>
          <td>4896</td>
          <td>6</td>
          <td>6</td>
          <td>126</td>
        </tr>
        <tr align="center">
          <td>MTECH IT</td>
          <td>509</td>
          <td>1478</td>
          <td>6</td>
          <td>5</td>
          <td>30</td>
        </tr>
        <tr align="center">
          <td>ME CSE</td>
          <td>606</td>
          <td>1488</td>
          <td>5</td>
          <td>5</td>
          <td>60</td>
        </tr>
        <tr align="center">
          <td>ME VLSI</td>
          <td>377</td>
          <td>931</td>
          <td>5</td>
          <td>5</td>
          <td>10</td>
        </tr>
        <tr align="center">
          <td>ME AE</td>
          <td>258</td>
          <td>625</td>
          <td>5</td>
          <td>5</td>
          <td>10</td>
        </tr>
        <tr align="center">
          <td>ME PED</td>
          <td>249</td>
          <td>615</td>
          <td>5</td>
          <td>5</td>
          <td>15</td>
        </tr>
        <tr align="center">
          <td>MBA</td>
          <td>1694</td>
          <td>6007</td>
          <td>12</td>
          <td>12</td>
          <td>235</td>
        </tr>
        <tr align="center">
          <td>Total</td>
          <td>18799</td>
          <td>44299</td>
          <td>103</td>
          <td>103</td>
          <td>924</td>
        </tr>
      </tbody></table>
                </div>   
              </div>


               <div class="tab-pane fade " id="dl">
                <div class="single_notice_pane">

                  <p>It has a collection of CDs and Floppy Disks, around 2100 of all disciplines including sources like GRE,GMAT, TOEFL, ISI codes etc. In addition, 300 Audio and Video Cassettes are available in the SCE Center Libraries. It provides a number of Online Electronic Database like IEEE, ACM, ASME and ASCE online CD-ROM databases. Proquest science online journals are also available in CD-ROMs.</p>
                  <p>Degital Library</p>
                  <p>1.DSpace</p>
                  <p>&nbsp;&nbsp;&nbsp;&nbsp;A groundbreaking digital repository system, DSpace captures, stores, indexes, preserves and redistributes an organization's research material in digital formats. Research institutions worldwide use DSpace for a variety of digital archiving needs - from institutional repositories (IRs) to learning object repositories or electronic records management, and more.</p>
                  <p>2.Green Stone</p>
                  <p>&nbsp;&nbsp;&nbsp;&nbsp;Greenstone is a suite of software for building and distributing digital library collections. It provides a way of organizing information and publishing it on the web or on removable media such as DVD and USB flash drives. Greenstone is produced by the New Zealand Digital Library Project at the University of Waikato, and developed and distributed in cooperation with UNESCO and the Human Info NGO. It is open-source, multilingual software, issued under the terms of the GNU General Public License. Read the Greenstone Factsheet for more information.</p><br>
                  <p>We have institutional memberships with the following institutions,</p>
                  <p>1.DELNET (Developing Library Network), New Del</p>
                  <img src="img/lib/Delnet-2.png" width="90%"><br>
                  <p>2.NDL(NATIONAL DIGITAL LIBRARY)</p>
                  <img src="img/lib/help3.png" width="90%" ><br>
                  <p>3.BCL (British Council Library), Chennai</p>
                  <img src="img/lib/page_1.jpg" width="90%" >
                </div>   
              </div>

              <div class="tab-pane fade " id="ni">
                <div class="single_notice_pane">
                  
                </div>   
              </div>

              <div class="tab-pane fade " id="service">
                <div class="single_notice_pane">
                  <div class="">
      <h1>Services</h1>
      <ul style="list-style-type: disc;">  
<li>Current Awareness Service</li>
  <li>E-Books Access</li>
  <li>E-Journal [Full-text] Access</li>
  <li>Information Desk - Any Information Any Time</li>
  <li>Inter Library Loan Service</li>
  <li>Internet Service</li>
  <li>News Paper Clippings</li>
  <li>Research and Reference Service</li>
  <li>Reprography Service</li>
  <li>Service for Career &amp; Placement Aids</li>
  <li>Upcoming Conference Alert Service</li>
  <li>User Orientations</li>
  </ul><br>
      <h5><strong>Non  Book Materials</strong></h5>
      <p>The following non-book materials are also available in theCentral  library.<br>
        <br>
        CD-ROMS /DVD’s - 2699 Nos.<br>
        AUDIO CASSETTES - 06 Nos.<br>
  <br>
        Library provides a sizeable collection of Compact Discs and Audio/Videos  related to Engineering and Technology, management and related courses. All the  speeches of top professionals delivered have been archived in the CD ROM format  to enable the students and other users to imbibe the thoughts and values  espoused by such eminent personalities </p>
</div>
                </div>   
              </div>

              <div class="tab-pane fade " id="nptel">
                <div class="single_notice_pane">

                                            <div class="item">
                                                <img src="img/lib/nptel.jpg" class="img-responsive" alt=""> <br>
                                            </div>
                                         
                                            <p class="text-center"> <a href="http://nptel.ac.in/" target="_blank" class="btn btn-dark btn-theme-colored btn-xl">NPTEL Web site link </a></p>
                  
                </div>   
              </div>

              <div class="tab-pane fade " id="ill">
                <div class="single_notice_pane">
                  
  <h1 class="page-header">National &amp; International Libraries  </h1>
  <h3>National</h3>
  <table cellspacing="0" cellpadding="0" class="table table-bordered">
    <tbody><tr>
      <td valign="top"><p>Indian Institute of Technology Bombay </p></td>
      <td valign="top"><p><a href="http://www.library.iitb.ac.in/" target="_new">Central Library</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Indian Institute of Technology Delhi </p></td>
      <td valign="top"><p><a href="http://www.iitd.ac.in/acad/library/index.html" target="_new">Central Library</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Indian Institute of Technology Guwahati </p></td>
      <td valign="top"><p><a href="http://www.iitg.ernet.in/rs/lib/public_html/index.html" target="_new">Central Library</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Indian Institute of Technology Kanpur </p></td>
      <td valign="top"><p><a href="http://www.lib.iitk.ac.in/" target="_new">P.K. Kelkar Library</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Indian Institute of Technology Kharagpur </p></td>
      <td valign="top"><p><a href="http://www.library.iitkgp.ernet.in/" target="_new">Central Library</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Indian Institute of Technology Madras </p></td>
      <td valign="top"><p><a href="http://www.cenlib.iitm.ac.in/docs/library/index.php" target="_new">Central Library</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Indian Institute of Technology Roorkee </p></td>
      <td valign="top"><p><a href="http://www.iitr.ac.in/acads/centers/library/about.htm" target="_new">Central Library</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Indian Institute of Science Banglore </p></td>
      <td valign="top"><p><a href="http://www.library.iisc.ernet.in/" target="_new">Library</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Information Center for Aerospace Science and    Tech. </p></td>
      <td valign="top"><p><a href="http://www.cmmacs.ernet.in/nal/icast/icast.html" target="_new">Library</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>National Centre for Science Information, Bangalore </p></td>
      <td valign="top"><p><a href="http://www.ncsi.iisc.ernet.in/" target="_new">Library</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Indian Institute of Management, Kozhikode </p></td>
      <td valign="top"><p><a href="http://www.iimk.ac.in/faciliti/library.htm" target="_new">Library</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Indian Institute of Management, Calcutta </p></td>
      <td valign="top"><p><a href="http://www.iimcal.ac.in/" target="_new">Library</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Indian Institute of Management, Bangalore </p></td>
      <td valign="top"><p><a href="http://www.iimb.ernet.in/html/m-frames.jsp?ilink=7&amp;pname=library.htm" target="_new">Library</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Indian Institute of Management, Indore </p></td>
      <td valign="top"><p><a href="http://www.iimidr.ac.in/iim/pages/institute/facilitiesLibrary.jsp" target="_new">Library</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Indian Institute of Management, Ahemdadbad </p></td>
      <td valign="top"><p><a href="http://www.iimahd.ernet.in/library/" target="_new">Library</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Indian Statistical Institute, Calcutta </p></td>
      <td valign="top"><p><a href="http://www.isical.ac.in/~library/" target="_new">Library</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>National Institute of Technology,Calicut </p></td>
      <td valign="top"><p><a href="http://www.nalanda.nitc.ac.in/" target="_new">Library</a></p></td>
    </tr>
  </tbody></table>
<h3>International</h3>
  <table border="1" cellspacing="0" cellpadding="0" class="table table-bordered">
    <tbody><tr>
      <td width="74%" valign="top"><p>Massachusetts Institute of Technology </p></td>
      <td width="26%" valign="top"><p><a href="http://libraries.mit.edu/" target="_new">Libraries</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Georgia Institute of Technology </p></td>
      <td valign="top"><p><a href="http://www.library.gatech.edu/" target="_new">e-Library</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>California Institute of Technology </p></td>
      <td valign="top"><p><a href="http://library.caltech.edu/" target="_new">Library</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Canada Institute for Scientific and    Technical Information </p></td>
      <td valign="top"><p><a href="http://www.nrc-cnrc.gc.ca/cisti/cisti_e.shtml" target="_new">CISTE</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Stanford University </p></td>
      <td valign="top"><p><a href="http://www-sul.stanford.edu/" target="_new">SUL</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Library of Congress </p></td>
      <td valign="top"><p><a href="http://www.loc.gov/index.html" target="_new">Library</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>British Library </p></td>
      <td valign="top"><p><a href="http://www.bl.uk/" target="_new">Library</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>University of Technology Sydney </p></td>
      <td valign="top"><p><a href="http://www.citny.aus/" target="_new">Library</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>RMIT </p></td>
      <td valign="top"><p><a href="http://www.rmit.edu.au/library" target="_new">Library</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Canberra Institute of Technology </p></td>
      <td valign="top"><p><a href="http://cit.edu.au/studentservices/library/index.php" target="_new">Library</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>European Library </p></td>
      <td valign="top"><p><a href="http://www.theeuropeanlibrary.org/tel4/" target="_new">TEL</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Virtual Technical Reports Center </p></td>
      <td valign="top"><p><a href="http://www.lib.umd.edu/epsl" target="_new">VTRC</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Hong Kong University of Science and    Technology </p></td>
      <td valign="top"><p><a href="http://library.ust.hk/" target="_new">Library</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>UMIST UK </p></td>
      <td valign="top"><p><a href="http://www2.umist.ac.uk/library/" target="_new">Library</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Virginia Tech. University Libraries </p></td>
      <td valign="top"><p><a href="http://techserv.lib.vt.edu/" target="_new">Library</a></p></td>
    </tr>
  </tbody></table>
<h3>Library Networks</h3>
  <table border="1" cellspacing="0" cellpadding="0" class="table table-bordered">
    <tbody><tr>
      <td width="75%" valign="top"><p>Ahmedabad Library Network </p></td>
      <td width="25%" valign="top"><p><a href="http://www.alibnet.org/cgi-sys/suspendedpage.cgi" target="_new">ADINET</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Bombay Library Network </p></td>
      <td valign="top"><p><a href="file:///C:\Documents%20and%20Settings\Admin\Desktop\MKCE\library.html" target="_new">BONET</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Calcutta Library Network </p></td>
      <td valign="top"><p><a href="http://www.calibnet.org/" target="_new">CALIBNET</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Developing Library Network </p></td>
      <td valign="top"><p><a href="http://www.delnet.nic.in/" target="_new">DELNET</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Information &amp; Library Network Centre </p></td>
      <td valign="top"><p><a href="http://www.inflibnet.ac.in/" target="_new">INFLIBNET</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Pune Library Network </p></td>
      <td valign="top"><p><a href="http://www.bioinfo.ernet.in/punet2/" target="_new">PUNENET</a></p></td>
    </tr>
    <tr>
      <td valign="top"><p>Mysore Library Network </p></td>
      <td valign="top"><p><a href="http://www.mylibnet.org/" target="_new">MYlibnet</a></p></td>
    </tr>
  </tbody></table>
<p>&nbsp;</p>
                </div>   
              </div>

              <div class="tab-pane fade " id="web">
                <div class="single_notice_pane">
                  <br>
                  <h3>Web OPAC(Online Public Access Catalog)</h3>
                  <p>The concept of Web OPACs is recent origin and it is serving as a gateway to the resources not only held by the respective library but also to the holdings of other participating libraries without to local collection but going, beyond further to regional , national, international levels.</p><br>
                  <p>Web OPAC available in Institute's LAN : <a>\\192.182.172.200/opac/index.asp</a></p>
                </div>   
              </div>

              <div class="tab-pane fade " id="journals">
                <div class="single_notice_pane">
                  <div id="main_left" style="width:759px">
    <h3 style="font-size:20px;">JOURNALS</h3>

    <br>

  <span id="jrnl_text" style="color:green;font-size:16px;">UNDER SELF-SUPPORTING</span><br><br>
      <ul class="list_nav">
        <li><a href="http://ieeexplore.ieee.org" style="font-size:14px;">IEEE/IET Electronic Library(IEL) Online</a></li>
        <li class="snd"><a href="http://www.sciencedirect.com" style="font-size:14px;">Science Direct</a>
          <ul class="list_nav1"><li><a href="http://www.sciencedirect.com/science/journals/sub/chemicaleng/all">Chemical Engineering</a></li>
          <li><a href="http://www.sciencedirect.com/science?_ob=BrowseListURL&amp;_type=subject&amp;subjColl=15&amp;zone=brws&amp;_acct=C000052774&amp;_version=1&amp;_urlVersion=0&amp;_userid=8740403&amp;md5=a568e7db9706a2d0d1a6b777567c31b3">Energy</a></li>
          <li><a href="http://www.sciencedirect.com/science?_ob=BrowseListURL&amp;_type=subject&amp;subjColl=16&amp;zone=brws&amp;_acct=C000052774&amp;_version=1&amp;_urlVersion=0&amp;_userid=8740403&amp;md5=a568e7db9706a2d0d1a6b777567c31b3">Engineering</a></li>
          <li><a href="http://www.sciencedirect.com/science/journals/sub/materialsscience/all">Materials Science</a></li>
        </ul>
      </li>
      <li href="http://www.sciencedirect.com" style="font-size:14px;"><a href="http://www.sciencedirect.com">Science Direct (Engineering Backfiles)</a></li>
      <li href="http://www.sciencedirect.com" style="font-size:14px;"><a href="http://www.sciencedirect.com">Science Direct (Material Science Backfiles)</a></li>
      <li><a href="https://saemobilus.sae.org/" style="font-size:14px;">SAE International Journals</a></li>
      <li><a href="http://www.scopus.com" style="font-size:14px;">SCOPUS</a></li>
      <li><a href="http://www.emeraldinsight.com/" style="font-size:14px;">Emerald&nbsp;(Accounting &amp; Finance, Management Science &amp; Operations)</a></li>
      <li><a href="http://search.proquest.com/technology1?accountid=170300" style="font-size:14px;">Engineering Research Resource - ProQuest Technology Collection</a></li>
      <li><a href="https://www.jove.com/journal/cancer-research" style="font-size:14px;">JoVE Journal - Cancer Research ( Video Journal) </a></li>
      <li><a href="http://www.webofknowledge.com/" style="font-size:14px;">Web of Science*</a></li>
      <li><a href="http://olabout.wiley.com/WileyCDA/Section/id-815577.html" style="font-size:14px;">Wiley Online Library (908 Wiley-Blackwell Journals)</a></li>
    </ul><br>

  <span id="jrnl_text" style="color:green;font-size:16px;">UNDER E-SHODHSINDU : CONSORTIUM FOR HIGHER EDUCATION ELECTRONIC RESOURCES</span><br><br>
  <ul class="list_nav" style="width:90%">
    <li><a href="http://www.pubs.acs.org">American Chemical Society</a></li>
    <li><a href="http://ascelibrary.org">ASCE Journals Online</a></li>
    <li><a href="https://asmedigitalcollection.asme.org/">ASME Journals Online</a></li>
    <li><a href="http://isid.org.in/">Institute for Studies in Industrial Development (ISID) Database*</a></li>
        <li><a href="http://jgateplus.com">JGate Plus (JCCC)*</a></li>
    <li><a href="http://www.jstor.org">JSTOR</a></li>
    <li><a href="http://www.ams.org/mathscinet">MathSciNet*</a></li>
    <li><a href="http://www.oxfordjournals.org">Oxford University Press</a></li>
    <li><a href="http://www.springerlink.com">Springer Link 1700 Collection and Nature Journal</a></li>
    <li><a href="http://www.tandfonline.com/">Taylor and Francis Journals</a></li>
  </ul>
    </div>
                </div>   
              </div>

              <div class="tab-pane fade " id="qbs">
                <div class="single_notice_pane">
                  <center><br><span class="title">Regulation 2017 for Batch 2018 - 2022</span> <br><br>
        <table cellspacing="0" cellpadding="0" align="center" border="1" id="table4">
            <tbody><tr bgcolor="#14F52B" height="30px"><td colspan="3"><a href="Downloads/AU_syllabus/R2017_Mech.pdf" target="_blank"><center><b>Mech. - Academic Regulation &amp; Syllabus</b></center></a></td></tr>
            <tr bgcolor="#14F52B" height="30px"><td colspan="3"><a href="Downloads/AU_syllabus/R2017_EEE.pdf" target="_blank"><center><b>EEE. - Academic Regulation &amp; Syllabus</b></center></a></td></tr>
            <tr bgcolor="#14F52B" height="30px"><td colspan="3"><a href="Downloads/AU_syllabus/R2017_ECE.pdf" target="_blank"><center><b>ECE. - Academic Regulation &amp; Syllabus</b></center></a></td></tr>
            <tr bgcolor="#14F52B" height="30px"><td colspan="3"><a href="Downloads/AU_syllabus/R2017_CSE.pdf" target="_blank"><center><b>CSE. - Academic Regulation &amp; Syllabus</b></center></a></td></tr>
            <tr bgcolor="#14F52B" height="30px"><td colspan="3"><a href="Downloads/AU_syllabus/R2017_IT.pdf" target="_blank"><center><b>IT. - Academic Regulation &amp; Syllabus</b></center></a></td></tr>
            <tr bgcolor="#14F52B" height="30px"><td colspan="3"><a href="Downloads/AU_syllabus/R2017_AuE.pdf" target="_blank"><center><b>AuE. - Academic Regulation &amp; Syllabus</b></center></a></td></tr>
            <tr bgcolor="#14F52B" height="30px"><td colspan="3"><a href="Downloads/AU_syllabus/R2017_EIE.pdf" target="_blank"><center><b>EIE. - Academic Regulation &amp; Syllabus</b></center></a></td></tr>
                      </tbody></table>
            <br><span class="title">Regulation 2017 for Batch 2017 - 2021</span> <br><br>
        <table cellspacing="0" cellpadding="0" align="center" border="1" id="table-alt">
            <tbody><tr bgcolor="#14F52B" height="30px"><td colspan="3"><a href="Downloads/AU_syllabus_2017-18/R2017_Mech.pdf" target="_blank"><center><b>Mech. - Academic Regulation &amp; Syllabus</b></center></a></td></tr>
            <tr bgcolor="#14F52B" height="30px"><td colspan="3"><a href="Downloads/AU_syllabus_2017-18/R2017_EEE.pdf" target="_blank"><center><b>EEE. - Academic Regulation &amp; Syllabus</b></center></a></td></tr>
            <tr bgcolor="#14F52B" height="30px"><td colspan="3"><a href="Downloads/AU_syllabus_2017-18/R2017_ECE.pdf" target="_blank"><center><b>ECE. - Academic Regulation &amp; Syllabus</b></center></a></td></tr>
            <tr bgcolor="#14F52B" height="30px"><td colspan="3"><a href="Downloads/AU_syllabus_2017-18/R2017_CSE.pdf" target="_blank"><center><b>CSE. - Academic Regulation &amp; Syllabus</b></center></a></td></tr>
            <tr bgcolor="#14F52B" height="30px"><td colspan="3"><a href="Downloads/AU_syllabus_2017-18/R2017_IT.pdf" target="_blank"><center><b>IT. - Academic Regulation &amp; Syllabus</b></center></a></td></tr>
            <tr bgcolor="#14F52B" height="30px"><td colspan="3"><a href="Downloads/AU_syllabus_2017-18/R2017_AuE.pdf" target="_blank"><center><b>AuE. - Academic Regulation &amp; Syllabus</b></center></a></td></tr>
            <tr bgcolor="#14F52B" height="30px"><td colspan="3"><a href="Downloads/AU_syllabus_2017-18/R2017_EIE.pdf" target="_blank"><center><b>EIE. - Academic Regulation &amp; Syllabus</b></center></a></td></tr>
            
             </tbody></table>
            <br><span class="title">Regulation 2013 for Batch 2014 - 2018, 2015 - 2019, 2016 - 2020</span> <br><br>
            <table cellspacing="0" cellpadding="0" align="center" border="1" id="table-alt">
            <tbody><tr bgcolor="#14F52B" height="30px"><td colspan="3"><a href="Downloads/AU_syllabus/R2013-Mech-I-VIII-aulibrary.pdf" target="_blank"><center><b>Mech. - Academic Regulation &amp; Syllabus</b></center></a></td></tr>
            <tr bgcolor="#14F52B" height="30px"><td colspan="3"><a href="Downloads/AU_syllabus/R2013-EEE-I-VIII-aulibrary.pdf" target="_blank"><center><b>EEE. - Academic Regulation &amp; Syllabus</b></center></a></td></tr>
            <tr bgcolor="#14F52B" height="30px"><td colspan="3"><a href="Downloads/AU_syllabus/R2013-ECE-I-VIII-aulibrary.pdf" target="_blank"><center><b>ECE. - Academic Regulation &amp; Syllabus</b></center></a></td></tr>
            <tr bgcolor="#14F52B" height="30px"><td colspan="3"><a href="Downloads/AU_syllabus/R2013-CSE-I-VIII-aulibrary.pdf" target="_blank"><center><b>CSE. - Academic Regulation &amp; Syllabus</b></center></a></td></tr>
            <tr bgcolor="#14F52B" height="30px"><td colspan="3"><a href="Downloads/AU_syllabus/R2013-IT-I-VIII-aulibrary.pdf" target="_blank"><center><b>IT. - Academic Regulation &amp; Syllabus</b></center></a></td></tr>
            <tr bgcolor="#14F52B" height="30px"><td colspan="3"><a href="Downloads/AU_syllabus/R2013-AU-I-VIII-aulibrary.pdf" target="_blank"><center><b>AuE. - Academic Regulation &amp; Syllabus</b></center></a></td></tr>
            <tr bgcolor="#14F52B" height="30px"><td colspan="3"><a href="Downloads/AU_syllabus/R2013-EIE-I-VIII-aulibrary.pdf" target="_blank"><center><b>EIE. - Academic Regulation &amp; Syllabus</b></center></a></td></tr>
            <tr bgcolor="#14F52B" height="30px"><td colspan="3"><a href="Downloads/AU_syllabus/R2013-ME-Cadcam-aulibrary.pdf" target="_blank"><center><b>ME(Cad/Cam). - Academic Regulation &amp; Syllabus</b></center></a></td></tr>
            <tr bgcolor="#14F52B" height="30px"><td colspan="3"><a href="Downloads/AU_syllabus/R2013-MEPSE-aulibrary.pdf" target="_blank"><center><b>ME(PSE). - Academic Regulation &amp; Syllabus</b></center></a></td></tr>
            <tr bgcolor="#14F52B" height="30px"><td colspan="3"><a href="Downloads/AU_syllabus/R2013-MECS-aulibrary.pdf" target="_blank"><center><b>ME(CS). - Academic Regulation &amp; Syllabus</b></center></a></td></tr>
            <tr bgcolor="#14F52B" height="30px"><td colspan="3"><a href="Downloads/AU_syllabus/R2013-MECSE-aulibrary.pdf" target="_blank"><center><b>ME(CSE). - Academic Regulation &amp; Syllabus</b></center></a></td></tr>
            <tr bgcolor="#14F52B" height="30px"><td colspan="3"><a href="Downloads/AU_syllabus/R2013-MECSEWSN-aulibrary.pdf" target="_blank"><center><b>ME(CSE with WSN). - Academic Regulation &amp; Syllabus</b></center></a></td></tr>
             </tbody></table></center>
                </div>   
              </div>

              </div> 
             </div>
             </div>
            </div>
          
          <!-- End course content -->

          
          <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="courseArchive_sidebar">
              
              <div class="single_sidebar">
                <h2>Events <span class="fa fa-angle-double-right"></span></h2>
               
                <ul class="news_tab">
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a class="news_img" href="#">
                         
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Technical Symposium - Students Acheivement</a>
                       <span class="feed_date">Mr.M.Devendran IV year civil won the second prize in Design context  and third prize in poster presentation held among variou...</span>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a class="news_img" href="#">
                          
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Foundation for Advancement of Education and Research, Bangalore - Best Project Award</a>
                       <span class="feed_date">The following students had presented a project titled “Wireless Security System featured with UWB/PIR Sensor and android app...</span>                
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a class="news_img" href="#">
                          <img class="media-object" src="img/fusion.png" alt="img">
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Auto desk Fusion 360 competition -  Mr. R.Gowtham of Final year Mechanical Engineering</a>
                       <span class="feed_date">Mr. R.Gowtham of Final year Mechanical Engineering student won the first prize in Auto desk Fusion 360 competition Conducted...</span>                
                      </div>
                    </div>
                  </li>                  
                </ul>
                <a class="see_all" href="#">See All</a>
              </div>
            </div>
          </div>
           
        </div>
      </div>
    </section>
    <!--=========== END COURSE BANNER SECTION ================-->
    
    <!--=========== BEGIN FOOTER SECTION ================-->
    <?php include 'php/footer.php';?>
    <!--=========== END FOOTER SECTION ================--> 

  

    <!-- Javascript Files
    ================================================== -->

    <!-- initialize jQuery Library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <!-- Preloader js file -->
    <script src="js/queryloader2.min.js" type="text/javascript"></script>
    <!-- For smooth animatin  -->
    <script src="js/wow.min.js"></script>  
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- slick slider -->
    <script src="js/slick.min.js"></script>
    <!-- superslides slider -->
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.animate-enhanced.min.js"></script>
    <script src="js/jquery.superslides.min.js" type="text/javascript" charset="utf-8"></script>   
    <!-- for circle counter -->
    <script src='https://cdn.rawgit.com/pguso/jquery-plugin-circliful/master/js/jquery.circliful.min.js'></script>
    <!-- Gallery slider -->
    <script type="text/javascript" language="javascript" src="js/jquery.tosrus.min.all.js"></script>   
   
    <!-- Custom js-->
    <script src="js/custom.js"></script>
  <!--=============================================== 
    Template Design By WpFreeware Team.
    Author URI : http://www.wpfreeware.com/
  ====================================================-->

  </body>
</html>
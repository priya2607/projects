<!DOCTYPE html>
<html lang="en">
 <head>
  <?php include 'php/head.php';?>
</head>
  <body>
     <!-- SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#"></a>
    <!-- END SCROLL TOP BUTTON -->

    <!--=========== BEGIN HEADER SECTION ================-->
    <?php include 'php/header.php';?>
    <!--=========== END HEADER SECTION ================--> 
    <section id="imgBanner">
      <h2>Master of Business Administration</h2>
    </section>
    <!--=========== END COURSE BANNER SECTION ================-->

    
    <!--=========== BEGIN COURSE BANNER SECTION ================-->
    <section id="courseArchive">
      <div class="container">
        <div class="row">
          <!-- start course content -->
          <div class="col-xs-12 col-lg-9">
            <div class="courseArchive_content">              
             <div class="singlecourse_ferimg_area">
              <div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/s/1.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/s/2.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/s/3.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/s/4.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/s/5.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>
</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 

</div></div></div></div>
<div class="col-xs-12 col-lg-3">
  <div class="mainevent">
  <img src="img/pg/1.jpg" width="100%">
    <div class="maineventcont clearfix">
      <h2>International <span>Conference</span></h2>
      <p>International Conference on innovation in 
        Communication, Information and Computing (ICICIC '13 Which held during 9th, 10th 
        ,11th  January 2013 Organized by the 
        department of CSE, IT,MCA</p>
      <p><a href="#" class="pull-right">+ Read More</a></p>
    </div>
  </div>
</div>
               <!--div class="singlecourse_ferimg">
                 <img src="img/course-single.jpg" alt="img">
               </div>  
                <div class="singlecourse_bottom">
                  <h2>Introduction To Matrix</h2>
                  <span class="singlecourse_author">
                    <img alt="img" src="img/author.jpg">
                    Richard Remus, Teacher
                  </span>
                  <span class="singlecourse_price">$20</span>
                </div-->
             </div>
             <div class="row">
<div class="col-xs-12 col-sm-9">
  
      <h1>M.E.  Computer Science And Engineering</h1>
<h2 class="page-header">Semester I</h2>
<h3>Theory</h3>
<ul class="list" style="margin-left:15px;">
        <li>Applied Probability and       Statistics</li>
        <li>Design and Management of       Computer Networks<strong> </strong></li>
        <li>Advanced Data Structures       and Algorithms<strong> </strong></li>
        <li>Multicore Architectures</li>
        <li>Elective I</li>
        <li>Elective II</li>
</ul>
<h3>Practical</h3>
<ul class="list" style="margin-left:15px;">
       <li>Advanced Data Structures       Laboratory</li>
       <li>Case Study - Network       Design (Team Work)</li>
</ul>
<h2 class="page-header">Semester II</h2>
<h3>Theory</h3>
<ul class="list" style="margin-left:15px;">
        <li>Theoretical Foundations of       Computer Science</li>
           <li>Advanced Databases</li>
           <li>Principles of Programming       Languages</li>
           <li>Advanced Operating Systems</li>
           <li>Elective III</li>
           <li>Elective IV</li>
</ul>
<h3>Practical</h3>
<ul class="list" style="margin-left:15px;">
        <li>Advanced Databases       Laboratory</li>
      <li>Case Study - Operating       Systems Design (Team Work)</li></ul>
<h2 class="page-header">Semester III</h2>
<h3>Theory</h3>
<ul class="list" style="margin-left:15px;">
        <li>Software Process and       Project Management</li>
           <li>Elective V</li>
           <li>Elective VI</li>
           <li>Elective VII</li>
</ul>
<h3>Practical</h3>
<ul class="list" style="margin-left:15px;">
        <li>
          Project Work (Phase I)
        </li>
</ul>          
 <h2 class="page-header">Semester IV</h2>
<h3>Practical</h3>
<ul class="list" style="margin-left:15px;">
        <li>
          Project Work (Phase II)
        </li>
</ul>  <br>
                 
<h1>Electives</h1>
<h2 class="page-header">Semester I</h2>
<h3>Elective-I</h3>
<ul class="list" style="margin-left:15px;">
  <li>Formal Models of Software Systems</li>
  <li>Performance Evaluation of Computer Systems</li>
  <li>Probabilistic Reasoning Systems</li>
  <li>Data Analysis and Business Intelligence</li>
  <li>Image Processing and       Analysis</li>
  <li>Sensing Techniques and Sensors<strong> </strong></li>
</ul>         
 <h3>Elective-II</h3>
<ul class="list" style="margin-left:15px;">
     <li>Randomized Algorithms</li>
     <li>Mobile and       Pervasive Computing</li>
     <li>Parallel Programming Paradigms</li>
     <li>Software Requirements Engineering</li>
     <li>Speech Processing and Synthesis</li>
     <li>Machine Learning Techniques</li>
</ul> 
<h2 class="page-header">Semester II</h2>
<h3>Elective-III</h3>
<ul class="list" style="margin-left:15px;">
 <li>Concurrency Models </li>
      <li>Real Time Systems </li>
      <li>Computer Vision </li>
      <li>Network and Information Security </li>
      <li>Design and Analysis of         Parallel Algorithms </li>
      <li>Software Architectures</li>
     </ul>      
 <h3>Elective-IV</h3>
<ul class="list" style="margin-left:15px;">
     <li>Model Checking and Program         Verification </li>
    
      <li>Embedded Software Development </li>
    
      <li>Cloud Computing </li>
    
      <li>Data Visualization Techniques </li>
    
      <li>Protocols and Architecture for         Wireless Sensor Networks </li>
    
      <li>Language Technologies </li>
    </ul>
    <h2 class="page-header">Semester III</h2>
    <h3>Elective-V</h3>
<ul class="list" style="margin-left:15px;">
     <li>Social Network Analysis </li>
    
      <li>Managing Big Data </li>
    
      <li>Mobile Application Development </li>
    
      <li>Bio-inspired Computing </li>
    
      <li>Medical Image Processing </li>
    
      <li>Software Design </li>
    </ul>  
     <h3>Elective-VI</h3>
<ul class="list" style="margin-left:15px;">
     <li>Reconfigurable Computing </li>
    
      <li>Energy Aware Computing </li>
    
      <li>Information Retrieval Techniques </li>
    
      <li>Data Mining Techniques </li>
    
      <li>Bio Informatics </li>
    
      <li>Software Quality Assurance </li>
    </ul>
     <h3>Elective-VII</h3>
<ul class="list" style="margin-left:15px;">
    <li>Multiobjective Optimization Techniques </li>
    
      <li>Enterprise Application Integration </li>
    
      <li>Information Storage Management </li>
    
      <li>Robotics </li>
    
      <li>Compiler Optimization Techniques </li>
    </ul>
    <h2 class="page-header">Program Educational Objectives (PEO):</h2>
    <div style="padding-left:20px;">
      <p>Graduates of this M. E. Computer Science and Engineering will be able to</p>
      <p>1.   Apply the necessary mathematical   tools and fundamental &amp; advanced knowledge of computer science &amp; engineering</p>
      <p>2.   Develop computer/software/network systems understanding the importance of social
      <p> business, technical, environmental,  and  human context in which the systems would work</p>
      <p> 3.   Articulate fundamental concepts, design underpinnings of computer/software/network
        systems,  and  research  findings   to   train   professionals   or   to  educate   engineering  students</p>
      <p>4.   Contribute   effectively   as   a    team   member/leader,    using   common   tools   and
        environment, in computer science and engineering projects, research, or education</p>
      <p>5.   Pursue  life-long  learning  and  research  in   selected   fields  of   computer  science   &amp;
        engineering and contribute to the growth of those fields and society at large</p>
         <h2 class="page-header">Program Outcomes:</h2>
         <p>Apply   knowledge  of mathematics,   science,   engineering   fundamentals  and  an engineering specializationto the conceptualization of engineering models.</p><p>1.Identify,  formulate,  research literature  and solve complexengineering problems reaching   substantiated   conclusions   using   first   principles  of   mathematics  andengineering sciences.</p><p>2.Design  solutions    for     complexengineering       problems            and        designsystems, components  or processes thatmeet specifiedneeds withappropriate consideration for public health and safety,cultural, societal, and environmental considerations.</p><p>3.Conduct   investigations  of  complex problems  including  design   of  experiments, analysis and interpretation ofdata, and synthesis ofinformationto provide validconclusions.</p><p>4.Create, select and apply appropriate techniques,resources, and modernengineeringtools, includingprediction  and modeling, to complexengineering  activities,  withan understanding of the limitations.</p><p>5.Function effectively asan individual,  and asa member or leaderin diverseteams and in multi-disciplinary settings.</p><p>6.Communicate  effectively  on  complexengineering activities with  the  engineering community and with societyat large,suchas beingable tocomprehend  and write effectivereportsand design documentation, makeeffective presentations, and giveand receive clear instructions.</p><p>7.Demonstrate understanding ofthe societal,health, safety,legal and cultural issues and the consequent responsibilities relevant toengineering practice.</p>    </div>
</div>
               <!--table class="table table-striped course_table">
                <thead>
                  <tr>          
                    <th>Course Title</th>
                    <th>Instructor</th>
                    <th>Timing</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>          
                    <td><a href="#">Computer Science &amp; Engineering</a></td>
                    <td>Dr. Steve Palmer</td>
                    <td>08:00 to 13:00</td>
                  </tr>
                  <tr>
                    <td><a href="#">Electronics &amp; Communications Engineering</a></td>          
                    <td>Jacob</td>                    
                    <td>08:00 to 13:00</td>
                  </tr>
                  <tr>
                    <td><a href="#">Civil Engineering</a></td>          
                    <td>Kimberly Jones</td>                    
                    <td>08:00 to 13:00</td>
                  </tr>
                  <tr>
                    <td><a href="#">Electrical &amp; Electronics Engineering</a></td>   

                    <td>Dr. Klee</td>                    
                    <td>08:00 to 13:00</td>
                  </tr>
                  <tr><td><a href="#">Mechanical Engineering</a></td> </tr>
                </tbody>
              </table-->
             </div>
             <script>
var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 1000); // Change image every 2 seconds
}
</script>

             <!-- start related course -->
             <!--div class="related_course">
                <h2>More Courses</h2>
                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="single_course wow fadeInUp" >
                      <div class="singCourse_imgarea">
                        <img src="img/course-1.jpg">
                        <div class="mask">                         
                          <a class="course_more" href="#">View Course</a>
                        </div>
                      </div>
                      <div class="singCourse_content">
                        <h3 class="singCourse_title"><a href="#">Introduction To Matrix</a></h3>
                        <p class="singCourse_price"><span>$20</span> Per One Month</p>
                        <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
                      </div>
                      <div class="singCourse_author">
                        <img alt="img" src="img/author.jpg">
                        <p>Richard Remus, Teacher</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="single_course wow fadeInUp" >
                      <div class="singCourse_imgarea">
                        <img src="img/course-1.jpg">
                        <div class="mask">                         
                          <a class="course_more" href="#">View Course</a>
                        </div>
                      </div>
                      <div class="singCourse_content">
                        <h3 class="singCourse_title"><a href="#">Introduction To Matrix</a></h3>
                        <p class="singCourse_price"><span>$20</span> Per One Month</p>
                        <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
                      </div>
                      <div class="singCourse_author">
                        <img alt="img" src="img/author.jpg">
                        <p>Richard Remus, Teacher</p>
                      </div>
                    </div>
                  </div>                                    
                </div>
              </div-->
              <!-- End related course -->
            </div>
          
          <!-- End course content -->

          <!-- start course archive sidebar -->
          
              <!-- start single sidebar -->
              <!--div class="single_sidebar">
                <h2>Events <span class="fa fa-angle-double-right"></span></h2>
                <ul class="news_tab">
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a href="#" class="news_img">
                          <img alt="img" src="img/news.jpg" class="media-object">
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Dummy text of the printing and typesetting industry</a>
                       <span class="feed_date">27.02.15</span>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a href="#" class="news_img">
                          <img alt="img" src="img/news.jpg" class="media-object">
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Dummy text of the printing and typesetting industry</a>
                       <span class="feed_date">28.02.15</span>                
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a href="#" class="news_img">
                          <img alt="img" src="img/news.jpg" class="media-object">
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Dummy text of the printing and typesetting industry</a>
                       <span class="feed_date">28.02.15</span>                
                      </div>
                    </div>
                  </li>                  
                </ul>
              </div-->
              <!-- End single sidebar -->
              <!-- start single sidebar -->
            
              <!-- End single sidebar -->
              <!-- start single sidebar -->
              <!--div class="single_sidebar">
                <h2>Sponsor Add <span class="fa fa-angle-double-right"></span></h2>
                <a class="side_add" href="#"><img src="img/side-add.jpg" alt="img"></a>
              </div-->
              <!-- End single sidebar -->
            </div>
          </div>
          <!-- start course archive sidebar -->
        </div>
      </div>
    </section>

     <!--=========== BEGIN FOOTER SECTION ================-->
  <?php include 'php/footer.php';?>
    <!--=========== END FOOTER SECTION ================--> 

  

    <!-- Javascript Files
    ================================================== -->

    <!-- initialize jQuery Library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <!-- Preloader js file -->
    <script src="js/queryloader2.min.js" type="text/javascript"></script>
    <!-- For smooth animatin  -->
    <script src="js/wow.min.js"></script>  
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- slick slider -->
    <script src="js/slick.min.js"></script>
    <!-- superslides slider -->
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.animate-enhanced.min.js"></script>
    <script src="js/jquery.superslides.min.js" type="text/javascript" charset="utf-8"></script>   
    <!-- for circle counter -->
    <script src='https://cdn.rawgit.com/pguso/jquery-plugin-circliful/master/js/jquery.circliful.min.js'></script>
    <!-- Gallery slider -->
    <script type="text/javascript" language="javascript" src="js/jquery.tosrus.min.all.js"></script>   
   
    <!-- Custom js-->
    <script src="js/custom.js"></script>
  <!--=============================================== 
    Template Design By WpFreeware Team.
    Author URI : http://www.wpfreeware.com/
  ====================================================-->
  </body>
  </html>
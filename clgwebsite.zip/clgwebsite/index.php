<!DOCTYPE html>
<html lang="en">
<head>
  <?php include 'php/head.php';?>
</head>
<body>    
 
    <!-- SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#"></a>
    <!-- END SCROLL TOP BUTTON -->
     

             <div class="container" style="margin-bottom:-20px">
        <div class="row">
        
        <div class="col-lg-6 col-md-6 col-sm-6">
         <div class="aboutus_area wow fadeInLeft"><p style="font-size:14px;color:#030" >
              <strong>Accredited By National Assessment and Accreditation Council (NAAC) </strong><br/>
          <strong>Listed under 2(F) & 12(B)</strong></p>
          </div></div>
        <div class="col-lg-6 col-md-6 col-sm-6">
         <div class="aboutus_area wow fadeInLeft"><div style="margin-bottom:15px;">
      <a href="" style="margin-top:10px;" class="btn btn-danger blink_me" data-target="#getInModal" data-toggle="modal"> <strong>Admissions Open</strong></a>
   <img src="img/counselling-code.gif" width="147" height="35" style="margin-top:10px">
<a href="/Broucher.pdf" target="_blank" class="btn btn-danger btn-xs active" download="e-brochure">Download Brochure</a> 
      &nbsp;<a href="http://sasurieengg.com/Prospectus" target="_blank" class="btn btn-danger btn-xs active">View Brochure</a> <a href="http://www.makevt.com/media/tourmaker/pxfoehvwit/" target="_blank" class="btn btn-info btn-xs active" style="margin-top:10px;">Sasurie Virtual Tour</a>
<a href="https://www.sce.directverify.in" target="_blank" class="btn btn-danger btn-xs active" >Online Student Certificate Verification</a>&nbsp;<a href="images/sasurie_AQAR16-17_V3.pdf" download class="btn btn-info btn-xs active" style="margin-top:10px;">NAAC - AQAR</a>&nbsp;<a href="images/nirf.html" download class="btn btn-info btn-xs active blink_me" style="margin-top:10px;">NIRF - Report</a>  
      </div>
    </div>
        </div></div></div>
          
  <?php include 'php/header.php';?>
   
<section id="slider">
      <div class="row">
        <div class="col-lg-12 col-md-12">
          <div class="slider_area">
            <!-- Start super slider -->
            <div id="slides">
              <ul class="slides-container">                          
                <li>
                  <img class="sld" src="img/banner.jpg" alt="img">
                   <div class="slider_caption">
                    <h2>TNEA CODE 2717</h2>
                    <p>Approved by AICTE and Affiliated to Anna University Chennai</p>
                    
                  </div>
                  <div class="slider_caption" style="text-align: left;">
                    <h2>Accredited By National Assessment and Accreditation Council (NAAC) Listed under 2(F)</h2>
                   
                  </div>
                  <div class="slider_caption">
                    <h2>Find out you in better way</h2>
                    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search</p>
                    
                  </div>
                </li>
              </ul>
              <nav class="slides-navigation">
                <a href="#" class="next"></a>
                <a href="#" class="prev"></a>
              </nav>
            </div>
          </div>
        </div>
      </div>
<script>
var myIndex = 0;
carousel();
function carousel() {
    var i;
    var x = document.getElementsByClassName("slider_caption");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";}
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 1000); // Change image every 2 seconds
}</script></section><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<!--=========== BEGIN SLIDER SECTION ================-->
<!--=========== END SLIDER SECTION ================-->

 

<!--<section id="courseArchive" style="align:center">
   <div class="container">
            <div class="section-header">
                <h2 class="section-title text-center wow fadeInDown">GALLERY</h2>
                <p class="text-center wow fadeInDown">College Gallery</p>
            </div>
            <div class="col-sm-12" class="mySlidesr"><center>
                <img class="mySlidesr" src="img/index/1.jpg" style="width:80%">
                <img class="mySlidesr" src="img/index/2.jpg" style="width:80%">
                <img class="mySlidesr" src="img/index/3.jpg" style="width:80%">
                <img class="mySlidesr" src="img/index/4.jpg" style="width:80%">
                <img class="mySlidesr" src="img/index/5.jpg" style="width:80%">
                <img class="mySlidesr" src="img/index/i1.jpg" style="width:80%">
                <img class="mySlidesr" src="img/index/i2.jpg" style="width:80%">
                <img class="mySlidesr" src="img/index/i3.jpg" style="width:80%">
                <img class="mySlidesr" src="img/index/i4.jpg" style="width:80%">
                <img class="mySlidesr" src="img/index/i4.jpg" style="width:80%">
              </center>
            <script>
var myIndex = 0;
carousel();
function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlidesr");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 4000); // Change image every 2 seconds
}</script></div>

</div>
</section> -->
    <!--=========== BEGIN ABOUT US SECTION ================-->
    <section id="aboutUs">
      <div class="container">
        <div class="row">
        <!-- Start about us area -->
        <div class="col-lg-6 col-md-6 col-sm-6">
         <div class="aboutus_area wow fadeInLeft">
            <h2 class="titile">About Us</h2>
            <p>Ponmudi Muthusamy Gounder Trust, Tirupur was founded in memory of the beloved father of the founder Chairman Sri.A.M.Kandaswami, a Philanthropist and Industrialist with a resolve to serve the society by providing quality education.</p>
          </div>
          
            <h2 class="titile">Administration</h2>
            <p>Chairman&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: Shri A.M. Kandaswami<br>
               Correspondent &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: Smt.Malarvizhi Kandaswami<br>
               Chief Executive Officer&nbsp;&nbsp; : Smt. K. Savitha Mohanraj<br>
               Secretary&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: Smt. A. K. Swathi<br>
               Principal&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: Dr. K. Pandiarajan </p>
          
        </div>
        <div class="col-lg-6 col-md-6 col-sm-6">
          <div class="newsfeed_area wow fadeInRight">
            <ul class="nav nav-tabs feed_tabs" id="myTab2">
              <li class="active"><a href="#news" data-toggle="tab">News</a></li>
              <li><a href="#notice" data-toggle="tab">Testimonials</a></li>
              <li><a href="#events" data-toggle="tab">Events</a></li>         
            </ul>

            <!-- Tab panes -->
            <div class="tab-content">
              <!-- Start news tab content -->
              <div class="tab-pane fade in active" id="news">                
                    <div class="media">
    <a href="gallery-details.php?id=85" class="pull-left">
      <img src="img/admin-gallery/thumbnail_1529741842.jpg" alt="64x64" width="64" height="64" class="media-object" style="width: 64px; height: 64px;" data-src="holder.js/64x64">
      </a>
    <h4><a href="gallery-details.php?id=85">International Yoga Day - 21.06.2018</a></h4>
<p class="small"> Posted on 23rd Jun 2018</p>
    </div>
  <div class="media">
    <a href="gallery-details.php?id=84" class="pull-left">
      <img src="img/admin-gallery/thumbnail_1520463615.jpg" alt="64x64" width="64" height="64" class="media-object" style="width: 64px; height: 64px;" data-src="holder.js/64x64">
      </a>
    <h4><a href="gallery-details.php?id=84">Shinelogics InfoTech PVT Ltd Centre of Excellence Inaguration</a></h4>
<p class="small"> Posted on 8th Mar 2018</p>
    </div>
  <div class="media">
    <a href="gallery-details.php?id=83" class="pull-left">
      <img src="img/admin-gallery/thumbnail_1519902447.jpg" alt="64x64" width="64" height="64" class="media-object" style="width: 64px; height: 64px;" data-src="holder.js/64x64">
      </a>
    <h4><a href="gallery-details.php?id=83">SMILE - 2K18 - Master of Business Administration - Symposium</a></h4>
<p class="small"> Posted on 1st Mar 2018</p>
    </div>   
                <a class="see_all" href="#">See All</a>
              </div>
              <!-- Start notice tab content -->  
              <div class="tab-pane fade " id="notice">
                <div class="single_notice_pane">
                  <ul class="news_tab">
                    <li>
                      <div class="media">
                        <div class="media-left">
                          <a class="news_img" href="#">
                            <img class="media-object" src="img/samson.jpg" alt="img">
                          </a>
                        </div>
                        <div class="media-body">
                         <a href="#">Mr Timothy Samson , Human Resources – Campus recruitment, Tech Mahindra.</a>
                         <span class="feed_date">Sasurie Seems to be a good place for learning where recruiters can do their maximum quality harvest in the near future. Hearty wishes from Tech Mahindra for the greatest success to be achieved. Work on accepting No limits, alternative thinking, driving positive change to Grow with us to Touch the Rise</span>
                        </div>
                      </div>                   
                    </li>
                    <li>
                      <div class="media">
                        <div class="media-left">
                          <a class="news_img" href="#">
                            <img class="media-object" src="img/Rangarajan.jpg" alt="img">
                          </a>
                        </div>
                        <div class="media-body">
                         <a href="#">Shri T S Rangarajan, Chair, IEEE Madras Section, Principal & Consultant, TCS.</a>
                         <span class="feed_date">ICICIC 13 Conference was a massive event & 1300 paper submission but managed very meticulously, collaboratively and quietly! Well done Team.</span>             
                        </div>
                      </div>
                    </li>
                    <li>
                      <div class="media">
                        <div class="media-left">
                          <a class="news_img" href="#">
                            <img class="media-object" src="img/Bhanu Kumar.jpg" alt="img">
                          </a>
                        </div>
                        <div class="media-body">
                         <a href="#">Mr S.Bhanu Kumar – Vice President, Cloud Infrastructure Services , NTT Data Global Delivery Serivces Limited</a>
                         <span class="feed_date">Thank you for the opportunity.</span>        
                        </div>
                      </div>
                    </li>                                    
                  </ul>
                  <ul class="news_tab">
                    <li>
                      <div class="media">
                        <div class="media-left">
                          <a class="news_img" href="#">
                            <img class="media-object" src="img/Stanley Geroge.jpg" alt="img">
                          </a>
                        </div>
                        <div class="media-body">
                        <a href="#">Mr Stanley George , Vice President – HR ( South India), Hexaware Technologies, Chennai.</a>
                        <span class="feed_date">An exciting day presenting degree to the students.Joy to see the glow in the student's eyes.Keep up the good work that you are doing in this region.Wish you all the best.</span>
                        </div>
                      </div>
                    </li>
                    <li>
                      <div class="media">
                        <div class="media-left">
                          <a class="news_img" href="#">
                            <img class="media-object" src="img/Chandrasekhar.jpg" alt="img">
                          </a>
                        </div>
                        <div class="media-body">
                         <a href="#">Mr C Chandrasekhar , Head- Human Resources, Atmel R& D India Pvt Ltd.</a>
                         <span class="feed_date">Good Team work, Excellent support and Extraordinary Infrastructure. Feel proud to have long term relationship with Sasurie.</span>          
                        </div>
                      </div>
                    </li>                                 
                  </ul>
                   <!--a class="see_all" href="#">See All</a-->
                </div>               
              </div>
              <!-- Start events tab content -->
              <div class="tab-pane fade " id="events">
                <ul class="news_tab">
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a class="news_img" href="#">
                          <!--img class="media-object" src="img/news.jpg" alt="img"-->
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Technical Symposium - Students Acheivement</a>
                       <span class="feed_date">Mr.M.Devendran IV year civil won the second prize in Design context  and third prize in poster presentation held among variou...</span>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a class="news_img" href="#">
                          <!--img class="media-object" src="img/news.jpg" alt="img"-->
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Foundation for Advancement of Education and Research, Bangalore - Best Project Award</a>
                       <span class="feed_date">The following students had presented a project titled “Wireless Security System featured with UWB/PIR Sensor and android app...</span>                
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a class="news_img" href="#">
                          <img class="media-object" src="img/fusion.png" alt="img">
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Auto desk Fusion 360 competition -  Mr. R.Gowtham of Final year Mechanical Engineering</a>
                       <span class="feed_date">Mr. R.Gowtham of Final year Mechanical Engineering student won the first prize in Auto desk Fusion 360 competition Conducted...</span>                
                      </div>
                    </div>
                  </li>                  
                </ul>
                <a class="see_all" href="#">See All</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      </div>
    </section>
    <!--=========== END ABOUT US SECTION ================--> 
 <section id="studentsTestimonial">
      <div class="container">
       <!-- Our courses titile -->
        <div class="row">
          <div class="col-lg-12 col-md-12"> 
            <div class="title_area">
              <h2 class="title_two">VISION MISSION QUALITY</h2>
              <span></span> 
            </div>
          </div>
        </div>
        <!-- End Our courses titile -->

        <!-- Start Our courses content -->
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="studentsTestimonial_content">              
              <div class="row">
                <!-- start single student testimonial -->
                <div class="col-lg-4 col-md-4 col-sm-4">
                  <div class="single_stsTestimonial wow fadeInUp">
                    <div class="stsTestimonial_msgbox">
                      <p>Our ambition is to develop a centre for imparting technical education with creativity and perform research with practical values to meet challenges of engineering environment and to achieve rural empowerment.</p>
                    </div>
                    <div class="stsTestimonial_content">
                      <h3>VISION</h3>
                    </div>
                  </div>
                </div>
                <!-- End single student testimonial -->
                <!-- start single student testimonial -->
                <div class="col-lg-4 col-md-4 col-sm-4">
                  <div class="single_stsTestimonial wow fadeInUp">
                    <div class="stsTestimonial_msgbox">
                      <p>The institute aims to produce innovative professionals with sound subject knowledge, research experience and social character for a sustainable growth of the nation by providing adequate training to develop education with leadership qualities.</p></div>
                    <div class="stsTestimonial_content">
                      <h3>MISSION</h3>                      
                      
                    </div>
                  </div>
                </div>
                <!-- End single student testimonial -->
                <!-- start single student testimonial -->
                <div class="col-lg-4 col-md-4 col-sm-4">
                  <div class="single_stsTestimonial wow fadeInUp">
                    <div class="stsTestimonial_msgbox">
                      <p>Quality policy of Sasurie College of Engineering is "Eminence in teaching through quality programs to make the young professionals self sustained and adaptable to the ever changing global impacts and need of the industry with social relevance"</p>
                    </div>
                    
                    <div class="stsTestimonial_content">
                      <h3>QUALITY</h3>                      
                      
                    </div>
                  </div>
                </div>
                <!-- End single student testimonial -->
              </div>
            </div>
          </div>
        </div>
        <!-- End Our courses content -->
      </div>
    </section>
    <!--=========== END STUDENTS TESTIMONIAL SECTION ================-->    
    <!--=========== BEGIN WHY US SECTION ================-->
    <section id="whyUs">
      <!-- Start why us top -->
      <div class="row">        
        <div class="col-lg-12 col-sm-12">
          <div class="whyus_top">
            <div class="container">
              <!-- Why us top titile -->
              <div class="row">
                <div class="col-lg-12 col-md-12"> 
                  <div class="title_area">
                    <h2 class="title_two">Backbones of Sasurie</h2>
                    <span></span> 
                  </div>
                </div>
              </div>
              <!-- End Why us top titile -->
              <!-- Start Why us top content  -->
              <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-4">
                  <div class="single_whyus_top wow fadeInUp">
                    <div class="whyus_icon">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <a href="http://sasurieinfo.tech/">
                      <img src="img/sit.png"  height="60%" ></img></a>
                    </div>
                    <h3>Sasurie Info Tech</h3>
                    <p class="con">A none of the kind of Software development cell driven by the Students of CSE department with the support of faculty members.</p>
                  </div>
                </div>
                
                <div class="col-lg-4 col-md-4 col-sm-4">
                  <div class="single_whyus_top wow fadeInUp">
                    <div class="whyus_icon">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <img src="img/geeks.png"  height="80%"></img>
                    </div>
                    <h3><a href="#">Sasurie Geeks Forum</a></h3>
                    <p>Forum is a student development skills and communication</p>
                  </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4">
                  <div class="single_whyus_top wow fadeInUp">
                    <div class="whyus_icon">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <img src="img/tech_geek_logo.psd"  height="60%" ></img>
                    </div>
                    <h3><a href="#">SRDC</a></h3>
                    <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
                  </div>
                </div>
              </div>
              <!-- End Why us top content  -->
            </div>
          </div>
        </div>        
      </div>
      <!-- End why us top -->

      <!-- Start why us bottom -->
      <div class="row">        
        <div class="col-lg-12 col-sm-12">
          <div class="whyus_bottom">            
            <div class="slider_overlay"></div>
            <div class="container">               
              <div class="skills">                
                <!-- START SINGLE SKILL-->
                <div class="col-lg-3 col-md-3 col-sm-3">
                 <div class="single_skill wow fadeInUp">
                   <div id="myStat" data-dimension="150" data-text="" data-info="" data-width="10" data-fontsize="25" data-percent="55" data-fgcolor="#999" data-bgcolor="#fff" ></div>
                    <h4>Repeate Learners</h4>                      
                  </div>
                </div>
                <!-- START SINGLE SKILL-->
                <div class="col-lg-3 col-md-3 col-sm-3">
                  <div class="single_skill wow fadeInUp">
                    <div id="myStathalf2" data-dimension="150" data-text="" data-info="" data-width="10" data-fontsize="25" data-percent="90" data-fgcolor="#999" data-bgcolor="#fff"></div>
                    <h4>Success Rate</h4>
                  </div>
                </div>
                <!-- START SINGLE SKILL-->
                <div class="col-lg-3 col-md-3 col-sm-3">                 
                  <div class="single_skill wow fadeInUp">
                    <div id="myStat2" data-dimension="150" data-text="" data-info="" data-width="10" data-fontsize="25" data-percent="80" data-fgcolor="#999" data-bgcolor="#fff" ></div>
                    <h4>Student Engagement</h4>
                  </div>
                </div>
                <!-- START SINGLE SKILL-->
                <div class="col-lg-3 col-md-3 col-sm-3">                 
                  <div class="single_skill wow fadeInUp">
                    <div id="myStat3" data-dimension="150" data-text="" data-info="" data-width="10" data-fontsize="25" data-percent="65" data-fgcolor="#999" data-bgcolor="#fff" ></div>
                    <h4>Certified Courses</h4>
                  </div>
                </div>
              </div>
            </div>            
          </div>
        </div>        
      </div>
      <!-- End why us bottom -->
    </section>
    <!--=========== END WHY US SECTION ================-->
    <!--=========== BEGIN OUR COURSES SECTION ================-->
    <section id="ourCourses">
      <div class="container">
       <!-- Our courses titile -->
        <div class="row">
          <div class="col-lg-12 col-md-12"> 
            <div class="title_area">
              <h2 class="title_two">Messages</h2>
              <span></span> 
            </div>
          </div>
        </div>
        <!-- End Our courses titile -->
        <!-- Start Our courses content -->
        <div class="row">
          
            <div class="ourCourse_content">
              <div class=" col-sm-4" >
                  <div class="single_course">
                    <div class="singCourse_imgarea">
                      <img src="img/amk.png" height="400px">
                      <div class="mask">                         
                        <a href="#" class="course_more">Chairman</a>
                      </div>
                    </div>
                    <div class="singCourse_content">
                    <h3 class="singCourse_title">Chairman</h3>
                    <p class="singCourse_price">Shri A.M. Kandaswami</p>
                    <p class="con">Education is the process of continuous growth and is lifelong.Educational Institutions should be the home and repository of fresh thoughts and new orientations. Whatever may be the transformation, it will be clear that education has two main aspects – the cultural aspects which make a person grow and, the production aspect which makes a person do things.These two aspects are not exclusive of each other. Education, science based and coherent with Indian culture and values, alone can provide the foundation for the nation's security and welfare.It is a matter of great pride and satisfaction that gives me great pleasure to announce that Sasurie Institutions are developing as centres of excellence for quality professional education, research and training.you will have better insight into this abode of education.Wish you a nice day.</p>
                    </div>
                    </div></div>
                <div class="col-sm-4" >
                  <div class="single_course">
                    <div class="singCourse_imgarea">
                      <img src="img/ceo2.jpg" height="400px">
                      <div class="mask">                         
                        <a href="#" class="course_more">CEO</a>
                      </div>
                    </div>
                    <div class="singCourse_content">
                    <h3 class="singCourse_title">CEO</h3>
                    <p class="singCourse_price">Smt. K. Savitha Mohanraj</p>
                    <p class="con">Education is a reflection of good civilisation, which helps us to be a good being. Our college works to mould the young minds. We just not only educate the students but also how to apply the source of knowledge in the society, when it is in need. We believe in literal practice than the text books. We teach them how to combat in this competitive world, which prevents from the alienation. Our institution’s main focus is to yield wakefulness for the students about their social and national responsibilities.We provide wide opportunities for the student’s, right from the first year in many sorts of events, which establish their self-confidence to stand unique from others. Our institutions, motive was put together in a word called “Education” like “Gurukulam” where we teach not only about the texts but about all the ethic, tactics and values of moral life.</p>
                    </div>
                  </div></div>
                <div class="col-md-4" >
                  <div class="single_course">
                    <div class="singCourse_imgarea">
                      <img src="img/principal.jpg" height="400px">
                      <div class="mask">                         
                        <a href="#" class="course_more">Principal</a>
                      </div>
                    </div>
                    <div class="singCourse_content">
                    <h3 class="singCourse_title">Principal</h3>
                    <p class="singCourse_price">Dr. K. Pandiarajan</p>
                    <p class="con">Today, the role of a college is not only to pursue academic excellence but also to motivate and empower its students to be lifelong learners, critical thinkers and productive members of an ever-changing global society. 
                    Our Honorable founder has dedicated this institute to empower engineers of the country to achieve quality education imbibed with professional and ethical values.
                    The Sasurie College of Engineering provide exemplary infrastructural facilities, a team of highly qualified and dedicated faculty and the exhilarating atmosphere in the campus which will surely take you to enviable heights and achievements.
                    And we strongly believe that "Use of current technologies and creation of new technologies are the fundamentals of engineering profession". 
                    So we strive to give all our students numerous opportunities to develop. </p><!--and to cultivate their talents through enrichment, engagement and extra-curricular activities.Here is the opportunity for you to make the right choice, which will lead you to a successful and satisfying profession as a useful and responsible citizen of our great nation.</p>-->
                    </div>
                  </div>
                </div>
            </div>
          </div>
        </div></div>
        <!-- End Our courses content -->
      </div>
    </section>
    <!--=========== END OUR COURSES SECTION ================-->  
    <!--=========== BEGIN OUR TUTORS SECTION ================-->
    <section id="ourTutors">
    
 <div class="container">
       <!-- Our courses titile -->
        <div class="row">
          <div class="col-xs-12">
  <div class="logocontainer" style="padding:10px; height:auto;">
  <h3 class="page-header" style="margin-top:0px;">Congratulations to the students placed in leading companies.</h3>
    <div id="s2" class="is" style="text-transform: uppercase; height: 150px; overflow: hidden; width: 100%; position: relative; left: 0px; top: 0px;"><div id="s21" class="my1" style="position: absolute; ">       <marquee behavior="scroll" direction="left" onmouseover="this.stop();" onmouseout="this.start();">
                <a href="javascript:;"> TECHNOSYS <br><img src="placed-students-2018/TECHNOSYS/mythili.jpg" height="120"></a> 
                 <a href="javascript:;"> TECHNOSYS <br><img src="placed-students-2018/TECHNOSYS/sivasankarai.jpg" height="120"></a> 
                 <a href="javascript:;"> TECHNOSYS <br><img src="placed-students-2018/TECHNOSYS/balaabirami.jpg" height="120"></a> 
                 <a href="javascript:;"> TECHNOSYS <br><img src="placed-students-2018/TECHNOSYS/keerthana.JPG" height="120"></a> 
                 <a href="javascript:;"> TECHNOSYS <br><img src="placed-students-2018/TECHNOSYS/Divya.jpg" height="120"></a> 
                 <a href="javascript:;"> TECHNOSYS <br><img src="placed-students-2018/TECHNOSYS/kamaleshwari.jpg" height="120"></a> 
                  <a href="javascript:;"> Vivid Infotech <br><img src="placed-students-2018/Vivid Infotech/revathi.jpg" height="120"></a> 
                  <a href="javascript:;"> Uniq <br><img src="placed-students-2018/Uniq/ganeshan.jpg" height="120"></a> 
                 <a href="javascript:;"> Uniq <br><img src="placed-students-2018/Uniq/Kaviraj.jpg" height="120"></a> 
         <a href="javascript:;"> Shinelogics <br><img src="placed-students-2018/Shinelogics/mythili.jpg" height="120"></a> 
                 <a href="javascript:;"> Shinelogics <br><img src="placed-students-2018/Shinelogics/sivasankarai.jpg" height="120"></a> 
                 <a href="javascript:;"> Shinelogics <br><img src="placed-students-2018/Shinelogics/sharmila.jpg" height="120"></a> 
                 <a href="javascript:;"> Shinelogics <br><img src="placed-students-2018/Shinelogics/yasodha.jpg" height="120"></a> 
                 <a href="javascript:;"> Shinelogics <br><img src="placed-students-2018/Shinelogics/arunkumar.jpg" height="120"></a> 
                 <a href="javascript:;"> Shinelogics <br><img src="placed-students-2018/Shinelogics/Vignesh.jpg" height="120"></a> 
                 <a href="javascript:;"> Shinelogics <br><img src="placed-students-2018/Shinelogics/kowsalya.jpg" height="120"></a> 
                 <a href="javascript:;"> Shinelogics <br><img src="placed-students-2018/Shinelogics/mohanapriya.jpg" height="120"></a> 
                 <a href="javascript:;"> Shinelogics <br><img src="placed-students-2018/Shinelogics/indhumathi.jpg" height="120"></a> 
                 <a href="javascript:;"> Shinelogics <br><img src="placed-students-2018/Shinelogics/rajeshkumar.jpg" height="120"></a> 
                 <a href="javascript:;"> Shinelogics <br><img src="placed-students-2018/Shinelogics/OmShakthi.jpg" height="120"></a> 
                 <a href="javascript:;"> Shinelogics <br><img src="placed-students-2018/Shinelogics/Mangayarkarasi.jpg" height="120"></a> 
                 <a href="javascript:;"> Shinelogics <br><img src="placed-students-2018/Shinelogics/ganeshan.jpg" height="120"></a> 
                 <a href="javascript:;"> Shinelogics <br><img src="placed-students-2018/Shinelogics/Suriiya.jpg" height="120"></a> 
                 <a href="javascript:;"> Shinelogics <br><img src="placed-students-2018/Shinelogics/dinesh kumarS.jpg" height="120"></a> 
                 <a href="javascript:;"> Shinelogics <br><img src="placed-students-2018/Shinelogics/Divya.jpg" height="120"></a> 
                 <a href="javascript:;"> Shinelogics <br><img src="placed-students-2018/Shinelogics/Kaviraj.jpg" height="120"></a> 
                 <a href="javascript:;"> Shinelogics <br><img src="placed-students-2018/Shinelogics/kavitha copy.jpg" height="120"></a> 
         
                <a href="javascript:;"> IVTL Infoview <br><img src="placed-students-2018/IVTL Infoview/rajeshkumar.jpg" height="120"></a> 
                 <a href="javascript:;"> IVTL Infoview <br><img src="placed-students-2018/IVTL Infoview/Tendulkar.jpg" height="120"></a> 
               
        </div></marquee>
        </div>
  </div>
</div></div>
        </div></div>
    </section>
    <?php include 'php/footer.php';?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <!-- Preloader js file -->
    <script src="js/queryloader2.min.js" type="text/javascript"></script>
    <!-- For smooth animatin  -->
    <script src="js/wow.min.js"></script>  
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- slick slider -->
    <script src="js/slick.min.js"></script>
    <!-- superslides slider -->
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.animate-enhanced.min.js"></script>
    <script src="js/jquery.superslides.min.js" type="text/javascript" charset="utf-8"></script>   
    <!-- for circle counter -->
    <script src='https://cdn.rawgit.com/pguso/jquery-plugin-circliful/master/js/jquery.circliful.min.js'></script>
    <!-- Gallery slider -->
    <script type="text/javascript" language="javascript" src="js/jquery.tosrus.min.all.js"></script>   
   
    <!-- Custom js-->
    <script src="js/custom.js"></script>
    <!--=============================================== 
   
    ====================================================-->


  </body>
</html>
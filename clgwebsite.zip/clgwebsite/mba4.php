<!DOCTYPE html>
<html lang="en">
  <head>
  <?php include 'php/head.php';?>
</head>
  <body>
     <!-- SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#"></a>
    <!-- END SCROLL TOP BUTTON -->

    <!--=========== BEGIN HEADER SECTION ================-->
     <?php include 'php/header.php';?>
    <!--=========== END HEADER SECTION ================--> 
    <section id="imgBanner">
      <h2>Master of Business Administration</h2>
    </section>
    <!--=========== END COURSE BANNER SECTION ================-->

    
    <!--=========== BEGIN COURSE BANNER SECTION ================-->
    <section id="courseArchive">
      <div class="row">
<div class="container">
<div class="inner department">
  <div class="col-lg-8 col-md-8 col-sm-8">
      <h1>Master of Business Administration</h1>  
      <h5>E-Course Material</h5>
    
              
      <div class="row" style="font-size:13px;">
  <div class="col-sm-4">
       <div class="list-group"> <a href="javascript:;" class="list-group-item active"><strong>I-Year-Sem-2</strong></a>
              <a href="mba-course-material-I-Year-Sem-2+BA7202 FINANCIAL MANAGEMENT.htm" class="list-group-item bfirst">BA7202 FINANCIAL MANAGEMENT</a>
               <a href="mba-course-material-I-Year-Sem-2+BA7204 HUMAN_RESOURCE_MANAGEMENT.htm" class="list-group-item bfirst">BA7204 HUMAN_RESOURCE _MANAGEMENT</a>
               <a href="mba-course-material-I-Year-Sem-2+BA7207 BUSINESS_RESEARCH_METHODS.htm" class="list-group-item bfirst">BA7207 BUSINESS_RESEARCH METHODS</a>
               <a href="mba-course-material-I-Year-Sem-2+BA7205 INFORMATION_MANAGEMENT.htm" class="list-group-item bfirst">BA7205 INFORMATION_MANAGEMENT</a>
               <a href="mba-course-material-I-Year-Sem-2+BA7201 OPERATIONS MANAGEMENT.htm" class="list-group-item bfirst">BA7201 OPERATIONS MANAGEMENT</a>
               <a href="mba-course-material-I-Year-Sem-2+BA7203 MARKETING MANAGEMENT.htm" class="list-group-item bfirst">BA7203 MARKETING MANAGEMENT</a>
               </div>
</div>
<div class="col-sm-4">
       <div class="list-group"> <a href="javascript:;" class="list-group-item active"><strong>II-Year-Sem-3</strong></a>
              <a href="mba-course-material-II-Year-Sem-3+BA7032 STRATEGIC_MANAGEMENT.htm" class="list-group-item bfirst">BA7032 STRATEGIC_MANAGEMENT</a>
               <a href="mba-course-material-II-Year-Sem-3+BA7022 MERCHANT BANKING AND FINANCIAL SERVICES.htm" class="list-group-item bfirst">BA7022 MERCHANT BANKING AND FINANCIAL SERVICES</a>
               <a href="mba-course-material-II-Year-Sem-3+BA7015 CUSTOMER RELATIONSHIP MANAGEMENT.htm" class="list-group-item bfirst">BA7015 CUSTOMER RELATIONSHIP MANAGEMENT</a>
               <a href="mba-course-material-II-Year-Sem-3+BA7013 SERVICE_MARKETING.htm" class="list-group-item bfirst">BA7013 SERVICE_MARKETING</a>
               <a href="mba-course-material-II-Year-Sem-3+BA7016 RURAL MARKETING.htm" class="list-group-item bfirst">BA7016 RURAL MARKETING</a>
               <a href="mba-course-material-II-Year-Sem-3+BA7301 ENTERPRISE RESOURCE PLANNING.htm" class="list-group-item bfirst">BA7301 ENTERPRISE RESOURCE PLANNING</a>
               <a href="mba-course-material-II-Year-Sem-3+BA7031 MANAGERIAL BEHAVIOUR AND EFFECTIVENESS.htm" class="list-group-item bfirst">BA7031 MANAGERIAL BEHAVIOUR AND EFFECTIVENESS</a>
               <a href="mba-course-material-II-Year-Sem-3+BA7034 INDUSTRIAL RELATIONS AND LABOUR WELFARE.htm" class="list-group-item bfirst">BA7034 INDUSTRIAL RELATIONS AND LABOUR WELFARE</a>
               <a href="mba-course-material-II-Year-Sem-3+BA7032 ENTREPRENEURSHIP DEVELOPMENT.htm" class="list-group-item bfirst">BA7032 ENTREPRENEURSHIP DEVELOPMENT</a>
               <a href="mba-course-material-II-Year-Sem-3+BA7021 SECURITY ANALYSIS AND PORTFOLIO MANAGEMENT.htm" class="list-group-item bfirst">BA7021 SECURITY ANALYSIS AND PORTFOLIO MANAGEMENT</a>
               <a href="mba-course-material-II-Year-Sem-3+BA7026 BANKING FINANCIAL SERVICES MANAGEMNT.htm" class="list-group-item bfirst">BA7026 BANKING FINANCIAL SERVICES MANAGEMNT</a>
               </div></div>
<div class="col-sm-4">
       <div class="list-group"> <a href="javascript:;" class="list-group-item active"><strong>II-Year-Sem-4</strong></a>
              <a href="mba-course-material-II-Year-Sem-4+BA7402 BUSINESS ETHICS,CORPORATE SOCIAL RESPONSIBILITY AND GOVERNANCE.htm" class="list-group-item bfirst">BA7402 BUSINESS ETHICS,CORPORATE SOCIAL RESPONSIBILITY AND GOVERNANCE</a>
               <a href="mba-course-material-II-Year-Sem-4+BA7401 INTERNATIONAL BUSINESS MANAGEMENT.htm" class="list-group-item bfirst">BA7401 INTERNATIONAL BUSINESS MANAGEMENT</a>
               </div>
                </div>
</div>   
</div>
</div><div class="col-sm-3">
              <div class="single_sidebar">
                <a href="#" class="list-group-item" style="background:#dcb305; color:#000; font-size:15px;">Master of Business Administration</a>
                 <a href="mba.php" class="list-group-item ">About the Department</a>
                 <a href="mba1.php" class="list-group-item ">Association Activities</a>
                 <a href="mba2.php" class="list-group-item ">Laurels Won by Students</a>
                 <a href="mba3.php" class="list-group-item ">Alumni Students</a>
                 <a href="mba4.php" class="list-group-item active ">E-Course Material</a>  
                 <a href="http://nptel.ac.in/course.php?disciplineId=110" class="list-group-item" target="_blank">NPTEL VIDEO</a> 
              </div></div></div>    </div></div>
           
    </section>

     <!--=========== BEGIN FOOTER SECTION ================-->
  <?php include 'php/footer.php';?>
    <!--=========== END FOOTER SECTION ================--> 

  

    <!-- Javascript Files
    ================================================== -->

    <!-- initialize jQuery Library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <!-- Preloader js file -->
    <script src="js/queryloader2.min.js" type="text/javascript"></script>
    <!-- For smooth animatin  -->
    <script src="js/wow.min.js"></script>  
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- slick slider -->
    <script src="js/slick.min.js"></script>
    <!-- superslides slider -->
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.animate-enhanced.min.js"></script>
    <script src="js/jquery.superslides.min.js" type="text/javascript" charset="utf-8"></script>   
    <!-- for circle counter -->
    <script src='https://cdn.rawgit.com/pguso/jquery-plugin-circliful/master/js/jquery.circliful.min.js'></script>
    <!-- Gallery slider -->
    <script type="text/javascript" language="javascript" src="js/jquery.tosrus.min.all.js"></script>   
   
    <!-- Custom js-->
    <script src="js/custom.js"></script>
  <!--=============================================== 
    Template Design By WpFreeware Team.
    Author URI : http://www.wpfreeware.com/
  ====================================================-->
  </body>
  </html>
<!DOCTYPE html>
<html lang="en">
 <head>
  <?php include 'php/head.php';?>
</head>
  <body> 

    <!-- SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#"></a>
    <!-- END SCROLL TOP BUTTON -->

    <!--=========== BEGIN HEADER SECTION ================-->
   <?php include 'php/header.php';?>
    <!--=========== END HEADER SECTION ================--> 

    <!--=========== BEGIN COURSE BANNER SECTION ================-->
    <section id="imgBanner">
      <h2>Extra Curicular Activities</h2>
    </section>
    <!--=========== END COURSE BANNER SECTION ================-->

    
    <!--=========== BEGIN COURSE BANNER SECTION ================-->
    <section id="courseArchive">
      <div class="container">
        <div class="row">
          <!-- start course content -->
          <div class="col-lg-8 col-md-8 col-sm-8">
            <div class="courseArchive_content">              
             <div class="singlecourse_ferimg_area">
              <div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/S/1.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/S/2.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/S/3.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/S/4.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/S/5.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>
</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span>
  <span class="dot"></span>
</div>
               <!--div class="singlecourse_ferimg">
                 <img src="img/course-single.jpg" alt="img">
               </div>  
                <div class="singlecourse_bottom">
                  <h2>Introduction To Matrix</h2>
                  <span class="singlecourse_author">
                    <img alt="img" src="img/author.jpg">
                    Richard Remus, Teacher
                  </span>
                  <span class="singlecourse_price">$20</span>
                </div-->
             </div>
             <div class="single_course_content">
               <h2>Extra Curicular Activities</h2>
               <!--ol>
                 <li>Internet Programming Lab</li>
                 <li>Data structure lab</li>
                 <li>Operating systems lab</li>
                 <li>Networking lab</li>
                 <li>Database Management Lab</li>
                 <li>Object Oriented Programming Lab</li>
                 <li>Case tools lab</li>
                 <li>Common internet lab</li>
                 <li>Central Computing lab</li>
               </ol>
                <div>
        <div class="lab1">
            <img src="img/lab/lab-1.jpg"  />
        </div>
        <div class="lab2">
            <img src="img/lab/lab-2.jpg"  />
        </div>
    </div-->
               <!--p>Technology needs to be integrated into teaching and learning process and the Institution has done the best to ensure it in these well equipped classrooms. Technology has been deployed for better student-teacher interaction, productivity and communication. It makes teaching and learning simpler and enjoyable. 

Lecture Halls  ,Tutorial Rooms , Seminar Hall , Conference Hal</p-->
<h2>2015-2014
</h2>
              
               <table class="table table-striped course_table">
                <thead>
                  <tr>          
                    <th>S No</th>
                    <th>Name Of the Student</th>
                    <th>Year</th>
                     <th>Event</th>
                    <th>Name of the College Organized</th>
                    <th>Prize won</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>          
                    <td>1</td>
                    <td>C.SHARVIKA</td>
                    <td>IV</td>
                    <td>PAPER PRESENTATION</td>
                    <td>MUTHAYAMMAL ENGINEERING COLLEGE</td>
                    <td>FIRST</td>
                  </tr>
                  <tr>
                   <td>2</td>
                    <td>JOSNA HOSEPH</td>
                    <td>IV</td>
                    <td>PAPER PRESENTATION</td>
                    <td>MUTHAYAMMAL ENGINEERING COLLEGE</td>
                    <td>FIRST</td>
                  </tr>
                  <tr>
                    <td>3</td>
                    <td>B.SENTHIL KUMAR</td>
                    <td>IV</td>
                    <td>CODE DEBUGGING</td>
                    <td>S.N.S COLLEGE OF ENGINEERING</td>
                    <td>SECOND</td>
                  </tr>
                  <tr>
                    <td>4</td>
                    <td>G.RAMESH</td>
                    <td>IV</td>
                    <td>CODE DEBUGGING</td>
                    <td>S.N.S COLLEGE OF ENGINEERING</td>
                    <td>SECOND</td></tr>
                  <tr><td>5</td>
                    <td>R.RANJITH KUMAR</td>
                    <td>IV</td>
                    <td>TECHNICAL QUIZ,BEST MANAGER</td>
                    <td>KARPAGAM  COLLEGE OF ENGINEERING</td>
                    <td>SECOND</td> </tr>
                     <tr>
                      <td>6</td>
                    <td>K.S.RAGAVENDIRAN</td>
                    <td>IV</td>
                    <td>TECHNICAL QUIZ,BEST MANAGER</td>
                    <td>KARPAGAM  COLLEGE OF ENGINEERING</td>
                    <td>SECOND</td> </tr>
                     <tr><td>7</td>
                    <td>T.SYED MUBARAK</td>
                    <td>IV</td>
                    <td>BEST MANAGER</td>
                    <td>ANGEL COLLEGE OF ENGINEERING</td>
                    <td>SECOND</td> </tr>
                     <tr><td>8</td>
                    <td>T.VIVEKANADHAN  </td>
                    <td>IV</td>
                    <td>BEST MANAGER</td>
                    <td>ANGEL COLLEGE OF ENGINEERING</td>
                    <td>SECOND</td> </tr>
                </tbody>
              </table>
<h2>2013-2014
</h2>
              
               <table class="table table-striped course_table">
                <thead>
                  <tr>          
                    <th>S No</th>
                    <th>Name Of the Student</th>
                    <th>Year</th>
                     <th>Event</th>
                    <th>Name of the College Organized</th>
                    <th>Prize won</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>          
                    <td>1</td>
                    <td>B.SENTHIL KUMAR</td>
                    <td>III</td>
                    <td>PAPER PRESENTATION</td>
                    <td>M.P.N.M.J ENGINEERING COLLEGE</td>
                    <td>SECOND</td>
                  </tr>
                  <tr>
                   <td>2</td>
                    <td>R.RANJITH KUMAR</td>
                    <td>III</td>
                    <td>PAPER PRESENTATION</td>
                    <td>M.P.N.M.J ENGINEERING COLLEGE</td>
                    <td>SECOND</td>
                  </tr>
                  <tr>
                    <td>3</td>
                    <td>P.GOKUL KRISHNAN</td>
                    <td>III</td>
                    <td>PAPER PRESENTATION</td>
                    <td>TEJAA SAKTHI ENGINEERING COLLEGE</td>
                    <td>SECOND</td>
                  </tr>
                  <tr>
                    <td>4</td>
                    <td>P.GOKUL KRISHNAN</td>
                    <td>III</td>
                    <td>TECHNICAL QUIZ</td>
                    <td>TEJAA SAKTHI ENGINEERING COLLEGE</td>
                    <td>SECOND</td></tr>
                  <tr><td>5</td>
                    <td>P.GOKUL KRISHNAN</td>
                    <td>III</td>
                    <td>PAPER PRESENTATION</td>
                    <td>SRI KRISHNA ENGINEERING COLLEGE</td>
                    <td>FIRST</td> </tr>
                     <tr><td>6</td>
                    <td>P.GOKUL KRISHNAN</td>
                    <td>III</td>
                    <td>CODE DEBUGGING</td>
                    <td>SRI KRISHNA ENGINEERING COLLEGE</td>
                    <td>SECOND</td> </tr>
                     <tr><td>7</td>
                    <td>P.GOKUL KRISHNAN</td>
                    <td>III</td>
                    <td>PAPER PRESENTATION</td>
                    <td>RANGANATHAN ENGINEERING COLLEGE</td>
                    <td>SECOND</td> </tr>
                     <tr><td>8</td>
                    <td>P.GOKUL KRISHNAN</td>
                    <td>III</td>
                    <td>CODE DEBUGGING</td>
                    <td>JOHNSONS ENGINEERING COLLEGE</td>
                    <td>SECOND</td> </tr>
                </tbody>
              </table>

             </div>
             <script>
var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 1000); // Change image every 2 seconds
}
</script>

             <!-- start related course -->
             <!--div class="related_course">
                <h2>More Courses</h2>
                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="single_course wow fadeInUp" >
                      <div class="singCourse_imgarea">
                        <img src="img/course-1.jpg">
                        <div class="mask">                         
                          <a class="course_more" href="#">View Course</a>
                        </div>
                      </div>
                      <div class="singCourse_content">
                        <h3 class="singCourse_title"><a href="#">Introduction To Matrix</a></h3>
                        <p class="singCourse_price"><span>$20</span> Per One Month</p>
                        <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
                      </div>
                      <div class="singCourse_author">
                        <img alt="img" src="img/author.jpg">
                        <p>Richard Remus, Teacher</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="single_course wow fadeInUp" >
                      <div class="singCourse_imgarea">
                        <img src="img/course-1.jpg">
                        <div class="mask">                         
                          <a class="course_more" href="#">View Course</a>
                        </div>
                      </div>
                      <div class="singCourse_content">
                        <h3 class="singCourse_title"><a href="#">Introduction To Matrix</a></h3>
                        <p class="singCourse_price"><span>$20</span> Per One Month</p>
                        <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
                      </div>
                      <div class="singCourse_author">
                        <img alt="img" src="img/author.jpg">
                        <p>Richard Remus, Teacher</p>
                      </div>
                    </div>
                  </div>                                    
                </div>
              </div-->
              <!-- End related course -->
            </div>
          </div>
          <!-- End course content -->

          <!-- start course archive sidebar -->
          <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="courseArchive_sidebar">
              <!-- start single sidebar -->
              <!--div class="single_sidebar">
                <h2>Events <span class="fa fa-angle-double-right"></span></h2>
                <ul class="news_tab">
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a href="#" class="news_img">
                          <img alt="img" src="img/news.jpg" class="media-object">
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Dummy text of the printing and typesetting industry</a>
                       <span class="feed_date">27.02.15</span>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a href="#" class="news_img">
                          <img alt="img" src="img/news.jpg" class="media-object">
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Dummy text of the printing and typesetting industry</a>
                       <span class="feed_date">28.02.15</span>                
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a href="#" class="news_img">
                          <img alt="img" src="img/news.jpg" class="media-object">
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Dummy text of the printing and typesetting industry</a>
                       <span class="feed_date">28.02.15</span>                
                      </div>
                    </div>
                  </li>                  
                </ul>
              </div-->
              <!-- End single sidebar -->
              <!-- start single sidebar -->
              <div class="single_sidebar">
                <h2>Computer Science and Engineering <span class="fa fa-angle-double-right"></span></h2>
                <ul>
                  <li><a href="cse.php">About the Department</a></li>
                  <li><a href="#">Labs Facilities</a></li>
                   <li><a href="class.php">Class Room Facilities</a></li>
                  <li><a href="#">Faculty Profile</a></li>
                  <li><a href="#">Association Activities</a></li>
                  <li><a href="#">Laurels Won by Students</a></li>
                  <li><a href="#">Alumini Students</a></li>
                  <li><a href="extra.php">Extra Curricular Activities</a></li>
                  <li><a href="#">E-Course Material</a></li>
                  <li><a href="#">NPTEL VIDEO</a></li>
                </ul>
              </div>
              <!-- End single sidebar -->
              <!-- start single sidebar -->
              <!--div class="single_sidebar">
                <h2>Sponsor Add <span class="fa fa-angle-double-right"></span></h2>
                <a class="side_add" href="#"><img src="img/side-add.jpg" alt="img"></a>
              </div-->
              <!-- End single sidebar -->
            </div>
          </div>
          <!-- start course archive sidebar -->
        </div>
      </div>
    </section>
    <!--=========== END COURSE BANNER SECTION ================-->
    
    <!--=========== BEGIN FOOTER SECTION ================-->
   <?php include 'php/footer.php';?>
    <!--=========== END FOOTER SECTION ================--> 

  

    <!-- Javascript Files
    ================================================== -->

    <!-- initialize jQuery Library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <!-- Preloader js file -->
    <script src="js/queryloader2.min.js" type="text/javascript"></script>
    <!-- For smooth animatin  -->
    <script src="js/wow.min.js"></script>  
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- slick slider -->
    <script src="js/slick.min.js"></script>
    <!-- superslides slider -->
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.animate-enhanced.min.js"></script>
    <script src="js/jquery.superslides.min.js" type="text/javascript" charset="utf-8"></script>   
    <!-- for circle counter -->
    <script src='https://cdn.rawgit.com/pguso/jquery-plugin-circliful/master/js/jquery.circliful.min.js'></script>
    <!-- Gallery slider -->
    <script type="text/javascript" language="javascript" src="js/jquery.tosrus.min.all.js"></script>   
   
    <!-- Custom js-->
    <script src="js/custom.js"></script>
  <!--=============================================== 
    Template Design By WpFreeware Team.
    Author URI : http://www.wpfreeware.com/
  ====================================================-->

  </body>
</html>
<!DOCTYPE html>
<html lang="en">
 <head>
  <?php include 'php/head.php';?>
</head>
  <body> 

    <!-- SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#"></a>
    <!-- END SCROLL TOP BUTTON -->

    <?php include 'php/header.php';?>
    <!--=========== END HEADER SECTION ================--> 

    <!--=========== BEGIN COURSE BANNER SECTION ================-->
    <section id="imgBanner">
      <h2>Computer Science</h2>
    </section>
    <!--=========== END COURSE BANNER SECTION ================-->

    
    <!--=========== BEGIN COURSE BANNER SECTION ================-->
    <section id="courseArchive">
      <div class="container">
        <div class="row">
          <!-- start course content -->
          <div class="col-lg-8 col-md-8 col-sm-8">
            <div class="courseArchive_content">              
             <div class="singlecourse_ferimg_area">
              <div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/place/1.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/place/2.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/place/3.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/place/4.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/place/5.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>
</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span>
  <span class="dot"></span>
</div>
               <!--div class="singlecourse_ferimg">
                 <img src="img/course-single.jpg" alt="img">
               </div>  
                <div class="singlecourse_bottom">
                  <h2>Introduction To Matrix</h2>
                  <span class="singlecourse_author">
                    <img alt="img" src="img/author.jpg">
                    Richard Remus, Teacher
                  </span>
                  <span class="singlecourse_price">$20</span>
                </div-->
             </div></div></div>
<div class="col-lg-4 col-md-4 col-sm-4">
            <div class="courseArchive_sidebar">
              <div class="single_sidebar" >
                <h2>Placements <span class="fa fa-angle-double-right"></span></h2>
                <ul>
                  <li><a href="our.php">Our Recruiters</a></li>
                  <li><a href="ptn.php">Placements Till Now</a></li>
                   <li><a href="trainning.php">Training</a></li>
                  <li><a href="contactplace.php">Contact PCDC</a></li>
                </ul>
              </div></div></div>
              <div class="row">
<div class=" col-sm-8">



<div class="row">
<div class="col-xs-12 col-sm-9">
  <div class=" inner"> 
    <div class="">
      <h1>Training</h1>
      <h4><strong>Training Methodology </strong></h4>
      <p>&nbsp;</p>
      <h3><strong>1st  Year&nbsp; - Soft Skill and Maths Speed  concept Training</strong></h3>
      <ul class="list">
        <li>Ice  Breaking Exercises</li>
        <li>Word  formation</li>
        <li>Logical  Puzzles</li>
        <li>Confident  Building exercise</li>
        <li>Memory  Training&nbsp; games</li>
      </ul>
      <h3><strong>2nd Year –  Communication and Basic concepts in Aptitude</strong></h3>
      <ul class="list">
        <li>Ice breaking session</li>
        <li>One minute talk about him/her self</li>
        <li>Presentation - Needs of communication</li>
        <li>Inspiration games</li>
        <li>Self grooming</li>
        <li>Giving motivation and inspirations to break  their stage fear</li>
        <li>Listening skill practice – communication lab</li>
        <li>Motivation session, Placement Importance<strong></strong></li>
        <li>Attitude Building session</li>
        <li>Importance Grammar session</li>
        <li>Presentation Skill Session</li>
        <li>Basic Grammar(Past, Present &amp; Future) Tenses<strong></strong></li>
        <li>Reading Comprehension<strong></strong></li>
        <li>Rearrange the Sentence<strong></strong></li>
        <li>Prepositions</li>
      </ul>
      <h3><strong>3rd Year –  Language Training and Soft Skill training </strong></h3>
      <ul class="list">
        <li>Training on Language like Writing, Speaking  ,&nbsp; Listening&amp;Reading Skill.<strong></strong></li>
        <li>Career Planning &amp; Goal Setting<strong></strong></li>
        <li>Importance of placement&nbsp; &amp; Placement @ Sasurie<strong></strong></li>
        <li>Self Grooming</li>
        <li>Resume Preparation</li>
        <li>Communication Importance</li>
        <li>Industry Expectation</li>
        <li>One Minute Talk</li>
        <li>GD Do’s &amp; Don’ts</li>
        <li>Interview Do’s &amp; Don’ts </li>
        <li>Mock GD Practices</li>
      </ul>
      <h3><strong>4th Year –  Language Training , Soft Skill Training and Campus placement Preparatory  Training</strong></h3>
      <ul class="list">
        <li>Training on Language like Writing, Speaking  ,&nbsp; Listening&amp; Reading Skill.<strong></strong></li>
        <li>Industry Expectation</li>
        <li>Campus Placement Preparatory Training</li>
        <li>Higher Studies awareness session</li>
      </ul>
      <h3><strong>Our Expert Presence :</strong></h3>
      <ol start="1" type="1">
        <li>Tech Mahindra FDP programmes       &amp; SDP actrivities</li>
        <li>Industry Interaction by       Corporate from CTS, Inautix, HCL, Hexaware, Atmel, Jasmin Infotech, AMI,       FSS, Wheels India, Titan Industries, etc.</li>
        <li>Aptitude Training by Speed       maths Trainers</li>
        <li>Language and Soft &nbsp;Training by External Training Companies</li>
        </ol>
      <p>&nbsp;</p>
<h3>Training program Details by Experts from Corporates / Training Institute.</h3>
<div class="table-responsive">
  <table class="table table-bordered ">
    <tbody><tr>
    <td width="59"><p align="center"><strong>S.No</strong></p></td>
    <td width="182"><p align="center"><strong>Name    of the Program</strong></p></td>
    <td width="78"><p align="center"><strong>Date</strong></p></td>
    <td width="246"><p align="center"><strong>Resource    Person</strong></p></td>
  </tr>
  <tr>
    <td width="59"><p>1</p></td>
    <td width="182"><p align="center">A    national level project Competition SASURIE INNOVATION EXPEDITITION</p></td>
    <td width="78"><p align="center">07.04.16</p></td>
    <td width="246"><p>D Eregamani <br>
      Asst General Manager &amp; Head - TQM <br>
      Carborundum Universal Ltd., </p></td>
  </tr>
  <tr>
    <td width="59"><p>2</p></td>
    <td width="182"><p align="center">National    Conference On Advances In Engineering Sciences</p></td>
    <td width="78"><p align="center">04.04.16</p></td>
    <td width="246"><p>Mr.Bhagath, CEO,Kalycito, Coimbatore</p></td>
  </tr>
  <tr>
    <td width="59"><p>3</p></td>
    <td width="182"><p align="center">Competitive    Exam Training Program<br>
      (46    ways to get a govt job in India)</p></td>
    <td width="78"><p align="center">31.03.16</p></td>
    <td width="246"><p>Mr.S.Vinoth, District Employment Officer, Erode</p></td>
  </tr>
  <tr>
    <td width="59"><p>4</p></td>
    <td width="182"><p align="center">Language    Training Program</p></td>
    <td width="78"><p align="center">19.03.16<br>
      to<br>
      23.03.16</p></td>
    <td width="246"><p>M Cube Solutions, Coimbatore.</p></td>
  </tr>
  <tr>
    <td width="59"><p>5</p></td>
    <td width="182"><p align="center">Industry    institution interaction session</p></td>
    <td width="78"><p align="center">18.03.16</p></td>
    <td width="246"><p>Mr.Sivakumar Palaniappan, HR Manager</p></td>
  </tr>
  <tr>
    <td width="59"><p>6</p></td>
    <td width="182"><p align="center">Leadership    Training Program</p></td>
    <td width="78"><p align="center">17.03.16</p></td>
    <td width="246"><p>Mr .R.Vijayan, General Manager,HR, CADeploy</p></td>
  </tr>
  <tr>
    <td width="59"><p>7</p></td>
    <td width="182"><p align="center">Sasurie    Leadership Forum</p></td>
    <td width="78"><p align="center">10.02.16</p></td>
    <td width="246"><p>Mr .R.Vijayan, General Manager,HR, CADeploy</p></td>
  </tr>
  <tr>
    <td width="59"><p>8</p></td>
    <td width="182"><p align="center">Industry    Institution Interaction session</p></td>
    <td width="78"><p align="center">19.08.15</p></td>
    <td width="246"><p>Mr.A.Ravi, Managing Partner, Priya Constructions.</p></td>
  </tr>
  <tr>
    <td width="59"><p>9</p></td>
    <td width="182"><p align="center">Industry    Institution Interaction session</p></td>
    <td width="78"><p align="center">14.08.15</p></td>
    <td width="246"><p>Mr.U.N. Muralikrishna, VP, Skava systems.</p></td>
  </tr>
  <tr>
    <td width="59"><p>10</p></td>
    <td width="182"><p align="center">Industry    Institution Interaction session</p></td>
    <td width="78"><p align="center">12.08.15</p></td>
    <td width="246"><p>Mr. K.Raghunandhanan,<br>
      Jt .General manager,<br>
      Larson &amp; Toubro.</p></td>
  </tr>
  <tr>
    <td width="59"><p>11</p></td>
    <td width="182"><p align="center">Mock    Interview</p></td>
    <td width="78"><p align="center">20.06.15</p></td>
    <td width="246"><p>Mr.G.Sudhakaran,<br>
      Team Lead, UST Global.</p></td>
  </tr>
  <tr>
    <td width="59"><p>12</p></td>
    <td width="182"><p align="center">Mock    Interview</p></td>
    <td width="78"><p align="center">20.06.15</p></td>
    <td width="246"><p>Mr.G.Logeshwaran, Team Lead, Qualcom.</p></td>
  </tr>
  <tr>
    <td width="59"><p>13</p></td>
    <td width="182"><p align="center">Mock    Interview</p></td>
    <td width="78"><p align="center">20.06.15</p></td>
    <td width="246"><p>Ms.J.Shanthini, HR executive, Happy miles.</p></td>
  </tr>
  <tr>
    <td width="59"><p>14</p></td>
    <td width="182"><p align="center">Mock    Interview</p></td>
    <td width="78"><p align="center">20.06.15</p></td>
    <td width="246"><p>Mr.S.Yuvaraj, Team Lead, ZTE Telecom.</p></td>
  </tr>
  <tr>
    <td width="59"><p>15</p></td>
    <td width="182"><p align="center">Mock    Interview</p></td>
    <td width="78"><p align="center">20.06.15</p></td>
    <td width="246"><p>Mr.B.Ramesh, Project Engineer, BSOL Systems.</p></td>
  </tr>
  <tr>
    <td width="59"><p>16</p></td>
    <td width="182"><p align="center">Mock    Interview</p></td>
    <td width="78"><p align="center">20.06.15</p></td>
    <td width="246"><p>Mr.P. Matheswaran, Embedded Engineer, Calibre    Interconnect systems.</p></td>
  </tr>
  <tr>
    <td width="59"><p>17</p></td>
    <td width="182"><p align="center">Mock    Interview</p></td>
    <td width="78"><p align="center">20.06.15</p></td>
    <td width="246"><p>Mr.A. Tamilalagan, Director -&nbsp; work flow,&nbsp;    S Forge LLP, India</p></td>
  </tr>
  <tr>
    <td width="59"><p>18</p></td>
    <td width="182"><p align="center">Mock    interview</p></td>
    <td width="78"><p align="center">20.06.15</p></td>
    <td width="246"><p>Mr.B.Lakhsmikandan, Technical Lead, Cameron.</p></td>
  </tr>
  <tr>
    <td width="59"><p>19</p></td>
    <td width="182"><p align="center">Mock    interview</p></td>
    <td width="78"><p align="center">20.06.15</p></td>
    <td width="246"><p>Mr.A.Ravi, Managing partner, Priya constructions.</p></td>
  </tr>
  <tr>
    <td width="59"><p>20</p></td>
    <td width="182"><p align="center">Mock    interview</p></td>
    <td width="78"><p align="center">20.06.15</p></td>
    <td width="246"><p>Mr.R.Yogeshwar, Technical Engineer, Roots    industries.</p></td>
  </tr>
  <tr>
    <td width="59"><p>21</p></td>
    <td width="182"><p align="center">Mock    interview</p></td>
    <td width="78"><p align="center">20.06.15</p></td>
    <td width="246"><p>Ms.M. Dharini, Software Engineer, Bosch.</p></td>
  </tr>
  <tr>
    <td width="59"><p>22</p></td>
    <td width="182"><p align="center">Mock    interview</p></td>
    <td width="78"><p align="center">20.06.15</p></td>
    <td width="246"><p>Mr.N. Ravindiran, Technical Engineer, Roots    industries.</p></td>
  </tr>
  <tr>
    <td width="59"><p>23</p></td>
    <td width="182"><p align="center">Phase    I Training</p></td>
    <td width="78"><p align="center">02.06.2015</p></td>
    <td width="246"><p>PCDC, Sasurie College of Engineering,    Vijayamangalam</p></td>
  </tr>
  </tbody></table>
  <table class="table table-bordered ">
     <tbody><tr>
       <td width="62"><strong>S.NO</strong></td>
       <td width="168"><strong>DATE OF THE    EVENT</strong></td>
       <td width="418"><strong>NAME</strong></td>
     </tr>
     <tr>
       <td>1</td>
       <td width="168">02.06.2015</td>
       <td>PHASE I TRAINING</td>
     </tr>
     <tr>
       <td>2</td>
       <td width="168">29.07.2015</td>
       <td>LUCID TECHNOLOGIES ON    CAMPUS</td>
     </tr>
     <tr>
       <td>3</td>
       <td width="168">31.07.2015</td>
       <td>VOLANTE TECHNOLOGIES    OFF CAMPUS</td>
     </tr>
     <tr>
       <td>4</td>
       <td width="168">25.08.2015</td>
       <td>VERNALIS SYSTEM ON    CAMPUS</td>
     </tr>
     <tr>
       <td>5</td>
       <td width="168">25.8.2015</td>
       <td>10 DAYS TECH MAHINDRA    COMPANY BASED TRAINING</td>
     </tr>
     <tr>
       <td>6</td>
       <td width="168">26.08.2015</td>
       <td>PAYODA OFF CAMPUS</td>
     </tr>
     <tr>
       <td>7</td>
       <td width="168">04.09.2015</td>
       <td>TECH MAHINDRA POOL    DRIVE</td>
     </tr>
     <tr>
       <td>8</td>
       <td>05.09.2015</td>
       <td>GODB TECH OFF CAMPUS</td>
     </tr>
     <tr>
       <td>9</td>
       <td>12.09.2015</td>
       <td>AGNITIO SYSTEMS ON    CAMPUS</td>
     </tr>
   </tbody></table>
    <table class="table table-bordered ">
    <tbody><tr>
      <td width="125"><strong>Sl. No</strong></td>
      <td width="484"><strong>Date</strong></td>
      <td width="912"><strong>Name of the event</strong></td>
      </tr>
    <tr>
      <td width="125">1</td>
      <td width="484">21.01.13 to 29.01.13 </td>
      <td width="912">Career Skill program for Final years</td>
      </tr>
    <tr>
      <td width="125">2</td>
      <td width="484">30.01.13 to 07.02.13</td>
      <td width="912">Social Skill program for present 3rd year</td>
      </tr>
    <tr>
      <td width="125">3</td>
      <td width="484">28.01.13 to 22.02.13 </td>
      <td width="912">Language&nbsp; and Verbal Reasoning    Training program for Present&nbsp; 3rd    year &amp; Present final year - </td>
      </tr>
    <tr>
      <td width="125">4</td>
      <td width="484">11.02.13</td>
      <td width="912">Basic Ethics program for Final years</td>
      </tr>
    <tr>
      <td width="125">5</td>
      <td width="484">18.02.13</td>
      <td width="912">Public Speaking program for present final years</td>
      </tr>
    <tr>
      <td width="125">6</td>
      <td width="484">25.02.13</td>
      <td width="912">Confidence Building program</td>
      </tr>
    <tr>
      <td width="125">7</td>
      <td width="484">04.03.13</td>
      <td width="912">Program on Creative thinking</td>
      </tr>
    <tr>
      <td width="125">8</td>
      <td width="484">18.03.13</td>
      <td width="912">Time Management program for present&nbsp;    final years &amp;Y third year</td>
      </tr>
    <tr>
      <td width="125">9</td>
      <td width="484">19.07.13 to 23.08.13</td>
      <td width="912">Language&nbsp; and Verbal Reasoning    Training program for final year </td>
      </tr>
    <tr>
      <td width="125">10</td>
      <td width="484">19.08.13 to 30.08.13 </td>
      <td width="912">Soft Skill program for Final years</td>
      </tr>
    <tr>
      <td width="125">11</td>
      <td width="484">26.08.13 to 31.08.13</td>
      <td width="912">Soft Skill program for present 3rd year</td>
      </tr>
    <tr>
      <td width="125">12</td>
      <td width="484">23.09.13 to 27.09.13</td>
      <td width="912">Counseling for present final year </td>
      </tr>
    <tr>
      <td width="125">13</td>
      <td width="484">12.12.13 to 27.12.13</td>
      <td width="912">Campus placement preparatory program on the company specific like    Tech Mahindra, CTS.</td>
      </tr>
    <tr>
      <td width="125">14</td>
      <td width="484">10.09.13 to 12.09.13</td>
      <td width="912">BEC Training for Staff members by British Council Experts</td>
      </tr>
    <tr>
      <td width="125">15</td>
      <td width="484">30.09.13 to 02.10.13 </td>
      <td width="912">C&amp; C++&nbsp; - Workshop for 3    days</td>
      </tr>
    <tr>
      <td width="125">16</td>
      <td width="484">17.12.13 to 19.12.13</td>
      <td width="912">C++ and Java Workshop for final years</td>
      </tr>
    <tr>
      <td width="125">17</td>
      <td width="484">30.01.14 to 31.01.14</td>
      <td width="912">Aptitude Training program on company based for final years</td>
      </tr>
    <tr>
      <td width="125">18</td>
      <td width="484">Language Training by BEC Trainer</td>
      <td width="912">28.01.14 to 29.01.14</td>
      </tr>
  </tbody></table>
</div>
    </div>
 
</div>

</div></div>

</div>
             <script>
var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 1000); // Change image every 2 seconds
}
</script>

           
        </div>
      </div>
    </section>
    <!--=========== END COURSE BANNER SECTION ================-->
    
    <!--=========== BEGIN FOOTER SECTION ================-->
    <?php include 'php/footer.php';?>
    <!--=========== END FOOTER SECTION ================--> 

  

    <!-- Javascript Files
    ================================================== -->

    <!-- initialize jQuery Library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <!-- Preloader js file -->
    <script src="js/queryloader2.min.js" type="text/javascript"></script>
    <!-- For smooth animatin  -->
    <script src="js/wow.min.js"></script>  
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- slick slider -->
    <script src="js/slick.min.js"></script>
    <!-- superslides slider -->
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.animate-enhanced.min.js"></script>
    <script src="js/jquery.superslides.min.js" type="text/javascript" charset="utf-8"></script>   
    <!-- for circle counter -->
    <script src='https://cdn.rawgit.com/pguso/jquery-plugin-circliful/master/js/jquery.circliful.min.js'></script>
    <!-- Gallery slider -->
    <script type="text/javascript" language="javascript" src="js/jquery.tosrus.min.all.js"></script>   
   
    <!-- Custom js-->
    <script src="js/custom.js"></script>
  </body>
</html>
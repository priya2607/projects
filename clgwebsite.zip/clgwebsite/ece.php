<!DOCTYPE html>
<html lang="en">
 <head>
  <?php include 'php/head.php';?>
</head>
  <body> 

    <!-- SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#"></a>
    <!-- END SCROLL TOP BUTTON -->

   <?php include 'php/header.php';?>
    <!--=========== BEGIN COURSE BANNER SECTION ================-->
    <section id="imgBanner">
      <h2>ECE</h2>
    </section>
    <!--=========== END COURSE BANNER SECTION ================-->

    
    <!--=========== BEGIN COURSE BANNER SECTION ================-->
    <section id="courseArchive">
      <div class="container">
        <div class="row">
          <!-- start course content -->
          <div class="col-lg-8 col-md-8 col-sm-8">
            <div class="courseArchive_content">              
             <div class="singlecourse_ferimg_area">
              <div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/S/ece/1.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/S/ece/2.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>

<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/S/ece/3.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>
<div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/S/ece/4.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div>
<!--div class="mySlides fade">
  <div class="numbertext"></div>
  <img src="img/S/5.jpg" style="width:100%">
  <div class="text">THE TECHNOCRATS OF THE SOCIETY</div>
</div-->
</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span>
</div>
               <!--div class="singlecourse_ferimg">
                 <img src="img/course-single.jpg" alt="img">
               </div>  
                <div class="singlecourse_bottom">
                  <h2>Introduction To Matrix</h2>
                  <span class="singlecourse_author">
                    <img alt="img" src="img/author.jpg">
                    Richard Remus, Teacher
                  </span>
                  <span class="singlecourse_price">$20</span>
                </div-->
             </div>
             <div class="single_course_content">
               <h2>About The Coures</h2>
               <p>The department of Electronics and Communication Engineering was established during the inception of the institute in the year 2001 to produce competent engineers in the field of Electronics and Communication Engineering. At present, the intake is 180 students since 2013.The department offers undergraduate degree programme of B.E Electronics and Communication Engineering & and postgraduate degree programme of M.E Applied electronics & VLSI Design. The department has state-of-the-art laboratory facilities to infuse practical knowledge to the students on par with academic excellence. The department has excellent and consistent placement record and most of the students are placed in reputed organizations. The department actively involved in teaching and research in disparate subfields of Electronics, Telecommunication, Signal Processing and Embedded Systems.</p>
<h2>Long Term Goal</h2>
               <p> To endeavor the department as a centre of excellence in offering quality education, technically competent and research focus in catering with high pattern of discipline through our dedicated faculty members in order to meet the challenges of industries in the area of Electronics and Communication Engineering.</p><h2>Short Term Goal</h2>
               <p>To educate the students with the state of art technologies to meet the growing challenges of the industry.
To make research culture among the faculty members and students.
To provide ethical and value based education by promoting activities addressing the societal needs.</p><h2>Programme Educational Objectives</h2><p>Make the graduates to acquire strong in subject fundamentals which facilitate them to solve complex engineering problems for betterment of society.
Make the graduates for active participation in co-curricular activities which enable them to get exposure in knowledge sharing, novel ideas and leadership skills.
Make the graduates to exhibit professional and ethical outlook, effective communication, team work and multidisciplinary approach.
Make the graduates to excel in higher studies and competitiveness in technical profession.</p><h2>Programme Outcomes</h2><p>The graduates will be able to acquire knowledge in mathematics, Engineering Sciences and Fundamentals of Electronics and Communication Engineering.
The graduates will be able to identify, formulate to design electronic circuits and interpret data.
The graduates will be able to use modern electronic equipments and software’s to analyze Engineering problems.
The graduates will be able to communicate effectively in both verbal and written form.
The graduates will be able to understand the professional, ethical and social responsibilities.
The graduates will be able to analyze the contemporary issues on electronics and provide the necessary solutions to the society.</p>
               <!--table class="table table-striped course_table">
                <thead>
                  <tr>          
                    <th>Course Title</th>
                    <th>Instructor</th>
                    <th>Timing</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>          
                    <td><a href="#">Computer Science &amp; Engineering</a></td>
                    <td>Dr. Steve Palmer</td>
                    <td>08:00 to 13:00</td>
                  </tr>
                  <tr>
                    <td><a href="#">Electronics &amp; Communications Engineering</a></td>          
                    <td>Jacob</td>                    
                    <td>08:00 to 13:00</td>
                  </tr>
                  <tr>
                    <td><a href="#">Civil Engineering</a></td>          
                    <td>Kimberly Jones</td>                    
                    <td>08:00 to 13:00</td>
                  </tr>
                  <tr>
                    <td><a href="#">Electrical &amp; Electronics Engineering</a></td>   

                    <td>Dr. Klee</td>                    
                    <td>08:00 to 13:00</td>
                  </tr>
                  <tr><td><a href="#">Mechanical Engineering</a></td> </tr>
                </tbody>
              </table-->
             </div>
             <script>
var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 1000); // Change image every 2 seconds
}
</script>

             <!-- start related course -->
             <!--div class="related_course">
                <h2>More Courses</h2>
                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="single_course wow fadeInUp" >
                      <div class="singCourse_imgarea">
                        <img src="img/course-1.jpg">
                        <div class="mask">                         
                          <a class="course_more" href="#">View Course</a>
                        </div>
                      </div>
                      <div class="singCourse_content">
                        <h3 class="singCourse_title"><a href="#">Introduction To Matrix</a></h3>
                        <p class="singCourse_price"><span>$20</span> Per One Month</p>
                        <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
                      </div>
                      <div class="singCourse_author">
                        <img alt="img" src="img/author.jpg">
                        <p>Richard Remus, Teacher</p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="single_course wow fadeInUp" >
                      <div class="singCourse_imgarea">
                        <img src="img/course-1.jpg">
                        <div class="mask">                         
                          <a class="course_more" href="#">View Course</a>
                        </div>
                      </div>
                      <div class="singCourse_content">
                        <h3 class="singCourse_title"><a href="#">Introduction To Matrix</a></h3>
                        <p class="singCourse_price"><span>$20</span> Per One Month</p>
                        <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
                      </div>
                      <div class="singCourse_author">
                        <img alt="img" src="img/author.jpg">
                        <p>Richard Remus, Teacher</p>
                      </div>
                    </div>
                  </div>                                    
                </div>
              </div-->
              <!-- End related course -->
            </div>
          </div>
          <!-- End course content -->

          <!-- start course archive sidebar -->
          <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="courseArchive_sidebar">
              <!-- start single sidebar -->
              <!--div class="single_sidebar">
                <h2>Events <span class="fa fa-angle-double-right"></span></h2>
                <ul class="news_tab">
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a href="#" class="news_img">
                          <img alt="img" src="img/news.jpg" class="media-object">
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Dummy text of the printing and typesetting industry</a>
                       <span class="feed_date">27.02.15</span>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a href="#" class="news_img">
                          <img alt="img" src="img/news.jpg" class="media-object">
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Dummy text of the printing and typesetting industry</a>
                       <span class="feed_date">28.02.15</span>                
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="media">
                      <div class="media-left">
                        <a href="#" class="news_img">
                          <img alt="img" src="img/news.jpg" class="media-object">
                        </a>
                      </div>
                      <div class="media-body">
                       <a href="#">Dummy text of the printing and typesetting industry</a>
                       <span class="feed_date">28.02.15</span>                
                      </div>
                    </div>
                  </li>                  
                </ul>
              </div-->
              <!-- End single sidebar -->
              <!-- start single sidebar -->
              <div class="single_sidebar">
                <h2>Electronics and Communication Engineering <span class="fa fa-angle-double-right"></span></h2>
                <ul>
                  <li><a href="cse.php">About the Department</a></li>
                  <li><a href="labs.php">Labs Facilities</a></li>
                   <li><a href="class.php">Class Room Facilities</a></li>
                  <li><a href="#">Faculty Profile</a></li>
                  <li><a href="#">Association Activities</a></li>
                  <li><a href="#">Laurels Won by Students</a></li>
                  <li><a href="#">Alumini Students</a></li>
                  <li><a href="extra.php">Extra Curricular Activities</a></li>
                  <li><a href="#">E-Course Material</a></li>
                  <li><a href="#">NPTEL VIDEO</a></li>
                </ul>
              </div>
              <!-- End single sidebar -->
              <!-- start single sidebar -->
              <!--div class="single_sidebar">
                <h2>Sponsor Add <span class="fa fa-angle-double-right"></span></h2>
                <a class="side_add" href="#"><img src="img/side-add.jpg" alt="img"></a>
              </div-->
              <!-- End single sidebar -->
            </div>
          </div>
          <!-- start course archive sidebar -->
        </div>
      </div>
    </section>
    <!--=========== END COURSE BANNER SECTION ================-->
    
    <!--=========== BEGIN FOOTER SECTION ================-->
  <?php include 'php/footer.php';?>
    <!--=========== END FOOTER SECTION ================--> 

  

    <!-- Javascript Files
    ================================================== -->

    <!-- initialize jQuery Library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <!-- Preloader js file -->
    <script src="js/queryloader2.min.js" type="text/javascript"></script>
    <!-- For smooth animatin  -->
    <script src="js/wow.min.js"></script>  
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- slick slider -->
    <script src="js/slick.min.js"></script>
    <!-- superslides slider -->
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.animate-enhanced.min.js"></script>
    <script src="js/jquery.superslides.min.js" type="text/javascript" charset="utf-8"></script>   
    <!-- for circle counter -->
    <script src='https://cdn.rawgit.com/pguso/jquery-plugin-circliful/master/js/jquery.circliful.min.js'></script>
    <!-- Gallery slider -->
    <script type="text/javascript" language="javascript" src="js/jquery.tosrus.min.all.js"></script>   
   
    <!-- Custom js-->
    <script src="js/custom.js"></script>
  <!--=============================================== 
    Template Design By WpFreeware Team.
    Author URI : http://www.wpfreeware.com/
  ====================================================-->

  </body>
</html>